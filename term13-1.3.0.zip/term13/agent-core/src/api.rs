use crate::{
    agent::Agent,
    config::Config,
    storage::Store,
    types::{
        AbortRequest, ConfirmRequest, HistoryResponse, Model, ModelsResponse, TaskRequest,
        TaskResponse,
    },
};
use async_stream::stream;
use axum::{
    extract::{Path, Query, State},
    http::{header, StatusCode},
    response::{
        sse::{Event, KeepAlive, Sse},
        IntoResponse,
    },
    routing::{get, post},
    Json, Router,
};
use serde::Deserialize;
use serde_json::{json, Value};
use std::{convert::Infallible, time::Duration};
use tokio::time::sleep;

#[derive(Clone)]
pub struct AppState {
    pub agent: Agent,
    pub store: Store,
    pub cfg: Config,
}
#[derive(Deserialize)]
pub struct IdQuery {
    pub id: String,
}

pub fn router(state: AppState) -> Router {
    Router::new()
        .route("/healthz", get(health))
        .route("/v1/models", get(models))
        .route("/usage", get(usage))
        .route("/balance", get(balance))
        .route("/task", post(task))
        .route("/abort", post(abort))
        .route("/confirm", post(confirm))
        .route("/history", get(history))
        .route("/stream", get(stream_job))
        .with_state(state)
}
async fn health(State(_s): State<AppState>) -> impl IntoResponse {
    Json(json!({"ok":true,"mode":"rust-safe-agent"}))
}
async fn read_json_url(s: &AppState, url: &Option<String>) -> Value {
    let Some(url) = url else {
        return json!({"ok":false,"configured":false,"error":"endpoint not configured"});
    };
    let mut req = s.agent.client.get(url);
    if let Some(k) = &s.cfg.ai_key {
        req = req.bearer_auth(k);
    }
    match req.send().await {
        Ok(r) => r
            .json::<Value>()
            .await
            .unwrap_or_else(|_| json!({"ok":false,"error":"invalid upstream json"})),
        Err(e) => json!({"ok":false,"error":e.to_string()}),
    }
}
async fn usage(State(s): State<AppState>) -> impl IntoResponse {
    Json(read_json_url(&s, &s.cfg.usage_url).await)
}
async fn balance(State(s): State<AppState>) -> impl IntoResponse {
    Json(read_json_url(&s, &s.cfg.balance_url).await)
}
async fn models(State(s): State<AppState>) -> impl IntoResponse {
    let url = format!("{}/models", s.cfg.ai_url.trim_end_matches('/'));
    let mut r = s.agent.client.get(url);
    if let Some(k) = &s.cfg.ai_key {
        r = r.bearer_auth(k);
    }
    match r.send().await {
        Ok(resp) => match resp.json::<ModelsResponse>().await {
            Ok(v) => Json(v).into_response(),
            Err(_) => Json(ModelsResponse {
                object: "list".into(),
                default_model: Some(s.cfg.default_model.clone()),
                data: vec![Model {
                    id: s.cfg.default_model.clone(),
                    object: "model".into(),
                    owned_by: "local".into(),
                    root: s.cfg.default_model.clone(),
                    default: true,
                }],
            })
            .into_response(),
        },
        Err(_) => Json(ModelsResponse {
            object: "list".into(),
            default_model: Some(s.cfg.default_model.clone()),
            data: vec![Model {
                id: s.cfg.default_model.clone(),
                object: "model".into(),
                owned_by: "local".into(),
                root: s.cfg.default_model.clone(),
                default: true,
            }],
        })
        .into_response(),
    }
}
async fn task(State(s): State<AppState>, Json(req): Json<TaskRequest>) -> impl IntoResponse {
    match s.agent.submit(req.text, req.model, req.role).await {
        Ok(id) => Json(TaskResponse {
            ok: true,
            id,
            queued: false,
        })
        .into_response(),
        Err(e) => (
            StatusCode::BAD_REQUEST,
            Json(json!({"error":e.to_string()})),
        )
            .into_response(),
    }
}
async fn abort(State(s): State<AppState>, Json(req): Json<AbortRequest>) -> impl IntoResponse {
    Json(json!({"ok":s.agent.abort(&req.id).await}))
}
async fn confirm(State(s): State<AppState>, Json(req): Json<ConfirmRequest>) -> impl IntoResponse {
    match s.agent.confirm(&req.id, &req.hash).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(json!({"ok":false,"error":e.to_string()})),
        )
            .into_response(),
    }
}
async fn history(State(s): State<AppState>, Query(q): Query<IdQuery>) -> impl IntoResponse {
    match s.store.get_job(&q.id).await {
        Some(j) => Json(HistoryResponse {
            id: j.id,
            status: j.status,
            text: j.text,
            answer: j.answer,
            steps: j.steps,
        })
        .into_response(),
        None => (
            StatusCode::NOT_FOUND,
            Json(json!({"error":"job not found"})),
        )
            .into_response(),
    }
}
async fn stream_job(State(s): State<AppState>, Query(q): Query<IdQuery>) -> impl IntoResponse {
    let id = q.id;
    let store = s.store.clone();
    let events = stream! {yield Ok::<Event,Infallible>(Event::default().event("hello").json_data(json!({"id":id})).unwrap());let mut sent=0usize;loop{if let Some(j)=store.get_job(&id).await{while sent<j.steps.len(){let e=&j.steps[sent];sent+=1;yield Ok(Event::default().event(e.event.clone()).json_data(e).unwrap());}if !matches!(j.status,crate::types::JobStatus::Queued|crate::types::JobStatus::Running){yield Ok(Event::default().event("done").json_data(json!({"status":j.status,"answer":j.answer})).unwrap());break;}}else{yield Ok(Event::default().event("error").json_data(json!({"error":"job not found"})).unwrap());break;}sleep(Duration::from_millis(250)).await;}};
    Sse::new(events).keep_alive(
        KeepAlive::new()
            .interval(Duration::from_secs(15))
            .text("ping"),
    )
}
