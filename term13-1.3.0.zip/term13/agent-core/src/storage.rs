use crate::types::{Job, PendingAction};
use std::{collections::HashMap, sync::Arc};
use tokio::sync::RwLock;

#[derive(Clone, Default)]
pub struct Store {
    pub jobs: Arc<RwLock<HashMap<String, Job>>>,
    pub pending: Arc<RwLock<HashMap<String, PendingAction>>>,
}

impl Store {
    pub async fn insert_job(&self, job: Job) {
        self.jobs.write().await.insert(job.id.clone(), job);
    }
    pub async fn get_job(&self, id: &str) -> Option<Job> {
        self.jobs.read().await.get(id).cloned()
    }
    pub async fn update_job(&self, job: Job) {
        self.jobs.write().await.insert(job.id.clone(), job);
    }
    pub async fn add_pending(&self, action: PendingAction) {
        self.pending.write().await.insert(action.id.clone(), action);
    }
    pub async fn take_pending(&self, id: &str) -> Option<PendingAction> {
        self.pending.write().await.remove(id)
    }
    pub async fn list_pending(&self) -> Vec<PendingAction> {
        self.pending.read().await.values().cloned().collect()
    }
}
