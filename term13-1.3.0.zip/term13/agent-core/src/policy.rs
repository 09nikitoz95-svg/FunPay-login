use crate::config::Config;
use std::path::{Path, PathBuf};

const SECRET_NAMES: &[&str] = &[
    ".env",
    ".env.local",
    ".env.production",
    ".env.development",
    "id_rsa",
    "id_ed25519",
];
const SECRET_EXTENSIONS: &[&str] = &[".pem", ".key", ".p12", ".pfx"];

pub fn normalize_absolute(input: &str) -> Option<PathBuf> {
    if input.is_empty() || input.contains('\0') {
        return None;
    }
    let p = Path::new(input);
    if !p.is_absolute() {
        return None;
    }
    let mut out = PathBuf::new();
    for component in p.components() {
        match component {
            std::path::Component::Prefix(v) => out.push(v.as_os_str()),
            std::path::Component::RootDir => out.push(std::path::MAIN_SEPARATOR_STR),
            std::path::Component::Normal(v) => out.push(v),
            std::path::Component::CurDir => {}
            std::path::Component::ParentDir => {
                if !out.pop() {
                    return None;
                }
            }
        }
    }
    Some(out)
}

pub fn is_secret_path(path: &Path) -> bool {
    let name = path
        .file_name()
        .and_then(|v| v.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    SECRET_NAMES.contains(&name.as_str())
        || name.contains("secret")
        || name.contains("credential")
        || SECRET_EXTENSIONS.iter().any(|ext| name.ends_with(ext))
        || name.ends_with(".env")
}

pub fn is_under(path: &Path, root: &Path) -> bool {
    path == root || path.starts_with(root)
}

pub fn is_writable(path: &Path, cfg: &Config) -> bool {
    let Some(normalized) = normalize_absolute(&path.to_string_lossy()) else {
        return false;
    };
    !is_secret_path(&normalized)
        && cfg
            .writable_roots
            .iter()
            .any(|root| is_under(&normalized, root))
}

pub fn is_allowed_service(name: &str, cfg: &Config) -> bool {
    cfg.allowed_services.iter().any(|s| s == name)
}

pub fn allowed_tool(name: &str) -> bool {
    matches!(
        name,
        "system_status"
            | "disk_memory_status"
            | "service_status"
            | "service_logs"
            | "process_list"
            | "network_listen"
            | "list_directory"
            | "read_project_file"
            | "search_project_files"
            | "write_project_file"
            | "apply_project_patch"
            | "reload_allowed_service"
            | "restart_allowed_service"
            | "ssh_command"
            | "answer"
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::Config;
    #[test]
    fn rejects_relative_and_traversal_paths() {
        assert!(normalize_absolute("relative/file").is_none());
        let root = if cfg!(windows) {
            "C:\\opt\\app\\..\\safe\\file"
        } else {
            "/opt/app/../safe/file"
        };
        assert!(normalize_absolute(root).is_some());
    }
    #[test]
    fn blocks_secret_paths() {
        assert!(is_secret_path(Path::new("/opt/app/.env")));
        assert!(is_secret_path(Path::new("/tmp/server.pem")));
        assert!(!is_secret_path(Path::new("/opt/app/main.rs")));
    }
    #[test]
    fn allows_only_configured_write_roots() {
        let mut c = Config::from_env();
        let root = std::env::temp_dir().join("rr-policy-root");
        c.writable_roots = vec![root.clone()];
        assert!(is_writable(&root.join("src/main.rs"), &c));
        assert!(!is_writable(
            &std::env::temp_dir().join("outside/passwd"),
            &c
        ));
    }
    #[test]
    fn tool_and_service_allowlists_are_closed() {
        assert!(allowed_tool("read_project_file"));
        assert!(!allowed_tool("exec"));
        let mut c = Config::from_env();
        c.allowed_services = vec!["rr-terminal.service".into()];
        assert!(is_allowed_service("rr-terminal.service", &c));
        assert!(!is_allowed_service("ssh.service", &c));
    }
}
