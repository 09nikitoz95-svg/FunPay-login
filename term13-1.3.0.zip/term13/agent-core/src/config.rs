use std::{env, path::PathBuf};

#[derive(Debug, Clone)]
pub struct Config {
    pub bind: String,
    pub ai_url: String,
    pub ai_key: Option<String>,
    pub default_model: String,
    pub fallback_model: String,
    pub max_steps: usize,
    pub max_job_seconds: u64,
    pub max_read_bytes: usize,
    pub max_output_bytes: usize,
    pub pending_seconds: u64,
    pub writable_roots: Vec<PathBuf>,
    pub allowed_services: Vec<String>,
    pub data_dir: PathBuf,
    pub usage_url: Option<String>,
    pub balance_url: Option<String>,
}

impl Config {
    pub fn from_env() -> Self {
        let data_dir = env::var_os("RR_TERM_DATA_DIR")
            .map(PathBuf::from)
            .unwrap_or_else(|| {
                dirs::data_local_dir()
                    .unwrap_or_else(|| PathBuf::from("."))
                    .join("rr-terminal")
            });
        let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
        let writable_roots = env::var("RR_TERM_WRITABLE_ROOTS")
            .map(|v| {
                v.split(';')
                    .map(|p| {
                        let p = PathBuf::from(p);
                        if p.is_absolute() {
                            p
                        } else {
                            cwd.join(p)
                        }
                    })
                    .collect()
            })
            .unwrap_or_else(|_| vec![cwd.join("workspace")]);
        Self {
            bind: env::var("RR_TERM_BIND").unwrap_or_else(|_| "127.0.0.1:7682".into()),
            ai_url: env::var("RR_TERM_AI_URL")
                .unwrap_or_else(|_| "http://127.0.0.1:8767/v1".into()),
            ai_key: env::var("RR_TERM_AI_KEY")
                .ok()
                .filter(|v| !v.trim().is_empty()),
            default_model: env::var("RR_TERM_MODEL").unwrap_or_else(|_| "gpt-5.6-luna".into()),
            fallback_model: env::var("RR_TERM_MODEL_FB").unwrap_or_else(|_| "gpt-5.6-sol".into()),
            max_steps: env::var("RR_TERM_MAX_STEPS")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(4),
            max_job_seconds: env::var("RR_TERM_MAX_JOB_SECONDS")
                .ok()
                .and_then(|v| v.parse().ok())
                .unwrap_or(480),
            max_read_bytes: 512 * 1024,
            max_output_bytes: 120 * 1024,
            pending_seconds: 10 * 60,
            writable_roots,
            allowed_services: env::var("RR_TERM_ALLOWED_SERVICES")
                .unwrap_or_else(|_| "rr-terminal.service;rr-api-proxy.service;caddy.service".into())
                .split(';')
                .map(str::to_owned)
                .collect(),
            data_dir,
            usage_url: env::var("RR_TERM_USAGE_URL").ok(),
            balance_url: env::var("RR_TERM_BALANCE_URL").ok(),
        }
    }
}
