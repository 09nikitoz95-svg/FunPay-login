use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Model {
    pub id: String,
    #[serde(default)]
    pub object: String,
    #[serde(default)]
    pub owned_by: String,
    #[serde(default)]
    pub root: String,
    #[serde(default)]
    pub default: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ModelsResponse {
    pub object: String,
    #[serde(default)]
    pub default_model: Option<String>,
    pub data: Vec<Model>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum JobStatus {
    Queued,
    Running,
    Pending,
    Done,
    Error,
    Aborted,
    StepsLimit,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskRequest {
    pub text: String,
    #[serde(default)]
    pub model: Option<String>,
    #[serde(default)]
    pub role: Option<AgentRole>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, clap::ValueEnum)]
#[serde(rename_all = "lowercase")]
pub enum AgentRole {
    Planner,
    Coder,
    Reviewer,
    Ops,
}

impl Default for AgentRole {
    fn default() -> Self {
        Self::Ops
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskResponse {
    pub ok: bool,
    pub id: String,
    pub queued: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AbortRequest {
    pub id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfirmRequest {
    pub id: String,
    pub hash: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Job {
    pub id: String,
    pub role: AgentRole,
    pub text: String,
    pub model: String,
    pub status: JobStatus,
    pub answer: String,
    pub steps: Vec<ToolEvent>,
    pub abort: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolEvent {
    pub t: u64,
    pub event: String,
    #[serde(default)]
    pub tool: Option<String>,
    #[serde(default)]
    pub payload: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PendingAction {
    pub id: String,
    pub hash: String,
    pub expires_at: u64,
    pub operation: serde_json::Value,
    pub preview: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HistoryResponse {
    pub id: String,
    pub status: JobStatus,
    pub text: String,
    pub answer: String,
    pub steps: Vec<ToolEvent>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolCall {
    pub tool: String,
    #[serde(flatten)]
    pub args: HashMap<String, serde_json::Value>,
}
