use crate::{
    config::Config,
    policy,
    redact::cap,
    storage::Store,
    tools,
    types::{AgentRole, Job, JobStatus, PendingAction, ToolCall, ToolEvent},
};
use anyhow::{anyhow, Result};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc,
    },
    time::Duration,
};
use tokio::{sync::Semaphore, time::timeout};

static IDS: AtomicU64 = AtomicU64::new(1);
fn id() -> String {
    format!("{}-{}", tools::now(), IDS.fetch_add(1, Ordering::Relaxed))
}

#[derive(Clone)]
pub struct Agent {
    pub cfg: Config,
    pub store: Store,
    pub client: Client,
    gate: Arc<Semaphore>,
}

#[derive(Debug, Serialize)]
struct CompletionRequest<'a> {
    model: &'a str,
    messages: &'a [Message],
    max_tokens: u32,
    temperature: f32,
}
#[derive(Debug, Deserialize)]
struct CompletionResponse {
    choices: Vec<Choice>,
}
#[derive(Debug, Deserialize)]
struct Choice {
    message: Message,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
struct Message {
    role: String,
    content: String,
}

const SYSTEM: &str = "You are a safe terminal agent. Use only registered JSON tools. Never output shell commands. Available tools: system_status, service_status, service_logs, process_list, network_listen, disk_memory_status, list_directory, read_project_file, search_project_files, write_project_file, reload_allowed_service, restart_allowed_service, ssh_command, answer. Mutations return pending and require administrator confirmation. Never reveal secrets.";

impl Agent {
    pub fn new(cfg: Config, store: Store) -> Self {
        Self {
            cfg,
            store,
            client: Client::new(),
            gate: Arc::new(Semaphore::new(1)),
        }
    }
    pub async fn submit(
        &self,
        text: String,
        requested_model: Option<String>,
        requested_role: Option<AgentRole>,
    ) -> Result<String> {
        let text = text.trim().chars().take(4000).collect::<String>();
        if text.len() < 2 {
            return Err(anyhow!("empty task"));
        }
        let model = requested_model
            .filter(|m| !m.trim().is_empty())
            .unwrap_or_else(|| self.cfg.default_model.clone());
        let role = requested_role.unwrap_or_default();
        let job = Job {
            id: id(),
            role,
            text,
            model,
            status: JobStatus::Queued,
            answer: String::new(),
            steps: Vec::new(),
            abort: false,
        };
        let jid = job.id.clone();
        let jid_c = jid.clone();
        self.store.insert_job(job).await;
        let this = self.clone();
        tokio::spawn(async move {
            this.run(jid_c).await;
        });
        Ok(jid)
    }
    pub async fn abort(&self, id: &str) -> bool {
        if let Some(mut j) = self.store.get_job(id).await {
            j.abort = true;
            self.store.update_job(j).await;
            true
        } else {
            false
        }
    }
    async fn event(&self, job: &mut Job, event: &str, tool: Option<String>, payload: Value) {
        job.steps.push(ToolEvent {
            t: tools::now(),
            event: event.into(),
            tool,
            payload,
        });
        self.store.update_job(job.clone()).await;
    }
    async fn run(&self, id: String) {
        let permit = self.gate.clone().acquire_owned().await.ok();
        let Some(mut job) = self.store.get_job(&id).await else {
            return;
        };
        job.status = JobStatus::Running;
        self.store.update_job(job.clone()).await;
        let result = timeout(
            Duration::from_secs(self.cfg.max_job_seconds),
            self.loop_job(&mut job),
        )
        .await;
        match result {
            Err(_) => {
                job.status = JobStatus::Error;
                job.answer = "agent timeout".into();
            }
            Ok(Err(e)) => {
                job.status = JobStatus::Error;
                job.answer = cap(&format!("agent error: {e}"), self.cfg.max_output_bytes);
            }
            Ok(Ok(())) => {}
        }
        if matches!(job.status, JobStatus::Running) {
            job.status = JobStatus::StepsLimit;
            job.answer = "step limit reached".into();
        }
        {
            let _st = job.status.clone();
            let _an = job.answer.clone();
            self.event(&mut job, "done", None, json!({"status":_st,"answer":_an}))
        }
        .await;
        drop(permit);
    }
    async fn loop_job(&self, job: &mut Job) -> Result<()> {
        let role_prompt=format!("\nCurrent role: {:?}. Planner decomposes work; Coder edits only after confirmation; Reviewer checks risks; Ops handles diagnostics and approved operations.",job.role);
        let mut messages = vec![
            Message {
                role: "system".into(),
                content: format!("{SYSTEM}{role_prompt}"),
            },
            Message {
                role: "user".into(),
                content: job.text.clone(),
            },
        ];
        for _ in 0..self.cfg.max_steps {
            if self
                .store
                .get_job(&job.id)
                .await
                .map(|j| j.abort)
                .unwrap_or(false)
            {
                job.status = JobStatus::Aborted;
                job.answer = "aborted".into();
                return Ok(());
            }
            let raw = match self.ask(&messages, &job.model).await {
                Ok(v) => v,
                Err(e) if job.model != self.cfg.fallback_model => {
                    job.model = self.cfg.fallback_model.clone();
                    self.ask(&messages, &job.model).await?
                }
                Err(e) => return Err(e),
            };
            let Some(call) = parse_tool_call(&raw) else {
                if !raw.trim().is_empty() {
                    job.answer = cap(raw.trim(), 20_000);
                    job.status = JobStatus::Done;
                    self.event(job, "answer", None, json!({"text":job.answer}))
                        .await;
                    return Ok(());
                }
                messages.push(Message {
                    role: "assistant".into(),
                    content: raw,
                });
                messages.push(Message {
                    role: "user".into(),
                    content: "Return one valid JSON tool call.".into(),
                });
                continue;
            };
            if call.tool == "answer" {
                job.answer = arg_string(&call, "text").unwrap_or_default();
                job.status = JobStatus::Done;
                self.event(job, "answer", Some(call.tool), json!({"text":job.answer}))
                    .await;
                return Ok(());
            }
            if !policy::allowed_tool(&call.tool) {
                self.event(
                    job,
                    "error",
                    Some(call.tool),
                    json!({"error":"tool denied"}),
                )
                .await;
                messages.push(Message {
                    role: "user".into(),
                    content: "Tool denied. Use answer.".into(),
                });
                continue;
            }
            let result = self.dispatch(&call).await?;
            let pending = result
                .get("pending")
                .and_then(Value::as_bool)
                .unwrap_or(false);
            self.event(
                job,
                if pending { "pending" } else { "result" },
                Some(call.tool.clone()),
                result.clone(),
            )
            .await;
            if pending {
                job.status = JobStatus::Pending;
                job.answer = "awaiting administrator confirmation".into();
                return Ok(());
            }
            messages.push(Message {
                role: "assistant".into(),
                content: raw,
            });
            messages.push(Message {
                role: "user".into(),
                content: format!(
                    "RESULT: {}",
                    cap(&result.to_string(), self.cfg.max_output_bytes)
                ),
            });
        }
        Ok(())
    }
    async fn ask(&self, messages: &[Message], model: &str) -> Result<String> {
        let url = format!("{}/chat/completions", self.cfg.ai_url.trim_end_matches('/'));
        let mut req = self.client.post(url).json(&CompletionRequest {
            model,
            messages,
            max_tokens: 2400,
            temperature: 0.2,
        });
        if let Some(k) = &self.cfg.ai_key {
            req = req.bearer_auth(k);
        }
        let r = req.send().await?;
        if !r.status().is_success() {
            return Err(anyhow!("LLM HTTP {}", r.status()));
        }
        let body: CompletionResponse = r.json().await?;
        body.choices
            .first()
            .map(|c| c.message.content.clone())
            .ok_or_else(|| anyhow!("empty model response"))
    }
    async fn dispatch(&self, call: &ToolCall) -> Result<Value> {
        let arg = |name| call.args.get(name).cloned().unwrap_or(Value::Null);
        match call.tool.as_str() {
            "list_directory" => Ok(tools::list_dir(arg("path").as_str().unwrap_or("/")).await),
            "read_project_file" => Ok(tools::read_file(
                arg("path").as_str().unwrap_or(""),
                &self.cfg,
                arg("max_bytes").as_u64().unwrap_or(65536) as usize,
            )
            .await),
            "search_project_files" => Ok(tools::search_files(
                arg("path").as_str().unwrap_or("/"),
                arg("query").as_str().unwrap_or(""),
                &self.cfg,
            )
            .await),
            "system_status" | "disk_memory_status" => Ok(
                json!({"ok":true,"system":tools::fixed_command("uname",&[],Duration::from_secs(10),self.cfg.max_output_bytes).await,"disk":tools::fixed_command("df",&["-h".into(),"/".into()],Duration::from_secs(10),self.cfg.max_output_bytes).await}),
            ),
            "process_list" => Ok(tools::fixed_command(
                "ps",
                &["-eo".into(), "pid,user,stat,pcpu,pmem,comm,args".into()],
                Duration::from_secs(20),
                self.cfg.max_output_bytes,
            )
            .await),
            "network_listen" => Ok(tools::fixed_command(
                "ss",
                &["-lntup".into()],
                Duration::from_secs(20),
                self.cfg.max_output_bytes,
            )
            .await),
            "service_status" => {
                self.service_read(
                    "systemctl",
                    &[
                        "status".into(),
                        arg_string(call, "service").unwrap_or_default(),
                        "--no-pager".into(),
                    ],
                )
                .await
            }
            "service_logs" => {
                self.service_read(
                    "journalctl",
                    &[
                        "-u".into(),
                        arg_string(call, "service").unwrap_or_default(),
                        "-n".into(),
                        arg("lines").as_u64().unwrap_or(80).min(300).to_string(),
                        "--no-pager".into(),
                    ],
                )
                .await
            }
            "write_project_file" | "apply_project_patch" => {
                let path = arg_string(call, "path").unwrap_or_default();
                let content = arg_string(call, "content").unwrap_or_default();
                self.preview_write(
                    &path,
                    &content,
                    arg_string(call, "note").unwrap_or_default(),
                )
                .await
            }
            "reload_allowed_service" | "restart_allowed_service" => {
                self.preview_service(&call.tool, arg_string(call, "service").unwrap_or_default())
                    .await
            }
            "ssh_command" => {
                let host = arg_string(call, "host").unwrap_or_default();
                let user = arg_string(call, "user").unwrap_or_default();
                let port = arg("port").as_u64().unwrap_or(22) as u16;
                let command = arg("command")
                    .as_array()
                    .cloned()
                    .unwrap_or_default()
                    .into_iter()
                    .filter_map(|v| v.as_str().map(str::to_owned))
                    .collect::<Vec<_>>();
                Ok(tools::ssh_command(
                    &host,
                    &user,
                    port,
                    None,
                    &command,
                    self.cfg.max_output_bytes,
                )
                .await)
            }
            _ => Err(anyhow!("unsupported tool")),
        }
    }
    async fn service_read(&self, program: &str, args: &[String]) -> Result<Value> {
        let service = args.get(1).cloned().unwrap_or_default();
        if !policy::is_allowed_service(&service, &self.cfg) {
            return Ok(json!({"ok":false,"error":"service denied"}));
        }
        Ok(tools::fixed_command(
            program,
            args,
            Duration::from_secs(30),
            self.cfg.max_output_bytes,
        )
        .await)
    }
    async fn preview_write(&self, path: &str, content: &str, note: String) -> Result<Value> {
        let p = policy::normalize_absolute(path).ok_or_else(|| anyhow!("invalid path"))?;
        if !policy::is_writable(&p, &self.cfg) {
            return Ok(json!({"ok":false,"error":"write denied"}));
        }
        let op = json!({"kind":"write","path":p,"content":content,"note":note});
        self.pending(op).await
    }
    async fn preview_service(&self, kind: &str, service: String) -> Result<Value> {
        if !policy::is_allowed_service(&service, &self.cfg) {
            return Ok(json!({"ok":false,"error":"service denied"}));
        }
        self.pending(json!({"kind":if kind.starts_with("restart"){"restart"}else{"reload"},"service":service})).await
    }
    async fn pending(&self, operation: Value) -> Result<Value> {
        let hash = tools::operation_hash(&operation);
        let action = PendingAction {
            id: id(),
            hash: hash.clone(),
            expires_at: tools::now() + self.cfg.pending_seconds,
            preview: operation.clone(),
            operation,
        };
        let v = json!({"ok":true,"pending":true,"id":action.id,"hash":hash,"expires_at":action.expires_at,"preview":action.preview});
        self.store.add_pending(action).await;
        Ok(v)
    }
    pub async fn confirm(&self, id: &str, hash: &str) -> Result<Value> {
        let Some(action) = self.store.take_pending(id).await else {
            return Ok(json!({"ok":false,"error":"operation not found"}));
        };
        if action.expires_at < tools::now() {
            return Ok(json!({"ok":false,"error":"confirmation expired"}));
        }
        if action.hash != hash {
            return Ok(json!({"ok":false,"error":"operation hash mismatch"}));
        }
        let op = action.operation;
        match op.get("kind").and_then(Value::as_str) {
            Some("write") => {
                tools::atomic_write(
                    op["path"].as_str().unwrap_or(""),
                    op["content"].as_str().unwrap_or(""),
                    &self.cfg,
                )
                .await
            }
            Some("reload") | Some("restart") => {
                let svc = op["service"].as_str().unwrap_or("");
                if !policy::is_allowed_service(svc, &self.cfg) {
                    return Ok(json!({"ok":false,"error":"service denied"}));
                }
                Ok(tools::fixed_command(
                    "systemctl",
                    &[op["kind"].as_str().unwrap().into(), svc.into()],
                    Duration::from_secs(60),
                    self.cfg.max_output_bytes,
                )
                .await)
            }
            _ => Ok(json!({"ok":false,"error":"unknown operation"})),
        }
    }
}

fn arg_string(call: &ToolCall, name: &str) -> Option<String> {
    call.args
        .get(name)
        .and_then(Value::as_str)
        .map(str::to_owned)
}
fn parse_tool_call(raw: &str) -> Option<ToolCall> {
    let a = raw.find('{')?;
    let b = raw.rfind('}')?;
    serde_json::from_str(&raw[a..=b]).ok()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn parses_json_tool_call_embedded_in_text() {
        let c = parse_tool_call("prefix {\"tool\":\"answer\",\"text\":\"ok\"}").unwrap();
        assert_eq!(c.tool, "answer");
    }
    #[test]
    fn malformed_tool_is_rejected() {
        assert!(parse_tool_call("not json").is_none());
    }
}
