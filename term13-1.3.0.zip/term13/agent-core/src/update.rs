//! Remote self-update: manifest check + verified in-place binary replacement.
//! Manifest shape: version + per-platform file list with URL, sha256 and size.

use anyhow::{anyhow, Context, Result};
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::path::PathBuf;

pub const DEFAULT_MANIFEST_URL: &str =
    "https://riskradarai.ru/app/releases/rust/latest-rust.json";

#[derive(Debug, Deserialize)]
pub struct ManifestFile {
    pub name: String,
    pub url: String,
    pub sha256: String,
    pub size: u64,
}

#[derive(Debug, Deserialize)]
pub struct Manifest {
    pub version: String,
    pub files: HashMap<String, Vec<ManifestFile>>,
}

pub fn platform_key() -> String {
    let os = match std::env::consts::OS {
        "windows" => "windows",
        "macos" => "macos",
        _ => "linux",
    };
    format!("{os}-{}", std::env::consts::ARCH)
}

pub fn current_version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

pub fn parse_version(s: &str) -> Result<(u64, u64, u64)> {
    let mut it = s.trim().trim_start_matches('v').split('.');
    let major: u64 = it
        .next()
        .ok_or_else(|| anyhow!("bad version {s}"))?
        .parse()?;
    let minor: u64 = it.next().unwrap_or("0").parse()?;
    let patch: u64 = it.next().unwrap_or("0").parse()?;
    Ok((major, minor, patch))
}

pub fn is_newer(current: &str, latest: &str) -> bool {
    match (parse_version(current), parse_version(latest)) {
        (Ok(c), Ok(l)) => l > c,
        _ => latest.trim() != current.trim(),
    }
}

pub fn sha256_hex(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

pub async fn fetch_manifest(client: &reqwest::Client, url: &str) -> Result<Manifest> {
    let resp = client.get(url).send().await.context("manifest request")?;
    if !resp.status().is_success() {
        return Err(anyhow!("manifest HTTP {}", resp.status()));
    }
    resp.json::<Manifest>().await.context("manifest parse")
}

fn install_dir() -> Result<PathBuf> {
    let exe = std::env::current_exe().context("current exe path")?;
    exe.parent()
        .map(|p| p.to_path_buf())
        .ok_or_else(|| anyhow!("no parent dir"))
}

fn replace_file(dir: &std::path::Path, name: &str, bytes: &[u8]) -> Result<String> {
    if name.contains('/') || name.contains('\\') || name.contains("..") {
        return Err(anyhow!("unsafe file name {name}"));
    }
    let target = dir.join(name);
    let staged = dir.join(format!("{name}.new"));
    std::fs::write(&staged, bytes).context("stage update")?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(&staged, std::fs::Permissions::from_mode(0o755));
    }
    if std::fs::rename(&staged, &target).is_ok() {
        return Ok(format!("{name}: updated"));
    }
    let aside = dir.join(format!("{name}.old"));
    let _ = std::fs::remove_file(&aside);
    std::fs::rename(&target, &aside).context("move current aside")?;
    std::fs::rename(&staged, &target).context("move staged in place")?;
    Ok(format!("{name}: updated, restart to use the new binary"))
}

pub async fn check(client: &reqwest::Client, manifest_url: &str) -> Result<String> {
    let m = fetch_manifest(client, manifest_url).await?;
    let cur = current_version();
    let key = platform_key();
    let n = m.files.get(&key).map(|v| v.len()).unwrap_or(0);
    if is_newer(cur, &m.version) {
        Ok(format!(
            "update available: {cur} -> {} (platform {key}, {n} files)",
            m.version
        ))
    } else {
        Ok(format!("up to date: {cur} (platform {key})"))
    }
}

pub async fn apply(client: &reqwest::Client, manifest_url: &str) -> Result<String> {
    let m = fetch_manifest(client, manifest_url).await?;
    let cur = current_version();
    if !is_newer(cur, &m.version) {
        return Ok(format!("already up to date: {cur}"));
    }
    let key = platform_key();
    let files = m
        .files
        .get(&key)
        .ok_or_else(|| anyhow!("no files for platform {key}"))?;
    if files.is_empty() {
        return Err(anyhow!("empty file list for platform {key}"));
    }
    let dir = install_dir()?;
    let mut out = vec![format!(
        "updating {cur} -> {} in {}",
        m.version,
        dir.display()
    )];
    for f in files {
        let bytes = client
            .get(&f.url)
            .send()
            .await
            .with_context(|| format!("download {}", f.name))?
            .error_for_status()?
            .bytes()
            .await?;
        if bytes.len() as u64 != f.size {
            return Err(anyhow!("size mismatch for {}", f.name));
        }
        let sum = sha256_hex(&bytes);
        if sum != f.sha256.to_lowercase() {
            return Err(anyhow!("sha256 mismatch for {}", f.name));
        }
        out.push(replace_file(&dir, &f.name, &bytes)?);
    }
    out.push("done - restart running binaries to use the new version".to_string());
    Ok(out.join("\n"))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn parses_versions() {
        assert_eq!(parse_version("0.1.0").unwrap(), (0, 1, 0));
        assert_eq!(parse_version("v1.2.3").unwrap(), (1, 2, 3));
        assert_eq!(parse_version("2.0").unwrap(), (2, 0, 0));
    }
    #[test]
    fn compares_versions() {
        assert!(is_newer("0.1.0", "0.1.1"));
        assert!(is_newer("0.1.9", "0.2.0"));
        assert!(!is_newer("0.1.1", "0.1.1"));
        assert!(!is_newer("0.2.0", "0.1.9"));
    }
    #[test]
    fn hashes_stable() {
        assert_eq!(
            sha256_hex(b"abc"),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
    }
}
