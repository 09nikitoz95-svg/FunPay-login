pub fn redact(input: &str) -> String {
    let mut out = input.to_owned();
    for marker in [
        "Bearer ",
        "sk-",
        "password=",
        "token=",
        "api_key=",
        "VC_MASTER_KEY=",
    ] {
        let mut start = 0;
        while let Some(pos) = out[start..].find(marker) {
            let absolute = start + pos;
            let tail = absolute + marker.len();
            let end = out[tail..]
                .find(|c: char| c.is_whitespace() || c == '"' || c == '\'' || c == ',')
                .map(|v| tail + v)
                .unwrap_or(out.len());
            let replacement = format!("{}[REDACTED]", marker);
            out.replace_range(absolute..end, &replacement);
            start = absolute + replacement.len();
            if start >= out.len() {
                break;
            }
        }
    }
    out
}

pub fn cap(input: &str, max: usize) -> String {
    let safe = redact(input);
    if safe.len() <= max {
        safe
    } else {
        let end = safe
            .char_indices()
            .take_while(|(i, _)| *i < max)
            .map(|(i, _)| i)
            .last()
            .unwrap_or(0);
        format!("{}\n…[truncated]", &safe[..end])
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn redacts_common_secrets() {
        let s = redact("Authorization: Bearer abc123 api_key=xyz password=hunter2");
        assert!(!s.contains("abc123"));
        assert!(!s.contains("hunter2"));
        assert!(s.contains("[REDACTED]"));
    }
    #[test]
    fn caps_output() {
        assert!(cap("abcdef", 3).len() < 30);
    }
}
