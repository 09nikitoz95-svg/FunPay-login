use crate::{config::Config, policy, redact::cap, types::PendingAction};
use anyhow::{anyhow, Result};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    path::{Path, PathBuf},
    process::Stdio,
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use tokio::{fs, io::AsyncWriteExt, process::Command, time::timeout};

pub async fn fixed_command(
    program: &str,
    args: &[String],
    limit: Duration,
    max_output: usize,
) -> Value {
    let mut command = Command::new(program);
    command
        .args(args)
        .env_clear()
        .env(
            "PATH",
            if cfg!(windows) {
                std::env::var("PATH").unwrap_or_default()
            } else {
                "/usr/sbin:/usr/bin:/sbin:/bin".to_string()
            },
        )
        .env("LC_ALL", "C")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .kill_on_drop(true);
    if !cfg!(windows) {
        command.current_dir("/");
    }
    let child = command.spawn();
    let Ok(child) = child else {
        return json!({"exit":-1,"out":"spawn failed"});
    };
    match timeout(limit, child.wait_with_output()).await {
        Ok(Ok(out)) => {
            let mut data = out.stdout;
            data.extend(out.stderr);
            json!({"exit":out.status.code().unwrap_or(-1),"out":cap(&String::from_utf8_lossy(&data), max_output)})
        }
        Ok(Err(e)) => json!({"exit":-1,"out":cap(&e.to_string(), max_output)}),
        Err(_) => json!({"exit":124,"out":"[timeout]"}),
    }
}

pub async fn read_file(path: &str, cfg: &Config, max: usize) -> Value {
    let Some(p) = policy::normalize_absolute(path) else {
        return json!({"ok":false,"error":"invalid absolute path"});
    };
    if policy::is_secret_path(&p) || max > cfg.max_read_bytes {
        return json!({"ok":false,"error":"path or size denied"});
    }
    match fs::metadata(&p).await {
        Ok(m) if m.len() as usize <= cfg.max_read_bytes => match fs::read(&p).await {
            Ok(b) => json!({"ok":true,"path":p,"text":cap(&String::from_utf8_lossy(&b),max)}),
            Err(e) => json!({"ok":false,"error":e.to_string()}),
        },
        Ok(_) => json!({"ok":false,"error":"file too large"}),
        Err(e) => json!({"ok":false,"error":e.to_string()}),
    }
}

pub async fn list_dir(path: &str) -> Value {
    let Some(p) = policy::normalize_absolute(path) else {
        return json!({"ok":false,"error":"invalid path"});
    };
    let Ok(mut rd) = fs::read_dir(&p).await else {
        return json!({"ok":false,"error":"directory unavailable"});
    };
    let mut entries = Vec::new();
    while let Ok(Some(e)) = rd.next_entry().await {
        if entries.len() >= 300 {
            break;
        }
        let ty = e.file_type().await.ok();
        entries.push(json!({"name":e.file_name(),"type":if ty.as_ref().is_some_and(|t|t.is_dir()){"dir"}else if ty.as_ref().is_some_and(|t|t.is_file()){"file"}else{"other"}}));
    }
    json!({"ok":true,"path":p,"entries":entries})
}

pub async fn search_files(root: &str, needle: &str, cfg: &Config) -> Value {
    if needle.is_empty() || needle.len() > 160 {
        return json!({"ok":false,"error":"invalid query"});
    }
    let Some(root) = policy::normalize_absolute(root) else {
        return json!({"ok":false,"error":"invalid root"});
    };
    let mut stack = vec![root];
    let mut matches = Vec::new();
    while let Some(dir) = stack.pop() {
        if matches.len() >= 100 {
            break;
        }
        let Ok(mut rd) = fs::read_dir(&dir).await else {
            continue;
        };
        while let Ok(Some(e)) = rd.next_entry().await {
            if matches.len() >= 100 {
                break;
            }
            let name = e.file_name().to_string_lossy().into_owned();
            if name.starts_with('.')
                || ["node_modules", "target", "__pycache__"].contains(&name.as_str())
            {
                continue;
            }
            let Ok(ty) = e.file_type().await else {
                continue;
            };
            let p = e.path();
            if ty.is_dir() {
                stack.push(p)
            } else if ty.is_file() {
                if let Ok(m) = e.metadata().await {
                    if m.len() as usize <= cfg.max_read_bytes && !policy::is_secret_path(&p) {
                        if let Ok(t) = fs::read_to_string(&p).await {
                            if let Some(i) = t.find(needle) {
                                matches.push(json!({"path":p,"sample":cap(&t[i.saturating_sub(120)..t.len().min(i+needle.len()+240)],500)}));
                            }
                        }
                    }
                }
            }
        }
    }
    json!({"ok":true,"matches":matches})
}

pub async fn atomic_write(path: &str, content: &str, cfg: &Config) -> Result<Value> {
    let p = policy::normalize_absolute(path).ok_or_else(|| anyhow!("invalid path"))?;
    if !policy::is_writable(&p, cfg) {
        return Err(anyhow!("write denied"));
    }
    if content.len() > 1024 * 1024 {
        return Err(anyhow!("file too large"));
    }
    if let Some(parent) = p.parent() {
        fs::create_dir_all(parent).await?;
    }
    let old = fs::read_to_string(&p).await.unwrap_or_default();
    let backup = PathBuf::from(format!("{}.pre-safe-agent-{}", p.display(), now()));
    if !old.is_empty() {
        fs::copy(&p, &backup).await.ok();
    }
    let tmp = PathBuf::from(format!("{}.tmp-{}", p.display(), now()));
    let mut f = fs::File::create(&tmp).await?;
    f.write_all(content.as_bytes()).await?;
    f.flush().await?;
    fs::rename(&tmp, &p).await?;
    Ok(
        json!({"ok":true,"path":p,"backup":if backup.exists(){Some(backup)}else{None::<PathBuf>},"bytes":content.len()}),
    )
}

pub fn operation_hash(operation: &Value) -> String {
    let mut h = Sha256::new();
    h.update(serde_json::to_vec(operation).unwrap_or_default());
    format!("{:x}", h.finalize())
}
pub fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

pub async fn ssh_command(
    host: &str,
    user: &str,
    port: u16,
    key: Option<&Path>,
    command: &[String],
    max_output: usize,
) -> Value {
    let mut args = vec![
        "-o".into(),
        "BatchMode=yes".into(),
        "-o".into(),
        "StrictHostKeyChecking=yes".into(),
        "-p".into(),
        port.to_string(),
    ];
    if let Some(k) = key {
        args.push("-i".into());
        args.push(k.to_string_lossy().into_owned());
    }
    args.push(format!("{}@{}", user, host));
    args.extend(command.iter().cloned());
    fixed_command("ssh", &args, Duration::from_secs(60), max_output).await
}

pub async fn sftp_upload(
    host: &str,
    user: &str,
    port: u16,
    key: Option<&Path>,
    local: &Path,
    remote: &str,
) -> Value {
    let mut args = vec![
        "-o".into(),
        "BatchMode=yes".into(),
        "-o".into(),
        "StrictHostKeyChecking=yes".into(),
        "-P".into(),
        port.to_string(),
    ];
    if let Some(k) = key {
        args.push("-i".into());
        args.push(k.to_string_lossy().into_owned());
    }
    args.push(local.to_string_lossy().into_owned());
    args.push(format!("{}@{}:{}", user, host, remote));
    fixed_command("sftp", &args, Duration::from_secs(120), 120 * 1024).await
}
