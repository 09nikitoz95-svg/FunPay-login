(function() {
  'use strict';
  if (window.rrapi) return;
  
  function getTauri() {
    return window.__TAURI__ || {};
  }

  function getInvoke() {
    const t = getTauri();
    if (t.core && typeof t.core.invoke === 'function') return t.core.invoke;
    if (typeof t.invoke === 'function') return t.invoke;
    if (window.__TAURI_INTERNALS__ && typeof window.__TAURI_INTERNALS__.invoke === 'function') {
      return window.__TAURI_INTERNALS__.invoke;
    }
    return null;
  }

  function getListen() {
    const t = getTauri();
    if (t.event && typeof t.event.listen === 'function') return t.event.listen;
    return null;
  }

  window.rrapi = {
    invoke: function(channel, payload) {
      const inv = getInvoke();
      if (!inv) {
        return Promise.reject(new Error('Tauri IPC not initialized'));
      }
      return inv('rrapi_invoke', { channel: channel, payload: payload || {} });
    },
    on: function(channel, cb) {
      const lis = getListen();
      if (!lis) {
        console.warn('Tauri event listener not available for channel:', channel);
        return function() {};
      }
      var unlistenFn = null;
      var active = true;
      lis(channel, function(e) {
        if (!active) return;
        try { cb(e.payload); } catch (err) { console.error('Error in listener for ' + channel + ':', err); }
      }).then(function(fn) {
        unlistenFn = fn;
      }).catch(function(err) {
        console.error('Failed to listen to ' + channel + ':', err);
      });
      return function() {
        active = false;
        if (unlistenFn) {
          try { unlistenFn(); } catch (e) {}
        }
      };
    },
    pathForFile: function(file) {
      return (file && file.path) || null;
    }
  };
})();
