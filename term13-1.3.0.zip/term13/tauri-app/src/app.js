/* ============ RiskRadar Terminal — renderer ============ */
'use strict';

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

const rr = window.rrapi;
let db = { settings: {}, chats: [], sshProfiles: [] };
const S = () => db.settings;
let models = [];
let modelMeta = {};
// 1.2.84 V-MODELS-RESILIENT: список не должен «исчезать» молча — ошибка видна, авто-повтор
let modelsLastError = null; let modelsRetryCount = 0; let modelsRetryTimer = null;
function scheduleModelsRetry() {
  if (modelsRetryTimer || models.length) return;
  const delays = [8000, 15000, 30000, 60000, 60000, 60000, 120000, 120000, 300000, 300000];
  const d = delays[Math.min(modelsRetryCount, delays.length - 1)];
  modelsRetryCount++;
  modelsRetryTimer = setTimeout(() => { modelsRetryTimer = null; if (!models.length) { try { loadModels(true); } catch (e) {} } }, d);
}
let currentChatId = null;
let streaming = null;        // { reqId, chatId }
const streamsByChat = new Map(); // V-MULTICHAT: параллельные стримы по чатам
try { globalThis.__streamsByChat = streamsByChat; } catch (e) {}
let saveTimer = null;
let pendingAttachments = [];
let sshSession = null;       // { id, term, fit, profile }
let currentPreviewFile = null;
let homeDirCache = '';
let codeEditState = null;
let aiSshSession = null;
let aiSshPending = null;
let turnFilePaths = [];      // V-FILEONCE: пути файлов за текущий ответ — одна сводка в конце
let balanceRefreshTimer = null;
let localWriteBridgeBlocked = false;
let topupState = { tab: 'sbp', min: null, dirs: null, busy: false, error: '', sbp: null, crypto: null, rub: 500, usd: 10, network: '', authHint: '' };
let topupPollTimer = null;

/* ------------------------------ i18n ------------------------------ */

const I18N = {
  ru: {
    newChat: 'Новый чат', searchChats: 'Поиск по чатам…', files: 'Файлы', settings: 'Настройки',
    export: 'Экспорт', exportChat: 'Экспорт чата в Markdown', theme: 'Сменить тему', closePanel: 'Закрыть панель',
    welcomeSub: 'Ваш AI-терминал: модели RiskRadar, файлы на вашем ПК и SSH — в одном окне.',
    keyPlaceholder: 'Вставьте ваш ключ (sk-smart-…)', connect: 'Подключить',
    keyHint: 'Ключ выдаётся в личном кабинете', keyLocal: 'Он хранится только на вашем ПК.',
    card1t: '💬 Чат с моделями', card1d: 'GPT-5.6, Claude, GPT-6-Astra и другие — со стримингом и markdown',
    card2t: '📁 Файлы ПК', card2d: 'ИИ читает и создаёт файлы в рабочем каталоге, сохраняет ответы',
    card3t: '🖥 SSH', card3d: 'ИИ выполняет команды на ваших серверах + терминал и SFTP',
    composerPh: 'Спросите что угодно… (Enter — отправить, Shift+Enter — новая строка)',
    attach: 'Прикрепить файл', send: 'Отправить', stopGen: 'Остановить',
    workdirTitle: 'Рабочий каталог терминала (файлы, доступные ИИ)',
    localFiles: '📁 Локальные файлы', pickDir: 'Выбрать папку', up: 'Вверх', up2: 'Вверх', home: 'Домашняя папка', home2: 'Дом', refresh: 'Обновить',
    name: 'Название', host: 'Хост', port: 'Порт', login: 'Логин', authType: 'Тип авторизации',
    password: 'Пароль', privKey: 'Закрытый ключ', password2: 'Пароль', keyFile: 'Файл ключа', keyPass: 'Пароль ключа',
    saveConn: 'Сохранить подключение в списке', connect2: 'Подключиться', disconnect: 'Отключить', disconnect2: 'Отключить',
    toTerminal: 'К терминалу', terminal: 'Терминал', uploadFile: 'Загрузить файл на сервер', upload: 'Загрузить',
    settings2: 'Настройки', baseUrl: 'Base URL шлюза', lockedByAdmin: 'Зафиксировано администратором',
    clientKey: 'Ключ клиента (sk-smart-…)', show: 'Показать', check: 'Проверить',
    defaultModel: 'Модель по умолчанию', refreshModels: 'Обновить список моделей', sysPrompt: 'Системный промпт',
    historyLimit: 'История (сообщений):',
    maxRounds: 'Раундов агента (шагов чтения):', maxTokens: 'Лимит длины ответа (0 — авто):',
    roundsNote: 'Агент читает файлы проекта по кругу: запрос → чтение → следующий запрос. Если кругов не хватило — напишите «дальше», и он продолжит с того же места.',
    trimWarn: 'Память переполнена: {n} старых сообщений не влезло в контекст и скрыто от модели. Задача закреплена, но детали могли потеряться.',
    roundsExhausted: 'Достигнут лимит раундов агента ({n}): чтение файлов остановлено. Напишите «дальше» — продолжу с того же места.',
    docxDone: 'DOCX готов', docxBtn: 'Скачать в DOCX', sendImages: 'Отправлять изображения моделям (vision)',
    theme2: 'Тема', themeDark: 'Тёмная', themeLight: 'Светлая', language: 'Язык интерфейса',
    updates: 'Обновления', checkNow: 'Проверить сейчас', save: 'Сохранить', close: 'Закрыть',
    open: 'Открыть', showInFolder: 'Показать в папке', attachToChat: 'Прикрепить к чату',
    chooseLangSelf: 'Choose interface language / Выберите язык интерфейса',
    // динамические
    noKey: 'Нет ключа', keyActive: 'Ключ активен', generating: 'Генерация…', reconnecting: 'Переподключение…', reasonTitle: 'Размышление',
    lpWaiting: 'жду ответа модели', lpThinking: 'модель думает', lpWriting: 'пишу ответ',
    applyToFile: 'Применить к файлу', applyDone: 'Применено к файлу', modelSwitched: 'Модель переключена',
    mCopy: 'Копировать', mRegen: 'Заново', mDel: 'Удалить', mSave: 'В файл',
    execSsh: 'Генерация…', execFile: 'Генерация…',
    noChats: 'Чатов пока нет', emptyFolder: 'Папка пуста', emptyDir: 'Пусто',
    settingsSaved: 'Настройки сохранены', copied: 'Скопировано',
    fileAttached: 'Файл прикреплён', filesAttached: 'Файлы прикреплены',
    keyOk: 'Ключ принят ✓', keyBad: 'Ключ не принят шлюзом. Проверьте его в кабинете.',
    needKeyFirst: 'Сначала укажите ключ клиента в настройках', enterKey: 'Вставьте ключ',
    sshErr: 'Ошибка связи: ', balanceTitle: 'Баланс ключа', balanceTokens: 'токенов',
    exportDone: 'Экспортировано', chatEmpty: 'Чат пуст', stoppedNote: '_(остановлено)_', resumingNote: '_(восстанавливаю соединение…)_',
  runDone: 'Готово', runError: 'Ошибка', runStopped: 'Остановлено',
    emptyReply: 'Пустой ответ модели. Попробуйте ещё раз или смените модель.',
    workdirHome: '~', codeSearch: 'Код', codeSearchLabel: 'Что найти',
    codeSearchNote: 'Ищет в последнем коде текущего чата и в локальной рабочей папке, показывает совпадения и открывает нужный кусок.',
    codeSearchFound: 'Найдено совпадений: ', codeSearchNone: 'Совпадения не найдены', codeSearchRun: 'Найти',
    codeOpenSnippet: 'Фрагмент', codeOpenFile: 'Открыть файл', titleSaved: 'Название чата обновлено',
    codeEdit: 'Редактор кода', codeEditPath: 'Файл для сохранения', codeEditPathNote: 'Можно сохранить как новый файл или перезаписать файл в рабочей папке.',
    codeEditContent: 'Код', codeEditAction: 'Редактировать', codeSave: 'Сохранить', codeSaveAs: 'Сохранить как…', codeSaved: 'Код сохранён: ',
    updatesNone: 'Обновлений нет', updatesUiRestart: 'Найдено обновление UI — перезапустите терминал', updatesAppAvail: 'Найдена новая версия приложения: ',
    remoteNeedsSsh: 'Для правки удалённого файла сначала подключитесь по SSH', remoteSaved: 'Удалённый файл сохранён: ',
    tokenShield: 'TokenShield — локально сжимать текст/код перед отправкой',
    tddMode: 'TDD-режим: сначала тесты (модель пишет и запускает тесты до правки кода)',
    webSearch: 'Веб-поиск (модель ищет в интернете)',
    shellExec: 'Выполнять команды на этом ПК (как Codex / Claude Code)',
    shellAuto: 'Не спрашивать подтверждение перед каждой командой (авто-режим)',
    shellNote: 'Команды запускаются в вашем login-shell (на macOS — с PATH из Terminal, поэтому brew/nvm/pyenv доступны). Требуется обновлённая оболочка терминала.',
    tokenShieldNote: 'Без ИИ: нормализует вложения и код, убирает лишние пустые строки и пробелы, чтобы экономить токены.',
    modelCatalog: 'Каталог моделей', modelCatalogNote: 'Группы моделей, поиск и стоимость. Для текстовых моделей — коэффициент ×, для генерации картинок — токены за одну картинку.', support: 'Поддержка',
  chatWeight: 'Лимит веса чата (токенов контекста)', chatWeightNow: 'Сейчас в этом чате:', openFolder: 'Открыть', browser: 'Браузер',
  pinChat: 'Закрепить чат', unpinChat: 'Снять закрепление', chatPinned: 'Чат закреплён', chatUnpinned: 'Чат откреплён',
  chatWeightNote: 'Лимит веса из настроек убран (1.2.98): бюджет контекста считается автоматически от окна модели, чат не блокируется при достижении лимита — старые сообщения мягко сжимаются, на диске остаются все.',
  chatsStorage: 'Хранилище чатов', chatsStorageNote: 'Все чаты хранятся только на этом компьютере и на сервер не уходят. Запись атомарная, предыдущая версия остаётся как db.json.bak.',
    topupTitle: 'Пополнение баланса', topupOpenSite: 'Открыть оплату на сайте', topupAuthRequired: 'Для создания оплаты нужен действующий API-ключ или вход в аккаунт RiskRadar.',
    topupSbp: 'СБП · ЮKassa', topupCrypto: 'Крипта · USDT', topupPay: 'Оплатить', topupGetAddress: 'Получить адрес',
    topupCreating: 'Создаём платёж…', topupCreatingInvoice: 'Создаём инвойс…', topupOpenPay: 'Перейти к оплате →', topupShowQr: 'Показать QR-код', topupCopy: 'Копировать', topupCopied: 'Скопировано ✓',
    faOpen: 'Открыть файл', faFolder: 'Показать в папке', faAttach: 'Прикрепить', faBadPath: 'Файл не найден или путь указан неверно:', faDirAttached: 'Папка прикреплена списком',
    setApiKey: 'API-ключ', setModel: 'Модель', setWeight: 'Вес чата для модели (символов)',
    setTheme: 'Тема оформления', setLang: 'Язык интерфейса', setSkills: 'Навыки (skills с GitHub)',
    setDb: 'Файл базы данных', setUpdates: 'Обновления приложения',
    csTitle: 'Поиск по коду', csQuery: 'Что искать', mbTitle: 'Выбор модели',
    ceTitle: 'Редактирование кода', cePath: 'Путь к файлу', ceCode: 'Содержимое',
    filesSummary: 'Файлы из ответа', sshAttempt: 'SSH: попытка', sshRunning: 'SSH: выполнение',
    mentionRead: 'Прочитан по @-упоминанию', writeVerifyFail: 'Запись не подтверждена:',
    ctxTitle: 'Использование токенов', ctxInput: 'Текущий ввод', ctxContext: 'Контекст', ctxMessages: 'Сообщения контекста', ctxTotal: 'Всего', ctxLimit: 'Лимит модели', ctxAuto: 'Автоматическое сжатие', ctxAutoNote: '(этот сеанс)', ctxCompress: 'Сжать диалог',
    ctxNoteModel: 'Лимит модели:', ctxNoteSend: 'в контекст уходит до', ctxNoteSetting: 'Лимит контекста в настройках:',
    ctxTooShort: 'Диалог пока слишком короткий', ctxNothing: 'Сжимать пока нечего', ctxDone: 'Сжато:', ctxAutoOn: 'Авто-сжатие включено', ctxAutoOff: 'Авто-сжатие выключено',
    skillsTitle: 'Навыки (skills) из GitHub', skillInstall: 'Установить', skillsNote: 'Навык — папка с файлом SKILL.md. Установленные навыки попадают в системный промпт, и модель может загрузить их через rr-skill.',
    skillsNone: 'Навыки не установлены', skillRemove: 'Удалить навык', skillNeedUrl: 'Укажите ссылку на репозиторий GitHub', skillLoading: 'Загружаем с GitHub…', skillInstalled: 'Установлено навыков:', skillError: 'Ошибка:'
  },
  en: {
    newChat: 'New chat', searchChats: 'Search chats…', files: 'Files', settings: 'Settings',
    export: 'Export', exportChat: 'Export chat to Markdown', theme: 'Toggle theme', closePanel: 'Close panel',
    welcomeSub: 'Your AI terminal: RiskRadar models, local files and SSH — in one window.',
    keyPlaceholder: 'Paste your key (sk-smart-…)', connect: 'Connect',
    keyHint: 'Get your key in the customer portal', keyLocal: 'It is stored only on your PC.',
    card1t: '💬 Chat with models', card1d: 'GPT-5.6, Claude, GPT-6-Astra and more — streaming with markdown',
    card2t: '📁 PC files', card2d: 'AI reads and writes files in the working directory, saves answers',
    card3t: '🖥 SSH', card3d: 'AI runs commands on your servers + terminal and SFTP',
    composerPh: 'Ask anything… (Enter — send, Shift+Enter — new line)',
    attach: 'Attach file', send: 'Send', stopGen: 'Stop',
    workdirTitle: 'Terminal working directory (files available to AI)',
    localFiles: '📁 Local files', pickDir: 'Choose folder', up: 'Up', up2: 'Up', home: 'Home folder', home2: 'Home', refresh: 'Refresh',
    name: 'Name', host: 'Host', port: 'Port', login: 'Login', authType: 'Auth type',
    password: 'Password', privKey: 'Private key', password2: 'Password', keyFile: 'Key file', keyPass: 'Key passphrase',
    saveConn: 'Save connection to the list', connect2: 'Connect', disconnect: 'Disconnect', disconnect2: 'Disconnect',
    toTerminal: 'Back to terminal', terminal: 'Terminal', uploadFile: 'Upload file to server', upload: 'Upload',
    settings2: 'Settings', baseUrl: 'Gateway Base URL', lockedByAdmin: 'Locked by administrator',
    clientKey: 'Client key (sk-smart-…)', show: 'Show', check: 'Check',
    defaultModel: 'Default model', refreshModels: 'Refresh model list', sysPrompt: 'System prompt',
    historyLimit: 'History (messages):',
    maxRounds: 'Agent rounds (read steps):', maxTokens: 'Max answer length (0 — auto):',
    roundsNote: 'The agent reads project files in rounds: request → read → next request. If rounds run out — say "continue" and it resumes where it stopped.',
    trimWarn: 'Memory overflow: {n} old messages did not fit the context and are hidden from the model. The task is pinned, but details may be lost.',
    roundsExhausted: 'Agent round limit reached ({n}): file reading stopped. Say "continue" — I will resume where I stopped.',
    docxDone: 'DOCX ready', docxBtn: 'Download as DOCX', sendImages: 'Send images to models (vision)',
    theme2: 'Theme', themeDark: 'Dark', themeLight: 'Light', language: 'Interface language',
    updates: 'Updates', checkNow: 'Check now', save: 'Save', close: 'Close',
    open: 'Open', showInFolder: 'Show in folder', attachToChat: 'Attach to chat',
    chooseLangSelf: 'Choose interface language / Выберите язык интерфейса',
    noKey: 'No key', keyActive: 'Key active', generating: 'Generating…', reasonTitle: 'Thinking', reconnecting: 'Reconnecting…',
    lpWaiting: 'waiting for the model', lpThinking: 'model is thinking', lpWriting: 'writing the answer',
    applyToFile: 'Apply to file', applyDone: 'Applied to file', modelSwitched: 'Model switched',
    mCopy: 'Copy', mRegen: 'Regenerate', mDel: 'Delete', mSave: 'To file',
    execSsh: 'Generating…', execFile: 'Generating…',
    noChats: 'No chats yet', emptyFolder: 'Folder is empty', emptyDir: 'Empty',
    settingsSaved: 'Settings saved', copied: 'Copied',
    fileAttached: 'File attached', filesAttached: 'Files attached',
    keyOk: 'Key accepted ✓', keyBad: 'Gateway rejected the key. Check it in the portal.',
    needKeyFirst: 'Set your client key in Settings first', enterKey: 'Paste the key',
    sshErr: 'Connection error: ', balanceTitle: 'Key balance', balanceTokens: 'tokens',
    exportDone: 'Exported', chatEmpty: 'Chat is empty', stoppedNote: '_(stopped)_', resumingNote: '_(reconnecting…)_',
  runDone: 'Done', runError: 'Error', runStopped: 'Stopped',
    emptyReply: 'Empty model reply. Try again or switch the model.',
    workdirHome: '~', codeSearch: 'Code', codeSearchLabel: 'Find',
    codeSearchNote: 'Searches the latest code in the current chat and the local working folder, then opens the exact snippet.',
    codeSearchFound: 'Matches found: ', codeSearchNone: 'No matches found', codeSearchRun: 'Find',
    codeOpenSnippet: 'Snippet', codeOpenFile: 'Open file', titleSaved: 'Chat title updated',
    codeEdit: 'Code editor', codeEditPath: 'File to save', codeEditPathNote: 'Save as a new file or overwrite a file inside the working folder.',
    codeEditContent: 'Code', codeEditAction: 'Edit', codeSave: 'Save', codeSaveAs: 'Save as…', codeSaved: 'Code saved: ',
    updatesNone: 'No updates found', updatesUiRestart: 'UI update found — restart the terminal', updatesAppAvail: 'New app version found: ',
    remoteNeedsSsh: 'Connect over SSH before editing a remote file', remoteSaved: 'Remote file saved: ',
    tokenShield: 'TokenShield — compress text/code locally before sending',
    tddMode: 'TDD mode: tests first (model writes & runs tests before touching code)',
    webSearch: 'Web search (model searches the internet)',
    shellExec: 'Run commands on this PC (like Codex / Claude Code)',
    shellAuto: 'Do not ask before each command (auto mode)',
    shellNote: 'Commands run in your login shell (on macOS with the Terminal PATH, so brew/nvm/pyenv work). Requires an updated terminal shell.',
    tokenShieldNote: 'No AI: normalizes files and code, trims redundant blank lines and spaces to save tokens.',
    modelCatalog: 'Model catalog', modelCatalogNote: 'Grouped models with search and cost. Text models show a × coefficient; image models show tokens per generated picture.', support: 'Support',
  chatWeight: 'Chat weight limit (context tokens)', chatWeightNow: 'Currently in this chat:', openFolder: 'Open', browser: 'Browser',
  pinChat: 'Pin chat', unpinChat: 'Unpin chat', chatPinned: 'Chat pinned', chatUnpinned: 'Chat unpinned',
  chatWeightNote: 'Manual weight limit removed (1.2.98): the context budget is derived automatically from the model window; the chat never stalls at a limit — old messages are softly compressed, everything stays on disk.',
  chatsStorage: 'Chat storage', chatsStorageNote: 'All chats are stored only on this computer and are never sent to the server. Saves are atomic and the previous version is kept as db.json.bak.',
    topupTitle: 'Balance top-up', topupOpenSite: 'Open payment on website', topupAuthRequired: 'Creating a payment requires a valid API key or a logged-in RiskRadar account.',
    topupSbp: 'SBP · YooKassa', topupCrypto: 'Crypto · USDT', topupPay: 'Pay', topupGetAddress: 'Get address',
    topupCreating: 'Creating payment…', topupCreatingInvoice: 'Creating invoice…', topupOpenPay: 'Proceed to payment →', topupShowQr: 'Show QR', topupCopy: 'Copy', topupCopied: 'Copied ✓',
    faOpen: 'Open file', faFolder: 'Show in folder', faAttach: 'Attach', faBadPath: 'File not found or the path is wrong:', faDirAttached: 'Folder attached as a list',
    setApiKey: 'API key', setModel: 'Model', setWeight: 'Chat weight for model (chars)',
    setTheme: 'Theme', setLang: 'Interface language', setSkills: 'Skills (from GitHub)',
    setDb: 'Database file', setUpdates: 'App updates',
    csTitle: 'Code search', csQuery: 'Query', mbTitle: 'Model picker',
    ceTitle: 'Code editor', cePath: 'File path', ceCode: 'Contents',
    filesSummary: 'Files from answer', sshAttempt: 'SSH: attempt', sshRunning: 'SSH: running',
    mentionRead: 'Read via @-mention', writeVerifyFail: 'Write not verified:',
    ctxTitle: 'Token usage', ctxInput: 'Current input', ctxContext: 'Context', ctxMessages: 'Context messages', ctxTotal: 'Total', ctxLimit: 'Model limit', ctxAuto: 'Automatic compression', ctxAutoNote: '(this session)', ctxCompress: 'Compress dialog',
    ctxNoteModel: 'Model limit:', ctxNoteSend: 'up to sent to context', ctxNoteSetting: 'Context limit in settings:',
    ctxTooShort: 'Dialog is too short', ctxNothing: 'Nothing to compress', ctxDone: 'Compressed:', ctxAutoOn: 'Auto-compress on', ctxAutoOff: 'Auto-compress off',
    skillsTitle: 'Skills from GitHub', skillInstall: 'Install', skillsNote: 'A skill is a folder with SKILL.md. Installed skills are added to the system prompt and the model can load them via rr-skill.',
    skillsNone: 'No skills installed', skillRemove: 'Remove skill', skillNeedUrl: 'Enter a GitHub repository URL', skillLoading: 'Downloading from GitHub…', skillInstalled: 'Skills installed:', skillError: 'Error:'
  }
};
let LANG = 'ru';
const t = (k) => (I18N[LANG] && I18N[LANG][k]) || I18N.ru[k] || k;

function applyI18n() {
  $$('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  $$('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  $$('[data-i18n-title]').forEach((el) => { el.title = t(el.dataset.i18nTitle); });
  document.documentElement.lang = LANG;
}

/* ------------------------------ утилиты ------------------------------ */

const TEXT_EXT = new Set(['txt','md','markdown','json','jsonc','js','mjs','cjs','ts','jsx','tsx','py','rb','go','rs','java','kt','c','h','cpp','hpp','cs','php','sh','bash','zsh','bat','cmd','ps1','psm1','yml','yaml','toml','ini','cfg','conf','env','log','csv','tsv','html','htm','css','scss','xml','svg','sql','r','lua','pl','swift','dart','vue','svelte','gradle','properties','dockerfile','makefile']);
const IMG_EXT = new Set(['png','jpg','jpeg','gif','webp','bmp']);
const extOf = (p) => { const m = /\.([A-Za-z0-9]+)$/.exec(String(p)); return m ? m[1].toLowerCase() : ''; };
const fmtSize = (n) => n >= 1073741824 ? (n/1073741824).toFixed(1)+' ГБ' : n >= 1048576 ? (n/1048576).toFixed(1)+' МБ' : n >= 1024 ? (n/1024).toFixed(0)+' КБ' : n+' Б';
const fmtTokens = (n) => n == null ? '—' : n >= 1e6 ? (n/1e6).toFixed(1)+'M' : n >= 1e3 ? Math.round(n/1e3)+'K' : String(n);
const fmtDate = (ts) => { const d = new Date(ts); return d.getDate().toString().padStart(2,'0')+'.'+(d.getMonth()+1).toString().padStart(2,'0'); };
const fmtMoneyRub = (n) => Number(n || 0).toLocaleString('ru-RU', { maximumFractionDigits: 0 }) + ' ₽';
const fmtMoneyUsd = (n) => '$' + Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const TOPUP_SITE_URL = 'https://riskradarai.ru/vibecoder.html?page=topup#topup';
const MODEL_GROUP_COLORS = { 'Генерация изображений': '#ec4899', 'OpenAI': '#22c55e', 'OpenAI / Code': '#14b8a6', 'Anthropic': '#a855f7', 'Google': '#eab308', 'DeepSeek': '#38bdf8', 'xAI': '#f97316', 'Moonshot': '#f43f5e', 'Qwen': '#84cc16', 'Zhipu': '#818cf8', 'MiniMax': '#fb7185', 'Tencent': '#06b6d4', 'Mimo': '#f59e0b', 'Other': '#94a3b8' };
const versionParts = (v) => String(v || '').split(/[^0-9]+/).filter(Boolean).map((x) => Number(x) || 0);
function compareVersions(a, b) {
  const aa = versionParts(a), bb = versionParts(b);
  const n = Math.max(aa.length, bb.length);
  for (let i = 0; i < n; i++) {
    const d = (aa[i] || 0) - (bb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}
function shellQuote(s) { return `'${String(s || '').replace(/'/g, `'"'"'`)}'`; }
function pickHereDocTag(text) {
  let tag = '__RR_EDIT__';
  while (String(text || '').includes(`\n${tag}\n`) || String(text || '').endsWith(`\n${tag}`)) tag += '_X';
  return tag;
}
function encodeBase64Utf8(text) {
  const bytes = new TextEncoder().encode(String(text || ''));
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}
function decodeBase64Utf8(b64) {
  const bin = atob(String(b64 || ''));
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder('utf-8').decode(bytes);
}
function stripAnsi(text) {
  return String(text || '').replace(/\x1B\[[0-9;?]*[ -/]*[@-~]/g, '').replace(/\x1B\][^\u0007]*(?:\u0007|\x1B\\)/g, '').replace(/\r/g, '');
}
function openExternalUrl(url) {
  const target = String(url || '').trim();
  if (!target) return Promise.resolve(false);
  const fallback = () => {
    try {
      const a = document.createElement('a');
      a.href = target; a.target = '_blank'; a.rel = 'noreferrer noopener'; a.style.display = 'none';
      document.body.appendChild(a); a.click(); setTimeout(() => a.remove(), 50);
      return true;
    } catch (e) {}
    try { const w = window.open(target, '_blank', 'noopener,noreferrer'); if (w) return true; } catch (e) {}
    try { window.location.href = target; return true; } catch (e) {}
    return false;
  };
  if (!(rr && typeof rr.invoke === 'function')) return Promise.resolve(fallback());
  // V-LINKFIX: главный процесс ждёт СТРОКУ url, а не {url} — при объекте ссылка молча не открывалась
  // (кнопка «Поддержка» и ссылка на оплату СБП ничего не делали). Пробуем оба варианта,
  // а если ни один не подтвердил успех — открываем через реальный <a target=_blank>:
  // его перехватывает setWindowOpenHandler в главном процессе и открывает системный браузер.
  // V-LINKFIX2: главный процесс открывает браузер по СТРОКЕ url и не возвращает результат,
  // поэтому успехом считаем сам факт ответа канала. Резервный путь — только при ошибке канала,
  // иначе ссылка открывалась дважды (две вкладки).
  return rr.invoke('app:openExternal', target)
    .then(() => true)
    .catch(() => {
      const ok = fallback();
      if (!ok) { try { copyText(target); toast('Ссылка скопирована: ' + target); } catch (e) {} }
      return ok;
    });
}
async function copyText(text) {
  const s = String(text || '');
  try { await navigator.clipboard.writeText(s); return true; } catch (e) {}
  try {
    const ta = document.createElement('textarea');
    ta.value = s; ta.style.position = 'fixed'; ta.style.left = '-9999px';
    document.body.appendChild(ta); ta.focus(); ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return !!ok;
  } catch (e) { return false; }
}

const MODEL_META = {
  'gpt-5.6-luna': { label: 'GPT-5.6 Luna', group: 'OpenAI', colors: ['#1d4ed8', '#0ea5e9'], monogram: 'L' },
  'codex-auto-review': { label: 'Codex Auto Review', group: 'OpenAI / Code', colors: ['#0f766e', '#14b8a6'], monogram: 'C' },
  'sonnet-4.6': { label: 'Sonnet 4.6', group: 'Anthropic', colors: ['#a855f7', '#7c3aed'], monogram: 'S' },
  'sonnet-5': { label: 'Sonnet 5', group: 'Anthropic', colors: ['#9333ea', '#ec4899'], monogram: 'S5' },
  'claude-sonnet-4-6': { label: 'Claude Sonnet 4.6', group: 'Anthropic', colors: ['#a855f7', '#7c3aed'], monogram: 'S' },
  'claude-sonnet-5': { label: 'Claude Sonnet 5', group: 'Anthropic', colors: ['#9333ea', '#ec4899'], monogram: 'S5' },
  'gpt-5.6-terra': { label: 'GPT-5.6 Terra', group: 'OpenAI', colors: ['#0f766e', '#22c55e'], monogram: 'T' },
  'gpt-5.4': { label: 'GPT 5.4', group: 'OpenAI', colors: ['#334155', '#64748b'], monogram: '5.4' },
  'opus-4.6': { label: 'Opus 4.6', group: 'Anthropic', colors: ['#f59e0b', '#ef4444'], monogram: 'O' },
  'opus-4.7': { label: 'Opus 4.7', group: 'Anthropic', colors: ['#f97316', '#ef4444'], monogram: 'O' },
  'opus-4.8': { label: 'Opus 4.8', group: 'Anthropic', colors: ['#fb7185', '#f97316'], monogram: 'O' },
  'claude-opus-4-6': { label: 'Claude Opus 4.6', group: 'Anthropic', colors: ['#f59e0b', '#ef4444'], monogram: 'O' },
  'claude-opus-4-7': { label: 'Claude Opus 4.7', group: 'Anthropic', colors: ['#f97316', '#ef4444'], monogram: 'O' },
  'claude-opus-4-8': { label: 'Claude Opus 4.8', group: 'Anthropic', colors: ['#fb7185', '#f97316'], monogram: 'O' },
  'claude-opus-5': { label: 'Claude Opus 5', group: 'Anthropic', colors: ['#ef4444', '#f59e0b'], monogram: 'O5' },
  'claude-fable-5': { label: 'Claude Fable 5', group: 'Anthropic', colors: ['#7c3aed', '#ec4899'], monogram: 'F5' },
  'claude-fable-5.1': { label: 'Claude Fable 5.1', group: 'Anthropic', colors: ['#7c3aed', '#ec4899'], monogram: 'F5' },
  'claude-haiku-4-5': { label: 'Claude Haiku 4.5', group: 'Anthropic', colors: ['#8b5cf6', '#22d3ee'], monogram: 'H' },
  'claude-haiku-4-5-20251001': { label: 'Claude Haiku 4.5', group: 'Anthropic', colors: ['#8b5cf6', '#22d3ee'], monogram: 'H' },
  'gpt-5.5': { label: 'GPT 5.5', group: 'OpenAI', colors: ['#475569', '#0f766e'], monogram: '5.5' },
  'gpt-5.6': { label: 'GPT 5.6', group: 'OpenAI', colors: ['#1d4ed8', '#10b981'], monogram: '5.6' },
  'gpt-5.6-sol': { label: 'GPT-5.6 Sol', group: 'OpenAI', colors: ['#dc2626', '#f59e0b'], monogram: 'S' },
  'gpt-6-astra': { label: 'GPT 6 Astra', group: 'OpenAI', colors: ['#7c3aed', '#0ea5e9'], monogram: 'A' },
  'deepseek-v4-flash': { label: 'DeepSeek V4 Flash', group: 'DeepSeek', colors: ['#0f766e', '#38bdf8'], monogram: 'DS' },
  'DeepSeek-V4-Flash-0731': { label: 'DeepSeek V4 Flash 0731', group: 'DeepSeek', colors: ['#0f766e', '#38bdf8'], monogram: 'DS' },
  'deepseek-v4-flash-vision-exp': { label: 'DeepSeek V4 Flash Vision', group: 'DeepSeek', colors: ['#0f766e', '#38bdf8'], monogram: 'DS' },
  'deepseek-v4-pro': { label: 'DeepSeek V4 Pro', group: 'DeepSeek', colors: ['#14532d', '#06b6d4'], monogram: 'DP' },
  'deepseek-v4-pro-0813': { label: 'DeepSeek V4 Pro 0813', group: 'DeepSeek', colors: ['#14532d', '#06b6d4'], monogram: 'DP' },
  'deepseek-v4.1-flash': { label: 'DeepSeek V4.1 Flash', group: 'DeepSeek', colors: ['#0f766e', '#38bdf8'], monogram: 'D4' },
  'gemini-2.5-flash': { label: 'Gemini 2.5 Flash', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G' },
  'gemini-2.5-pro': { label: 'Gemini 2.5 Pro', group: 'Google', colors: ['#1d4ed8', '#7c3aed'], monogram: 'G' },
  'gemini-3-flash-preview': { label: 'Gemini 3 Flash Preview', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G3' },
  'gemini-3-pro-preview': { label: 'Gemini 3 Pro Preview', group: 'Google', colors: ['#1d4ed8', '#7c3aed'], monogram: 'G3' },
  'gemini-3.1-flash-lite-preview': { label: 'Gemini 3.1 Flash Lite', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G3' },
  'gemini-3.1-pro-preview': { label: 'Gemini 3.1 Pro Preview', group: 'Google', colors: ['#1d4ed8', '#7c3aed'], monogram: 'G3' },
  'gemini-3.5-flash': { label: 'Gemini 3.5 Flash', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G3' },
  'gemini-3.5-flash-lite': { label: 'Gemini 3.5 Flash Lite', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G3' },
  'gemini-3.5-flash-low': { label: 'Gemini 3.5 Flash Low', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G3' },
  'gemini-3.6-flash': { label: 'Gemini 3.6 Flash', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G3' },
  'gemini-3.7-flash': { label: 'Gemini 3.7 Flash', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G3' },
  'gemini-3.8-flash': { label: 'Gemini 3.8 Flash', group: 'Google', colors: ['#2563eb', '#8b5cf6'], monogram: 'G3' },
  'glm-5.1': { label: 'GLM 5.1', group: 'Zhipu', colors: ['#0f766e', '#84cc16'], monogram: 'GLM' },
  'glm-5.2': { label: 'GLM 5.2', group: 'Zhipu', colors: ['#0f766e', '#84cc16'], monogram: 'GLM' },
  'glm-5.3': { label: 'GLM 5.3', group: 'Zhipu', colors: ['#0f766e', '#84cc16'], monogram: 'GLM' },
  'glm-5.3-flash': { label: 'GLM 5.3 Flash', group: 'Zhipu', colors: ['#0f766e', '#84cc16'], monogram: 'GLM' },
  'grok-4.3': { label: 'Grok 4.3', group: 'xAI', colors: ['#334155', '#0ea5e9'], monogram: 'GX' },
  'grok-4.5': { label: 'Grok 4.5', group: 'xAI', colors: ['#334155', '#0ea5e9'], monogram: 'GX' },
  'grok-4.6': { label: 'Grok 4.6', group: 'xAI', colors: ['#334155', '#0ea5e9'], monogram: 'GX' },
  'grok-build-0.1': { label: 'Grok Build 0.1', group: 'xAI', colors: ['#334155', '#0ea5e9'], monogram: 'GB' },
  'hy3': { label: 'Hunyuan 3', group: 'Tencent', colors: ['#7c2d12', '#f97316'], monogram: 'HY' },
  'hy4-preview': { label: 'Hunyuan 4 Preview', group: 'Tencent', colors: ['#7c2d12', '#f97316'], monogram: 'HY' },
  'kimi-k2.6': { label: 'Kimi K2.6', group: 'Moonshot', colors: ['#0f766e', '#14b8a6'], monogram: 'K' },
  'kimi-k2.7-code': { label: 'Kimi K2.7 Code', group: 'Moonshot / Code', colors: ['#0f766e', '#14b8a6'], monogram: 'K' },
  'kimi-k3': { label: 'Kimi K3', group: 'Moonshot', colors: ['#0f766e', '#14b8a6'], monogram: 'K' },
  'mimo-v2.5': { label: 'Mimo V2.5', group: 'Mimo', colors: ['#4f46e5', '#06b6d4'], monogram: 'M' },
  'mimo-v2.5-pro': { label: 'Mimo V2.5 Pro', group: 'Mimo', colors: ['#4f46e5', '#06b6d4'], monogram: 'M' },
  'minimax-m2.5': { label: 'MiniMax M2.5', group: 'MiniMax', colors: ['#be123c', '#fb7185'], monogram: 'MM' },
  'minimax-m2.7': { label: 'MiniMax M2.7', group: 'MiniMax', colors: ['#be123c', '#fb7185'], monogram: 'MM' },
  'minimax-m3': { label: 'MiniMax M3', group: 'MiniMax', colors: ['#be123c', '#fb7185'], monogram: 'MM' },
  'qwen3.6-27b': { label: 'Qwen 3.6 27B', group: 'Qwen', colors: ['#1f2937', '#22c55e'], monogram: 'Q' },
  'qwen3.7-max': { label: 'Qwen 3.7 Max', group: 'Qwen', colors: ['#1f2937', '#22c55e'], monogram: 'Q' },
  'qwen3.7-plus': { label: 'Qwen 3.7 Plus', group: 'Qwen', colors: ['#1f2937', '#22c55e'], monogram: 'Q' },
  'qwen3.8-flash': { label: 'Qwen 3.8 Flash', group: 'Qwen', colors: ['#1f2937', '#22c55e'], monogram: 'Q' },
  'qwen3.8-max': { label: 'Qwen 3.8 Max', group: 'Qwen', colors: ['#1f2937', '#22c55e'], monogram: 'Q' },
  'qwen3.8-max-preview': { label: 'Qwen 3.8 Max Preview', group: 'Qwen', colors: ['#1f2937', '#22c55e'], monogram: 'Q' },
  'gpt-image-2': { label: 'GPT Image 2', group: 'OpenAI', colors: ['#475569', '#0ea5e9'], monogram: 'IMG' }
};
const MODEL_COEF = {
  'gpt-5.6-luna': 1.7, 'codex-auto-review': 1.7, 'gpt-5.4': 3.5, 'sonnet-4.6': 2, 'sonnet-5': 2.5,
  'gpt-5.6-terra': 3, 'opus-4.6': 4, 'opus-4.7': 4, 'opus-4.8': 4, 'gpt-5.6-sol': 4, 'gpt-6-astra': 8,
  'claude-sonnet-4-6': 2, 'claude-sonnet-5': 2.5, 'claude-opus-4-6': 4, 'claude-opus-4-7': 4, 'claude-opus-4-8': 4,
  'claude-fable-5': 8.4, 'claude-fable-5.1': 47.7, 'claude-haikulite-preview': 0.75, 'gemini-3.1-pro-preview': 3.4,
  'gemini-3.5-flash': 2.2, 'gemini-3.5-flash-lite': 2.75, 'gemini-3.5-flash-low': 6.05, 'gemini-3.6-flash': 1,
  'gemini-3.7-flash': 1.35, 'gemini-3.8-flash': 1.3, 'glm-5.1': 3.85, 'glm-5.2': 3.05, 'glm-5.3': 1,
  'glm-5.3-flash': 0.6, 'gpt-5.5': 2.75, 'gpt-5.6': 2.65, 'grok-4.3': 2.1, 'grok-4.5': 0.95, 'grok-4.6': 0.6,
  'grok-build-0.1': 2.5, 'hy3': 0.6, 'hy4-preview': 0.6, 'kimi-k2.6': 4.5, 'kimi-k2.7-code': 1.1, 'kimi-k3': 2.4,
  'mimo-v2.5': 0.6, 'mimo-v2.5-pro': 4.2, 'minimax-m2.5': 6.15, 'minimax-m2.7': 1.2, 'minimax-m3': 0.7,
  'qwen3.6-27b': 1.2, 'qwen3.7-max': 2, 'qwen3.7-plus': 3.8, 'qwen3.8-flash': 0.6, 'qwen3.8-max': 5, 'qwen3.8-max-preview': 2
};
/* V-IMGCOST: сколько ТОКЕНОВ списывается за одну генерацию картинки.
 * У текстовых моделей цена — коэффициент ×, у генерации картинок фиксированная цена за картинку,
 * поэтому коэффициент там бессмысленен и заменён на реальную стоимость в токенах.
 * Значения измерены на живом аккаунте: дельта spent в /api/vc/me до и после генерации. */
const IMG_GEN_TOKENS = {
  'gemini-3.1-flash-image': 653353,
  'nano-banana': 2623907,
  'google-imagen-4': 13119534,
  'nano-banana-2': 2623907,
  'nano-banana-pro': 1140291,
  'gpt-image-1.5': 2623907,
  'gpt-image-2': 2623907,
  'gpt-image-2.5': 2623907,
  'gpt-image-2.5-flare': 2623907,
  'gpt-image-2.5-sunburst': 2623907,
  'grok-imagine-image': 371507,
  'grok-imagine-image-lite': 2623907,
  'grok-imagine-image-pro': 2623907
};
/* V-IMGCOST: для моделей без точного замера — цена по семейству (тот же порядок величины). */
const IMG_GEN_TOKENS_BY_FAMILY = [
  [/imagen/i, 'google-imagen-4'],
  [/nano-?banana/i, 'nano-banana'],
  [/gpt-image/i, 'gpt-image-1.5'],
  [/grok-imagine/i, 'grok-imagine-image'],
  [/gemini.*image|image.*flash/i, 'gemini-3.1-flash-image']
];
const IMG_GEN_TOKENS_FALLBACK = 2623907;
/* 1M токенов = 2.89 ₽ (pricePerMRub шлюза). Уточняется из ответа /api/vc/*. */
let PRICE_PER_M_RUB = 2.89;
function imageTokensPerPicture(id) {
  const key = String(id || '');
  if (IMG_GEN_TOKENS[key] != null) return IMG_GEN_TOKENS[key];
  const norm = (x) => x.toLowerCase().replace(/^rrx-/, '').replace(/[-_.]/g, '');
  const nk = norm(key);
  for (const k of Object.keys(IMG_GEN_TOKENS)) if (norm(k) === nk) return IMG_GEN_TOKENS[k];
  for (const pair of IMG_GEN_TOKENS_BY_FAMILY) if (pair[0].test(key)) return IMG_GEN_TOKENS[pair[1]];
  return IMG_GEN_TOKENS_FALLBACK;
}
function fmtImgTokens(n) {
  if (n == null) return '—';
  if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace('.', ',') + 'M';
  return Math.round(n / 1000) + 'K';
}
/* V-IMGCOST: подпись стоимости — картинки в токенах за штуку, текст в коэффициенте. */
function modelCostText(meta) {
  if (meta && meta.isImageGen) return '≈' + fmtImgTokens(meta.tokensPerImage) + (LANG === 'en' ? ' tok/pic' : ' токенов');
  return '×' + ((meta && meta.coef) != null ? meta.coef : 1);
}
function modelCostTitle(meta) {
  if (meta && meta.isImageGen) {
    const base = (LANG === 'en' ? 'about ' : '≈') + fmtImgTokens(meta.tokensPerImage) + (LANG === 'en' ? ' tokens per generated picture' : ' токенов за одну сгенерированную картинку');
    const rub = (Number(meta.tokensPerImage) || 0) * PRICE_PER_M_RUB / 1e6;
    return rub > 0 ? base + (LANG === 'en' ? ' (~$' + (rub / 84.5).toFixed(3) + ')' : ' (≈' + rub.toFixed(2).replace('.', ',') + ' ₽)') : base;
  }
  return '×' + ((meta && meta.coef) != null ? meta.coef : 1);
}
const MODEL_GROUP_ORDER = ['OpenAI', 'OpenAI / Code', 'Anthropic', 'Google', 'DeepSeek', 'xAI', 'Moonshot', 'Qwen', 'Zhipu', 'MiniMax', 'Tencent', 'Mimo', 'Other', 'Генерация изображений'];
/* V-LOGOS: реальные векторные логотипы вендоров (simple-icons) */
const MODEL_LOGO_PATHS = {
  "OpenAI": { c: "#10a37f", d: "M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z" },
  "OpenAI / Code": { c: "#888", d: "M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z" },
  "Anthropic": { c: "#d97757", d: "M17.3041 3.541h-3.6718l6.696 16.918H24Zm-10.6082 0L0 20.459h3.7442l1.3693-3.5527h7.0052l1.3693 3.5528h3.7442L10.5363 3.5409Zm-.3712 10.2232 2.2914-5.9456 2.2914 5.9456Z" },
  "Google": { c: "#4285f4", d: "M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z" },
  "DeepSeek": { c: "#4d6bfe", d: "M23.748 4.651c-.254-.124-.364.113-.512.233-.051.04-.094.09-.137.137-.372.397-.806.657-1.373.626-.829-.046-1.537.214-2.163.848-.133-.782-.575-1.248-1.247-1.548-.352-.155-.708-.311-.955-.65-.172-.24-.219-.509-.305-.774-.055-.16-.11-.323-.293-.35-.2-.031-.278.136-.356.276-.313.572-.434 1.202-.422 1.84.027 1.436.633 2.58 1.838 3.393.137.094.172.187.129.323-.082.28-.18.553-.266.833-.055.179-.137.218-.328.14a5.5 5.5 0 0 1-1.737-1.179c-.857-.828-1.631-1.743-2.597-2.46a12 12 0 0 0-.689-.47c-.985-.957.13-1.743.387-1.836.27-.098.094-.433-.778-.428-.872.003-1.67.295-2.687.685a3 3 0 0 1-.465.136 9.6 9.6 0 0 0-2.883-.101c-1.885.21-3.39 1.1-4.497 2.622C.082 8.776-.231 10.854.152 13.02c.403 2.284 1.568 4.175 3.36 5.653 1.857 1.533 3.997 2.284 6.438 2.14 1.482-.085 3.132-.284 4.994-1.86.47.234.962.328 1.78.398.629.058 1.235-.031 1.705-.129.735-.155.684-.836.418-.961-2.155-1.004-1.682-.595-2.112-.926 1.095-1.295 2.768-3.598 3.284-6.733.05-.346.115-.834.108-1.114-.004-.171.035-.238.23-.257a4.2 4.2 0 0 0 1.545-.475c1.397-.763 1.96-2.016 2.093-3.517.02-.23-.004-.467-.247-.588M11.58 18.168c-2.088-1.642-3.101-2.183-3.52-2.16-.39.024-.32.472-.234.763.09.288.207.487.371.74.114.167.192.416-.113.603-.673.416-1.842-.14-1.897-.168-1.361-.801-2.5-1.86-3.301-3.306-.775-1.393-1.225-2.888-1.299-4.482-.02-.385.094-.522.477-.592a4.7 4.7 0 0 1 1.53-.038c2.131.311 3.946 1.264 5.467 2.774.868.86 1.525 1.887 2.202 2.89.72 1.066 1.494 2.082 2.48 2.915.348.291.626.513.892.677-.802.09-2.14.109-3.055-.615zm1.001-6.44a.306.306 0 0 1 .415-.287.3.3 0 0 1 .113.074.3.3 0 0 1 .086.214c0 .17-.136.307-.308.307a.303.303 0 0 1-.306-.307m3.11 1.596c-.2.081-.4.151-.591.16a1.25 1.25 0 0 1-.798-.254c-.274-.23-.47-.358-.551-.758a1.7 1.7 0 0 1 .015-.588c.07-.327-.007-.537-.238-.727-.188-.156-.426-.199-.689-.199a.6.6 0 0 1-.254-.078.253.253 0 0 1-.114-.358 1 1 0 0 1 .192-.21c.356-.202.767-.136 1.146.016.352.144.618.408 1.001.782.392.451.462.576.685.915.176.264.336.536.446.848.066.194-.02.353-.25.45" },
  "Moonshot": { c: "#17171c", d: "m1.053 16.91 9.538 2.55a21 20.981 0 0 0 .06 2.031l5.956 1.592a12 11.99 0 0 1-15.554-6.172m-1.02-5.79 11.352 3.035a21 20.981 0 0 0-.469 2.01l10.817 2.89a12 11.99 0 0 1-1.845 2.004L.658 15.918a12 11.99 0 0 1-.625-4.796m1.593-5.146L13.573 9.17a21 20.981 0 0 0-1.01 1.874l11.297 3.02a21 20.981 0 0 1-.67 2.362l-11.55-3.087L.125 10.26a12 11.99 0 0 1 1.499-4.285ZM6.067 1.58l11.285 3.016a21 20.981 0 0 0-1.688 1.719l7.824 2.091a21 20.981 0 0 1 .513 2.664L2.107 5.218a12 11.99 0 0 1 3.96-3.638M21.68 4.866 7.222 1.003A12 11.99 0 0 1 21.68 4.866" },
  "Moonshot / Code": { c: "#888", d: "m1.053 16.91 9.538 2.55a21 20.981 0 0 0 .06 2.031l5.956 1.592a12 11.99 0 0 1-15.554-6.172m-1.02-5.79 11.352 3.035a21 20.981 0 0 0-.469 2.01l10.817 2.89a12 11.99 0 0 1-1.845 2.004L.658 15.918a12 11.99 0 0 1-.625-4.796m1.593-5.146L13.573 9.17a21 20.981 0 0 0-1.01 1.874l11.297 3.02a21 20.981 0 0 1-.67 2.362l-11.55-3.087L.125 10.26a12 11.99 0 0 1 1.499-4.285ZM6.067 1.58l11.285 3.016a21 20.981 0 0 0-1.688 1.719l7.824 2.091a21 20.981 0 0 1 .513 2.664L2.107 5.218a12 11.99 0 0 1 3.96-3.638M21.68 4.866 7.222 1.003A12 11.99 0 0 1 21.68 4.866" },
  "Qwen": { c: "#6b4cff", d: "M23.919 14.545 20.817 9.17l1.47-2.544a.56.56 0 0 0 0-.566l-1.633-2.83a.57.57 0 0 0-.49-.283h-6.207L12.487.402a.57.57 0 0 0-.49-.284H8.732a.56.56 0 0 0-.49.284L5.139 5.775h-2.94a.56.56 0 0 0-.49.284L.077 8.887a.56.56 0 0 0 0 .567L3.18 14.83l-1.47 2.545a.56.56 0 0 0 0 .566l1.634 2.83a.57.57 0 0 0 .49.283h6.205l1.47 2.545a.57.57 0 0 0 .49.284h3.266a.57.57 0 0 0 .49-.284l3.104-5.375h2.94a.57.57 0 0 0 .49-.283l1.634-2.828a.55.55 0 0 0-.004-.568M8.733.686l1.634 2.828-1.634 2.828H21.8L20.164 9.17H7.425L5.63 6.06Zm1.306 19.801-6.205-.002 1.634-2.83h3.265L2.201 6.344h3.267q3.182 5.517 6.367 11.032zm10.124-5.66L18.53 12l-6.532 11.315-1.634-2.83c2.129-3.673 4.25-7.351 6.373-11.028h3.592l3.102 5.374z" },
  "MiniMax": { c: "#e73562", d: "M11.43 3.92a.86.86 0 1 0-1.718 0v14.236a1.999 1.999 0 0 1-3.997 0V9.022a.86.86 0 1 0-1.718 0v3.87a1.999 1.999 0 0 1-3.997 0V11.49a.57.57 0 0 1 1.139 0v1.404a.86.86 0 0 0 1.719 0V9.022a1.999 1.999 0 0 1 3.997 0v9.134a.86.86 0 0 0 1.719 0V3.92a1.998 1.998 0 1 1 3.996 0v11.788a.57.57 0 1 1-1.139 0zm10.572 3.105a2 2 0 0 0-1.999 1.997v7.63a.86.86 0 0 1-1.718 0V3.923a1.999 1.999 0 0 0-3.997 0v16.16a.86.86 0 0 1-1.719 0V18.08a.57.57 0 1 0-1.138 0v2a1.998 1.998 0 0 0 3.996 0V3.92a.86.86 0 0 1 1.719 0v12.73a1.999 1.999 0 0 0 3.996 0V9.023a.86.86 0 1 1 1.72 0v6.686a.57.57 0 0 0 1.138 0V9.022a2 2 0 0 0-1.998-1.997" },
};


// V-LOGOS: svg-иконка модели; для групп без официального знака — монограмма в цвете группы
function modelLogoSvg(meta, size) {
  const sz = size || 20;
  const g = meta.group;
  const lp = MODEL_LOGO_PATHS[g];
  if (lp && lp.d) {
    return '<svg class="mlogo" viewBox="0 0 24 24" width="'+sz+'" height="'+sz+'" aria-hidden="true"><path d="'+lp.d+'" fill="'+lp.c+'"/></svg>';
  }
  const color = (MODEL_GROUP_COLORS && MODEL_GROUP_COLORS[g]) || (meta.colors && meta.colors[1]) || '#64748b';
  const mono = esc((meta.monogram || (meta.label||g).slice(0,2)).toUpperCase());
  return '<span class="mlogo mlogo-mono" style="width:'+sz+'px;height:'+sz+'px;background:'+color+'">'+mono+'</span>';
}
function prettifyModelName(name) {
  return String(name || '')
    .replace(/_/g, ' ')
    .replace(/(^|[\s-])([a-z])/g, (_, a, b) => a + b.toUpperCase())
    .replace(/\bGpt\b/g, 'GPT')
    .replace(/\bClaude\b/g, 'Claude')
    .replace(/\bGemini\b/g, 'Gemini')
    .replace(/\bDeepseek\b/g, 'DeepSeek')
    .replace(/\bGlm\b/g, 'GLM')
    .replace(/\bQwen\b/g, 'Qwen')
    .replace(/\bKimi\b/g, 'Kimi');
}
// V-IMGGEN: модели, которые ТОЛЬКО генерируют изображения (text→image) — отдельная группа,
// не путать с vision-моделями (те ПРИНИМАЮТ картинки на вход и остаются в группе вендора).
const IMG_GEN_GROUP = 'Генерация изображений';
const IMG_GEN_RE = /(^|[-_.])image($|[-_.\d])|imagen|nano-banana|grok-imagine/i;
function applyGatewayModelPricing(metaMap) {
  const parsePrice = (v) => {
    const s = String(v == null ? '' : v).trim();
    const coef = s.match(/[×x]\s*([0-9]+(?:[.,][0-9]+)?)/i);
    if (coef) return { coef: Number(coef[1].replace(',', '.')) };
    const img = s.match(/([0-9]+(?:[.,][0-9]+)?)\s*(K|M)\s*\/\s*(?:img|image|picture)/i);
    if (img) return { tokensPerImage: Math.round(Number(img[1].replace(',', '.')) * (img[2].toUpperCase() === 'M' ? 1e6 : 1e3)) };
    const raw = Number(s.replace(/[^0-9.,]/g, '').replace(',', '.'));
    return Number.isFinite(raw) && raw > 0 ? { coef: raw } : {};
  };
  for (const [id, m] of Object.entries(metaMap || {})) {
    const parsed = parsePrice(m && m.price);
    if (parsed.coef != null || parsed.tokensPerImage != null) metaMap[id] = { ...(m || {}), gatewayPrice: m.price, ...parsed };
  }
  return metaMap;
}
function getModelMeta(name) {
  const meta = modelMeta[name] || MODEL_META[name] || {};
  const isImageGen = IMG_GEN_RE.test(name);
  const group = isImageGen ? IMG_GEN_GROUP : (meta.group || (/opus|sonnet|claude/i.test(name) ? 'Anthropic' : /codex/i.test(name) ? 'OpenAI / Code' : /gpt/i.test(name) ? 'OpenAI' : /gemini/i.test(name) ? 'Google' : /deepseek/i.test(name) ? 'DeepSeek' : /grok/i.test(name) ? 'xAI' : /kimi/i.test(name) ? 'Moonshot' : /qwen/i.test(name) ? 'Qwen' : /glm/i.test(name) ? 'Zhipu' : /minimax/i.test(name) ? 'MiniMax' : /hy/i.test(name) ? 'Tencent' : /mimo/i.test(name) ? 'Mimo' : 'Other'));
  const coef = meta.gatewayCoef != null ? meta.gatewayCoef : (meta.coef != null ? meta.coef : (MODEL_COEF[name] != null ? MODEL_COEF[name] : 1));
  const provider = /^OpenAI/.test(group) ? 'OpenAI' : group;
  // V-MODAL: модальность — текст / изображение / аудио. Определяем по id и подсказкам в метке.
  let modalities = Array.isArray(meta.modalities) ? meta.modalities.slice() : null;
  if (!modalities) {
    modalities = ['text'];
    if (/vision|image|vl\b|-vl|multimodal|omni/i.test(name)) modalities.push('image');
    if (/audio|voice|tts|asr|speech|transcribe|listen/i.test(name)) modalities.push('audio');
    // модели-флагманы с широким мультимодальным входом
    if (/^(gemini-(3|2\.5)|claude-(opus|sonnet|fable)|gpt-5|grok-4)/i.test(name)) { if (!modalities.includes('image')) modalities.push('image'); }
  }
  if (isImageGen) modalities = ['imagegen'];
  const hasImage = modalities.includes('image'), hasAudio = modalities.includes('audio');
  const modality = isImageGen ? 'imagegen' : hasAudio ? 'audio' : hasImage ? 'image' : 'text';
  return {
    id: name,
    label: meta.label || prettifyModelName(name),
    coef,
    tokensPerImage: isImageGen ? (meta.tokensPerImage || imageTokensPerPicture(name)) : null,
    group,
    provider,
    isImageGen,
    modalities,
    modality,
    colors: meta.colors || ['#334155', '#0ea5e9'],
    monogram: meta.monogram || prettifyModelName(name).split(/\s+/).slice(0, 2).map((x) => x[0] || '').join('').slice(0, 3).toUpperCase()
  };
}
function modelOptionLabel(name) {
  const m = getModelMeta(name);
  return `${m.label} · ${modelCostText(m)}`;
}
function modelAvatarSvg(name) {
  const m = getModelMeta(name);
  const txt = esc(m.monogram);
  return `<svg viewBox="0 0 64 64" width="42" height="42" aria-hidden="true"><defs><linearGradient id="g-${esc(name)}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${m.colors[0]}"/><stop offset="1" stop-color="${m.colors[1]}"/></linearGradient></defs><rect x="4" y="4" width="56" height="56" rx="16" fill="#0b1220"/><rect x="8" y="8" width="48" height="48" rx="14" fill="url(#g-${esc(name)})"/><text x="32" y="37" text-anchor="middle" font-size="20" font-weight="800" fill="#fff" font-family="Segoe UI, Arial, sans-serif">${txt}</text></svg>`;
}

/* V-TASKSTATE: durable project goal/progress survives compaction and model switches. */
let activeTaskState = null;
function taskProjectPath() { return String(S().workDir || '').trim(); }
function renderTimeline(events) {
  const box = $('#task-timeline');
  if (!box) return;
  box.textContent = '';
  for (const event of (Array.isArray(events) ? events : []).slice(-20)) {
    const row = document.createElement('div');
    row.className = 'task-timeline-item ' + String(event.status || 'running');
    const title = document.createElement('b'); title.textContent = String(event.title || event.type || 'Действие');
    const detail = document.createElement('span'); detail.textContent = event.output ? ' — ' + String(event.output).slice(0, 240) : '';
    row.append(title, detail); box.appendChild(row);
  }
}
function renderTaskCard(state) {
  const card = $('#task-card');
  if (!card) return;
  const s = state || {};
  const visible = !!(s.goal || s.nextStep || (s.completed && s.completed.length) || (s.findings && s.findings.length));
  card.classList.toggle('hidden', !visible);
  $('#task-goal').textContent = s.goal || 'Цель ещё не задана';
  $('#task-phase').textContent = s.phase || 'idle';
  $('#task-completed').textContent = String((s.completed || []).length);
  $('#task-next').textContent = s.nextStep || '—';
  const button = $('#task-continue');
  if (button) button.classList.toggle('hidden', !s.nextStep || s.phase === 'done');
  renderTimeline(s.timeline || []);
}
async function continueTask() {
  const s = activeTaskState;
  if (!s || !s.nextStep) return false;
  const input = $('#composer-input');
  if (input) input.value = 'Продолжить с шага: ' + s.nextStep;
  renderTaskCard(s);
  if (typeof sendMessage === 'function') { await sendMessage(); return true; }
  return false;
}
async function loadActiveTaskState(chat) {
  activeTaskState = null;
  const projectPath = taskProjectPath();
  if (!chat || !projectPath) return null;
  try {
    const r = await rr.invoke('task:load', { projectPath, chatId: chat.id });
    if (r && r.ok) activeTaskState = r.state || r;
  } catch (e) { console.warn('[RR] task state load', e); }
  renderTaskCard(activeTaskState);
  return activeTaskState;
}
function taskStatePrompt() {
  const s = activeTaskState;
  if (!s || (!s.goal && !s.nextStep && !s.completed?.length && !s.findings?.length)) return '';
  const lines = [
    '\\n=== СОСТОЯНИЕ ЗАДАЧИ (локально сохранено) ===',
    'Цель: ' + (s.goal || 'не задана'),
    'Фаза: ' + (s.phase || 'idle'),
    'Выполнено: ' + ((s.completed || []).slice(-12).join(' | ') || 'нет'),
    'Найдено: ' + ((s.findings || []).slice(-8).join(' | ') || 'нет'),
    'Ошибки: ' + ((s.errors || []).slice(-8).join(' | ') || 'нет'),
    'Следующий шаг: ' + (s.nextStep || 'не задан'),
    '=== КОНЕЦ СОСТОЯНИЯ ===\\n'
  ];
  return lines.join('\\n');
}
async function saveActiveTaskPatch(patch) {
  const chat = currentChat();
  const projectPath = taskProjectPath();
  if (!chat || !projectPath) return null;
  try {
    const r = await rr.invoke('task:save', { projectPath, chatId: chat.id, patch });
    if (r && r.ok) activeTaskState = r.state;
    renderTaskCard(activeTaskState);
    return r;
  } catch (e) { console.warn('[RR] task state save', e); return null; }
}
function saveDb() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => rr.invoke('db:put', db).catch(console.error), 400);
}

/* ------------------------------ markdown ------------------------------ */

marked.setOptions({ gfm: true, breaks: true });

function renderMd(text) {
  try { return DOMPurify.sanitize(marked.parse(text || ''), { ADD_ATTR: ['target'] }); }
  catch (e) { return '<p>' + esc(text) + '</p>'; }
}

/* V-AUTOAPPLY: если модель напечатала код в чате вместо rr-file — даём применить его к файлу
   кнопкой «💾», а при однозначном совпадении (один блок = один прикреплённый файл того же типа)
   применяем автоматически. */
/* V-MACDLG: на macOS нативный диалог гасит все файлы при filters=['*'] (дефолт main.js).
   Передаём явный широкий список расширений — так файлы и папки выбираются. */
const ATTACH_FILTERS = [{ name: 'Все файлы', extensions: ['docx','doc','txt','rtf','md','markdown','html','htm','css','js','mjs','ts','json','py','sh','yml','yaml','xml','svg','csv','tsv','log','sql','pdf','xlsx','xls','pptx','ppt','zip','rar','7z','png','jpg','jpeg','gif','webp','bmp','mp3','wav','mp4','mov','exe','bat','ps1','env','ini','conf','java','c','cpp','h','cs','go','rs','rb','php','vue','svelte','kt','swift','dart'] }];
/* V-MACNOFILTER: по документации Electron на macOS ЛЮБОЙ активный фильтр гасит файлы
 * (а ['*'] — известный баг с полностью пустым диалогом). Поэтому на macOS фильтры
 * не передаём вовсе — диалог показывает все файлы; на Windows/Linux фильтр удобен. */
let IS_DARWIN = false;
let IS_WIN = false; // 1.2.83
function langToFileExt(lang) {
  const l = String(lang || '').toLowerCase();
  const map = { css:'css', html:'html', htm:'html', js:'js', mjs:'js', jsx:'js', ts:'ts', tsx:'ts', py:'py', json:'json', md:'md', txt:'txt', sh:'sh', bash:'sh', xml:'xml', svg:'svg', yml:'yml', yaml:'yml', sql:'sql', php:'php', java:'java', c:'c', cpp:'cpp', cs:'cs', go:'go', rs:'rs', rb:'rb', vue:'vue', scss:'scss', less:'less' };
  return map[l] || null;
}
function fencedBlocksOf(text) {
  const out = []; const re = /```([\w-]*)[^\n]*\n([\s\S]*?)```/g; let m;
  while ((m = re.exec(String(text || '')))) out.push({ lang: m[1], body: m[2] });
  return out;
}
function lastUserFileCandidates(chat) {
  const u = [...(chat && chat.messages || [])].reverse().find((m) => m && m.role === 'user');
  const out = [];
  for (const a of (u && u.attachments) || []) if (a.path) out.push(a.path);
  for (const a of (u && u.mentions) || []) if (a && a.path) out.push(a.path);
  return out;
}
function fileExtOf(p) { return String(String(p).split(/[\\/]/).pop().split('.').pop() || '').toLowerCase(); }
/* V-SELFAPPLY: терминал САМ пишет правки. css-блок вливается в <style> прикреплённого
   html, js-блок — в <script>; блок того же типа — целым файлом. */
function mergeCssIntoHtml(html, css) {
  const s = String(html || '');
  if (/<style[^>]*>[\s\S]*?<\/style>/i.test(s)) return s.replace(/(<style[^>]*>)[\s\S]*?(<\/style>)/i, (m, a, b) => a + '\n' + css + '\n' + b);
  if (/<\/head>/i.test(s)) return s.replace(/<\/head>/i, '<style>\n' + css + '\n</style>\n</head>');
  return s + '\n<style>\n' + css + '\n</style>\n';
}
function mergeJsIntoHtml(html, js) {
  const s = String(html || ''); const tag = '<script>\n' + js + '\n</script>';
  if (/<\/body>/i.test(s)) return s.replace(/<\/body>/i, tag + '\n</body>');
  return s + '\n' + tag + '\n';
}
function targetForBlock(lang, cands) {
  const ext = langToFileExt(lang); if (!ext) return null;
  const same = cands.filter((p) => fileExtOf(p) === ext);
  if (same.length === 1) return { path: same[0], mode: 'write' };
  const htmls = cands.filter((p) => fileExtOf(p) === 'html' || fileExtOf(p) === 'htm');
  if (ext === 'css' && htmls.length === 1) return { path: htmls[0], mode: 'css-html' };
  if (ext === 'js' && htmls.length === 1) return { path: htmls[0], mode: 'js-html' };
  return null;
}
async function applyCodeBlock(body, lang, auto) {
  const tgt = targetForBlock(lang, lastUserFileCandidates(currentChat()));
  if (!tgt) {
    if (auto) return null; // авто — только при однозначной цели
    const ext = langToFileExt(lang);
    const r = await rr.invoke('fs:saveDialog', { suggestedName: 'applied.' + ext, content: body });
    if (!r || r.canceled) return null;
    if (r.error) { toast(r.error, 'err'); return null; }
    toast(t('applyDone') + ': ' + r.path); return r.path;
  }
  let content = body;
  if (tgt.mode === 'css-html' || tgt.mode === 'js-html') {
    const cur = await rr.invoke('fs:readText', { filePath: tgt.path });
    if (!cur || !cur.ok) { toast((cur && cur.error) || 'read failed', 'err'); return null; }
    content = tgt.mode === 'css-html' ? mergeCssIntoHtml(cur.content, body) : mergeJsIntoHtml(cur.content, body);
  }
  const w = await rr.invoke('fs:writeText', { filePath: tgt.path, content });
  if (w && w.ok) toast((auto ? '⚙️ ' : '💾 ') + t('applyDone') + ': ' + tgt.path);
  else toast((w && w.error) || 'write failed', 'err');
  return (w && w.ok) ? tgt.path : null;
}
async function maybeAutoApply(chat, a) {
  if (S().autoApply === false || a.autoApplied || !a.content) return;
  const blocks = fencedBlocksOf(a.content).filter((b) => langToFileExt(b.lang) && b.body.trim().length > 100);
  if (blocks.length !== 1) return;
  if (!targetForBlock(blocks[0].lang, lastUserFileCandidates(chat))) return;
  a.autoApplied = true;
  await applyCodeBlock(blocks[0].body, blocks[0].lang, true);
}
function enhanceCode(root, opts) {
  const light = !!(opts && opts.light);
  // тул-блоки ИИ (rr-ssh / rr-file) → компактный вид
  root.querySelectorAll('pre code.language-rr-blender, pre code.language-rr-photoshop, pre code.language-rr-shell, pre code.language-rr-ssh, pre code.language-rr-file, pre code.language-rr-rfile, pre code.language-rr-balance, pre code.language-rr-web, pre code.language-rr-doc, pre code.language-rr-video, pre code.lang-rr-video, pre code.lang-rr-blender, pre code.lang-rr-photoshop, pre code.lang-rr-shell, pre code.lang-rr-ssh, pre code.lang-rr-file, pre code.lang-rr-rfile, pre code.lang-rr-balance, pre code.lang-rr-web, pre code.lang-rr-doc').forEach((block) => {
    const pre = block.parentElement;
    if (pre.tagName !== 'PRE' || pre.classList.contains('rr-tool')) return;
    pre.classList.add('rr-tool');
    const cls = block.className || '';
    const args = parseToolPreviewArgs(block.textContent, cls);
    const isSsh = /rr-ssh/.test(cls);
    const isRemoteFile = /rr-rfile/.test(cls);
    const isBalance = /rr-balance/.test(cls);
    const isWeb = /rr-web/.test(cls);
    const isDoc = /rr-doc/.test(cls);
    const isSkill = /rr-skill/.test(cls);
    const isShell = /rr-shell/.test(cls);
    const isVideo = /rr-video/.test(cls);
    block.textContent = isSsh
      ? '🖥 SSH → ' + (args.cmd || '') + (args.host ? '  @' + args.host + (args.profile ? ' (' + args.profile + ')' : '') : args.profile ? '  @' + args.profile : '')
      : isShell
        ? '⌨️ команда → ' + (args.cmd || args.command || '')
        : isRemoteFile
        ? '🗂 remote ' + (args.op || '') + ' ' + (args.path || '')
        : isBalance
          ? '💰 balance'
          : isSkill
            ? '🧠 навык ' + ((args.name || args.skill) || '')
            : isWeb
            ? '🌐 web ' + (args.op || 'fetch') + ' ' + (args.url || args.query || args.place || '')
            : isDoc
              ? '📄 документ ' + (args.format || '') + ' ' + (args.title || args.path || '')
              : isVideo
                ? '🎬 видео → ' + String(args.prompt || '').slice(0, 90)
                : '📁 ' + (args.op || '') + ' ' + (args.path || '');
    block.removeAttribute('class');
  });
  root.querySelectorAll('pre code').forEach((block) => {
    if (block.dataset.hl) return;
    // V-PERF: во время стрима не подсвечиваем код (hljs на растущем блоке = O(n²), тормозит активное окно).
    if (light && !block.dataset.hlPending) { block.dataset.hlPending = '1'; return; }
    block.dataset.hl = '1';
    delete block.dataset.hlPending;
    try { hljs.highlightElement(block); } catch (e) {}
    const pre = block.parentElement;
    if (pre.tagName === 'PRE' && !pre.querySelector('.code-copy')) {
      const btn = document.createElement('button');
      btn.className = 'code-copy';
      btn.textContent = t('mCopy');
      btn.onclick = () => {
        navigator.clipboard.writeText(block.textContent).then(() => {
          btn.textContent = '✓';
          setTimeout(() => (btn.textContent = t('mCopy')), 1400);
        });
      };
      pre.appendChild(btn);
      const _lang = ((block.className || '').match(/language-([\w-]+)/) || [])[1];
      if (langToFileExt(_lang) && block.textContent.trim().length > 80) {
        const ab = document.createElement('button');
        ab.className = 'code-copy code-apply'; ab.textContent = '💾'; ab.title = t('applyToFile');
        ab.onclick = () => applyCodeBlock(block.textContent, _lang, false);
        pre.appendChild(ab);
      }
    }
  });
  root.querySelectorAll('a').forEach((a) => { a.target = '_blank'; a.rel = 'noreferrer'; });
}

function normalizeNewlines(text) {
  return String(text || '').replace(/\r\n?/g, '\n');
}
function estimateTokens(text) {
  return Math.max(1, Math.ceil(String(text || '').length / 4));
}
/* V-CHATWEIGHT: вес чата в токенах — сколько реально уходит в модель. */
const IMAGE_TOKEN_COST = 1100;   // одна картинка ≈ 1100 токенов
function messageWeight(m) {
  if (!m) return 0;
  let n = estimateTokens(String(m.content || ''));
  if (m.images && m.images.length) n += m.images.length * IMAGE_TOKEN_COST;
  for (const a of m.attachments || []) n += estimateTokens(String(a.content || ''));
  return n;
}
function chatWeight(chat) {
  if (!chat) return 0;
  let n = 0;
  for (const m of chat.messages || []) n += messageWeight(m);
  return n;
}
function chatWeightLimit() {
  /* V-CTXAUTO (1.2.98): ручной «Вес чата (200000)» из настроек УБРАН совсем — клиенты
   * упирались в него и чат «вставал» (переставал отвечать). Бюджет всегда авто: окно
   * текущей модели (meta с шлюза, иначе таблица) минус 12K на системный промпт.
   * Старое сохранённое значение S().chatWeightLimit игнорируется намеренно. */
  try {
    const mm = Number((modelMeta[S().model || ''] || {}).context_length) || 0;
    let ctx = mm >= 8000 ? mm : 0;
    if (!ctx) {
      const m = String(S().model || '').toLowerCase();
      ctx = (/gpt-5\.6|gpt-6|gpt-5\.5|claude-|kimi-k3|minimax|grok-4/.test(m)) ? 196608 : 131072;
    }
    return Math.max(48000, ctx - 12000);
  } catch (e) { return 119072; }
}
/* V-CHATWEIGHT: режем самые старые сообщения, пока контекст не влезет в лимит по весу.
 * Сообщения на диске остаются — ограничиваем только то, что отправляем модели. */
function trimHistoryByWeight(hist, sys) {
  const budget = chatWeightLimit() - estimateTokens(sys);
  const list = hist.slice();
  let total = 0;
  for (const m of list) total += messageWeight(m);
  // V-MEMFIX: якорь задачи — самое старое сообщение пользователя ужимаем до текста+имён файлов, но не выбрасываем
  let anchor = null;
  try {
    const ai = list.findIndex((m) => m && m.role === 'user');
    if (ai >= 0) {
      let m = list[ai];
      if (messageWeight(m) > 4000) {
        let short = String(m.content || '');
        const names = (m.attachments || []).map((a) => a.name || a.path).filter(Boolean);
        if (names.length) short += '\n[Прикреплены файлы: ' + names.join(', ') + ']';
        m = { role: 'user', content: short.slice(0, 4000), attachments: [], images: [], ts: m.ts };
        list[ai] = m;
        total = 0;
        for (const x of list) total += messageWeight(x);
      }
      anchor = list[ai];
    }
  } catch (e) {}
  // V-SHRINKHIST (1.2.95): перед тем как выбрасывать целые сообщения, СЖИМАем старые
  // толстяки (tool-результаты, вставленные файлы) до голов+хвостов. Структура диалога
  // сохраняется, модель видит что и где читалось; режем только если не помогло.
  let shrunk = 0;
  if (total > budget) {
    for (let i = 0; i < list.length - 4 && total > budget; i++) {
      const m = list[i];
      if (!m || m === anchor || m.role === 'user' && i >= list.length - 6) continue;
      if (messageWeight(m) < 2200) continue;
      const txt = String(m.content || '');
      const cut = txt.length > 3200
        ? txt.slice(0, 1500) + '\n…[старый вывод сжат: −' + (txt.length - 2900) + ' зн.; полный текст — в истории чата и в файлах на диске]…\n' + txt.slice(-1400)
        : txt;
      let atts = m.attachments;
      if (Array.isArray(atts) && atts.length) {
        atts = atts.map((a) => {
          const ac = String((a && a.content) || '');
          if (a && a.kind === 'text' && ac.length > 2600) return Object.assign({}, a, { content: ac.slice(0, 1200) + '\n…[сжат]…\n' + ac.slice(-1000) });
          return a;
        });
      }
      const nm = Object.assign({}, m, { content: cut });
      if (atts) nm.attachments = atts;
      list[i] = nm;
      total = 0; for (const x of list) total += messageWeight(x);
      shrunk++;
    }
  }
  let dropped = 0;
  while (list.length > 1 && total > budget) {
    if (anchor && list[0] === anchor) {
      if (list.length < 3) break; // остались якорь + последнее — дальше резать нельзя
      total -= messageWeight(list.splice(1, 1)[0]);
      dropped++;
    } else {
      total -= messageWeight(list.shift());
      dropped++;
    }
  }
  if (shrunk) console.log('[RR:weight] сжато старых сообщений: ' + shrunk);
  if (dropped) {
    console.log('[RR:weight] отброшено сообщений: ' + dropped + ', вес ' + total + ' из ' + budget);
    try {
      const _nowD = Date.now();
      if (_nowD - (window.__rrTrimToastAt || 0) > 30 * 60000) {
        window.__rrTrimToastAt = _nowD;
        toast(t('trimWarn').replace('{n}', String(dropped)) + (shrunk ? (' (ещё ' + shrunk + ' — сжато, не удалено)') : ''), 'warn', t('settings2'), () => openSettings());
      }
    } catch (e) {}
  }
  return list;
}
/* 1.2.85 V-DEBATE: мультиагентный консильум — критик (вторая модель) ревьюит код ПЕРЕД записью на диск */
const CRITIC_CANDIDATES = ['deepseek-v4-flash', 'gemini-3.5-flash', 'gpt-5.6-luna', 'claude-haiku-4-5', 'gpt-5.6-terra', 'kimi-k2.6'];
function pickCriticModel() {
  try {
    const cur = S().model || '';
    const pool = (models || []).filter((m) => m !== cur);
    for (const c of CRITIC_CANDIDATES) if (pool.includes(c)) return c;
    return pool[0] || '';
  } catch (e) { return ''; }
}
async function criticGate(op, filePath, reviewText, chat) {
  try {
    if (!S().debateMode) return null;
    const ext = (String(filePath).split('.').pop() || '').toLowerCase();
    if (!TEXT_EXT.has(ext)) return null; // ревьюим только код/текст
    if (!reviewText || reviewText.length > 60000) return null; // слишком большой — пропускаем
    const critic = pickCriticModel();
    if (!critic) return null;
    const sys = 'You are a strict senior code reviewer (consilium critic). Review the code change. Reply with the FIRST line exactly "OK" if it is safe and correct, or the word "ISSUE" followed by up to 3 short bullets with concrete bugs only (null/undefined, broken API, edge case, infinite loop, security). Be terse. No style suggestions.';
    const body = reviewText.slice(0, 5000) + (reviewText.length > 5000 ? '\n…[truncated]' : '');
    const user = (op === 'patch' ? 'PATCH (old→new) for ' : 'Content of ') + filePath + ':\n```\n' + body + '\n```';
    const r = await withTimeout(rr.invoke('gw:chat', { reqId: 'critic-' + Date.now(), baseUrl: S().baseUrl, apiKey: S().apiKey, model: critic, temperature: 0, messages: [{ role: 'system', content: sys }, { role: 'user', content: user }] }), 60000, 'critic timeout');
    const txt = String((r && r.content) || '').trim();
    if (!txt) return null; // критик недоступен — работу не блокируем
    const first = txt.split('\n')[0].toUpperCase();
    const ok = /^OK/.test(first);
    if (chat) chat.__criticBlocks = ok ? 0 : (Number(chat.__criticBlocks) || 0) + 1;
    return { ok: ok, critic: critic, verdict: txt.slice(0, 900) };
  } catch (e) { return null; }
}
function criticRejectOutput(g) {
  return '⚖ CRITIC REJECTED the change (reviewer: ' + g.critic + '):\n' + g.verdict + '\nFix the listed issues and re-send the corrected ' + 'code block (same op). Do not argue with the critic — fix it.';
}
/* V-REQCOUNT: счётчик запросов — за сессию работы и по текущему чату. */
let sessionRequests = 0;
function bumpRequestCount(chat) {
  sessionRequests++;
  if (chat) chat.requests = (Number(chat.requests) || 0) + 1;
  persistSessionStats();
  updateRequestCounter();
  try { saveDb(); } catch (e) {}
}
function updateRequestCounter() {
  const val = $('#req-counter-val');
  if (!val) return;
  val.textContent = String(sessionRequests);
  const chat = currentChat();
  const inChat = (chat && Number(chat.requests)) || 0;
  const w = chatWeight(chat), wl = chatWeightLimit();
  const btn = $('#req-counter');
  if (btn) btn.title = LANG === 'en'
    ? 'Requests this session: ' + sessionRequests + '\nRequests in this chat: ' + inChat + '\nChat weight: ' + w.toLocaleString('en-US') + ' of ' + wl.toLocaleString('en-US') + ' tokens'
    : 'Запросов за эту сессию: ' + sessionRequests + '\nЗапросов в этом чате: ' + inChat + '\nВес чата: ' + w.toLocaleString('ru-RU') + ' из ' + wl.toLocaleString('ru-RU') + ' токенов';
}

/* V-TOKENSTATS: расширенная статистика по клику на счётчик запросов — сколько
 * реально уходит токенов (ввод/вывод/всего), примерная стоимость и последние запросы. */
const sessionStats = { reqs: 0, inTok: 0, outTok: 0, started: Date.now(), recent: [], tsSaved: 0 }; // 1.2.79: +экономия TokenShield за сессию
// 1.2.85 V-STATS-PERSIST: дневная статистика не теряется после рестарта терминала
function rrDayKey() { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function persistSessionStats() {
  try {
    if (!db) return;
    const k = rrDayKey();
    if (!db.stats || db.stats.day !== k) db.stats = { day: k, reqs: sessionStats.reqs, inTok: sessionStats.inTok, outTok: sessionStats.outTok, tsSaved: sessionStats.tsSaved };
    db.stats.reqs = sessionStats.reqs; db.stats.inTok = sessionStats.inTok; db.stats.outTok = sessionStats.outTok; db.stats.tsSaved = sessionStats.tsSaved;
    db.stats.reqCounter = sessionRequests;
  } catch (e) {}
}
function rrFmtNum(n) { return Number(n || 0).toLocaleString(LANG === 'en' ? 'en-US' : 'ru-RU'); }
function rrCostRub(tok) { return (Number(tok) || 0) * PRICE_PER_M_RUB / 1e6; }
function recordTokenUsage(chat, model, result, sentWeight, a) {
  try {
    const u = (result && result.usage) || null;
    let inTok = (u && u.prompt_tokens != null) ? Number(u.prompt_tokens) : (Number(sentWeight) || 0);
    let outTok = (u && u.completion_tokens != null) ? Number(u.completion_tokens)
      : (estimateTokens(a && a.content) + estimateTokens(a && a.reasoning));
    inTok = Math.max(0, Math.round(inTok)); outTok = Math.max(0, Math.round(outTok));
    sessionStats.reqs++; sessionStats.inTok += inTok; sessionStats.outTok += outTok;
    sessionStats.recent.unshift({ model: model || '?', in: inTok, out: outTok, ts: Date.now() });
    if (sessionStats.recent.length > 12) sessionStats.recent.length = 12;
    if (chat) { chat.tokenIn = (Number(chat.tokenIn) || 0) + inTok; chat.tokenOut = (Number(chat.tokenOut) || 0) + outTok; }
    persistSessionStats();
    const pop = $('#stats-panel'); if (pop && !pop.classList.contains('hidden')) renderStatsPanel();
  } catch (e) {}
}
function statsRows() {
  const chat = currentChat();
  const L = (ru, en) => LANG === 'en' ? en : ru;
  const totalTok = sessionStats.inTok + sessionStats.outTok;
  const rub = rrCostRub(totalTok);
  const mins = Math.max(0, Math.round((Date.now() - sessionStats.started) / 60000));
  const dur = mins < 60 ? (mins + ' ' + L('мин', 'min')) : (Math.floor(mins / 60) + L('ч ', 'h ') + (mins % 60) + L('м', 'm'));
  let html = '<div class="st-hdr">📨 ' + L('Статистика токенов', 'Token usage') + '</div><div class="st-grid">';
  html += '<div class="st-cell"><span>' + L('Запросов', 'Requests') + '</span><b>' + rrFmtNum(sessionStats.reqs) + '</b></div>';
  html += '<div class="st-cell"><span>' + L('Всего токенов', 'Total tokens') + '</span><b>' + rrFmtNum(totalTok) + '</b></div>';
  html += '<div class="st-cell"><span>' + L('Ввод', 'Input') + '</span><b>' + rrFmtNum(sessionStats.inTok) + '</b></div>';
  html += '<div class="st-cell"><span>' + L('Вывод', 'Output') + '</span><b>' + rrFmtNum(sessionStats.outTok) + '</b></div>';
  html += '<div class="st-cell"><span>' + L('≈ Стоимость', '≈ Cost') + '</span><b>' + rub.toFixed(2) + ' ₽</b></div>';
  html += '<div class="st-cell"><span>' + L('Сессия', 'Session') + '</span><b>' + dur + '</b></div>';
  html += '</div>';
  // 1.2.79: сколько сэкономлено на TokenShield (локальное сжатие текста/кода перед отправкой)
  const tsTotal = Number((S() && S().tsSavedTotal) || 0);
  html += '<div class="st-cell" style="grid-column:1/-1;background:rgba(52,211,153,.08)"><span>🛡 ' + L('TokenShield — сэкономлено', 'TokenShield — saved') + '</span><b>−' + rrFmtNum(sessionStats.tsSaved) + ' ' + L('ток. за сессию', 'tok this session')
    + (tsTotal ? ' · ' + L('всего', 'total') + ' −' + rrFmtNum(tsTotal) + ' ' + L('ток.', 'tok.') + ' (≈' + rrCostRub(tsTotal).toFixed(2) + ' ₽)' : '') + '</b></div>';
  const cin = Number(chat && chat.tokenIn) || 0, cout = Number(chat && chat.tokenOut) || 0;
  const creq = Number(chat && chat.requests) || 0;
  html += '<div class="st-sub">' + L('Этот чат', 'This chat') + ': <b>' + rrFmtNum(creq) + ' ' + L('запросов', 'requests') + '</b> · ' + rrFmtNum(cin + cout) + ' ' + L('токенов', 'tokens')
    + ' · ' + L('вес', 'weight') + ' ' + rrFmtNum(chatWeight(chat)) + '/' + rrFmtNum(chatWeightLimit()) + '</div>';
  if (sessionStats.recent.length) {
    html += '<div class="st-sub2">' + L('Последние запросы', 'Recent requests') + '</div><div class="st-list">';
    for (const r of sessionStats.recent) {
      html += '<div class="st-li"><span class="st-m">' + esc(String(r.model)) + '</span>'
        + '<span class="st-t">↑' + rrFmtNum(r.in) + ' · ↓' + rrFmtNum(r.out) + '</span></div>';
    }
    html += '</div>';
  }
  html += '<div class="st-foot"><button id="stats-reset" class="btn-ghost sm">' + L('Сбросить', 'Reset') + '</button></div>';
  return html;
}
function renderStatsPanel() {
  const p = $('#stats-panel'); if (!p) return;
  p.innerHTML = statsRows();
  const rb = $('#stats-reset');
  if (rb) rb.onclick = () => { sessionStats.reqs = 0; sessionStats.inTok = 0; sessionStats.outTok = 0; sessionStats.tsSaved = 0; sessionStats.recent = []; sessionStats.started = Date.now(); sessionRequests = 0; try { db.stats = null; saveDb(); } catch (e) {} updateRequestCounter(); renderStatsPanel(); };
}
function positionStatsPanel(p) {
  const btn = $('#req-counter'); if (!btn || !p) return;
  const r = btn.getBoundingClientRect();
  p.style.top = (r.bottom + 6) + 'px';
  p.style.left = Math.max(8, Math.min(window.innerWidth - 320, r.right - 300)) + 'px';
}
function toggleStatsPanel() {
  let p = $('#stats-panel');
  if (!p) {
    p = document.createElement('div'); p.id = 'stats-panel'; p.className = 'stats-panel hidden';
    document.body.appendChild(p);
    document.addEventListener('mousedown', (e) => {
      if (!p.classList.contains('hidden') && !p.contains(e.target) && !$('#req-counter').contains(e.target)) p.classList.add('hidden');
    });
  }
  if (p.classList.contains('hidden')) { positionStatsPanel(p); renderStatsPanel(); p.classList.remove('hidden'); }
  else p.classList.add('hidden');
}
function injectStatsCss() {
  if (document.getElementById('rr-stats-css')) return;
  const st = document.createElement('style'); st.id = 'rr-stats-css';
  st.textContent = ''
    + '#btn-debate{opacity:.55}#btn-debate.on{opacity:1;background:rgba(245,184,61,.14);border-color:rgba(245,184,61,.5);color:#f5b83d}'
    + '#req-counter{cursor:pointer}'
    + '.stats-panel{position:fixed;z-index:9000;width:300px;background:var(--panel,#1b1f27);border:1px solid var(--border,#2c333d);'
    + 'border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.5);color:var(--text,#e6e9ef);padding:12px;font-size:13px}'
    + '.stats-panel .st-hdr{font-weight:800;margin-bottom:8px}'
    + '.stats-panel .st-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px}'
    + '.stats-panel .st-cell{background:rgba(255,255,255,.04);border-radius:8px;padding:6px 8px}'
    + '.stats-panel .st-cell span{display:block;font-size:11px;color:var(--text-dim,#8b93a1)}'
    + '.stats-panel .st-cell b{font-size:15px}'
    + '.stats-panel .st-sub,.stats-panel .st-sub2{margin-top:8px;font-size:12px;color:var(--text-dim,#8b93a1)}'
    + '.stats-panel .st-list{margin-top:4px;max-height:160px;overflow:auto}'
    + '.stats-panel .st-li{display:flex;justify-content:space-between;gap:8px;padding:3px 0;border-bottom:1px solid rgba(255,255,255,.05)}'
    + '.stats-panel .st-m{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
    + '.stats-panel .st-t{color:var(--text-dim,#8b93a1);white-space:nowrap}'
    + '.stats-panel .st-foot{margin-top:8px;text-align:right}'
    + '.shell-confirm-backdrop{position:fixed;inset:0;z-index:9500;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center}'
    + '.shell-confirm-backdrop.hidden{display:none}'
    + '.shell-confirm{width:min(560px,92vw);background:var(--panel,#1b1f27);border:1px solid var(--border,#2c333d);'
    + 'border-radius:14px;box-shadow:0 18px 60px rgba(0,0,0,.6);color:var(--text,#e6e9ef);padding:16px}'
    + '.shell-confirm .sc-head{font-weight:800;font-size:15px;margin-bottom:6px}'
    + '.shell-confirm .sc-cwd{font-size:12px;color:var(--text-dim,#8b93a1);margin-bottom:8px;word-break:break-all}'
    + '.shell-confirm .sc-cmd{background:rgba(0,0,0,.35);border-radius:8px;padding:10px;margin:0 0 12px;white-space:pre-wrap;'
    + 'word-break:break-all;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px;max-height:220px;overflow:auto}'
    + '.shell-confirm .sc-btns{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}'
    // V-COMPACT: компактные ряды действий ИИ (убираем большие пустоты между строками)
    + '#messages .msg{margin:3px 0 !important}'
    + '#messages .msg.tool{margin:1px 0 !important}'
    + '#messages details.tool-line{margin:0 !important;padding:3px 8px !important}'
    + '#messages .msg-attach{margin:2px 0 !important}'
    // V-LIVEACT: живая строка «что делает ИИ»
    + '.live-act{color:var(--text-dim,#8b93a1);font-size:12.5px;font-style:italic;animation:rrPulse 1.2s ease-in-out infinite}'
    + '@keyframes rrPulse{0%,100%{opacity:.55}50%{opacity:1}}'
    // V-VERBADGE: версия терминала в правом нижнем углу
    + '.rr-version-badge{position:fixed;right:8px;bottom:6px;z-index:8000;font-size:10px;opacity:.55;'
    + 'color:var(--text-dim,#8b93a1);pointer-events:none;user-select:none}';
  document.head.appendChild(st);
}
function activityForBlocks(blocks) {
  const L = (ru, en) => LANG === 'en' ? en : ru;
  const last = blocks && blocks[blocks.length - 1];
  if (!last) return L('выполняю…', 'working…');
  const args = last.args || {};
  if (last.type === 'rr-ssh') return '🖥 ' + L('выполняю на сервере: ', 'running on server: ') + String(args.cmd || '').slice(0, 80);
  if (last.type === 'rr-shell') return '⌨️ ' + L('выполняю команду: ', 'running command: ') + String(args.cmd || args.command || '').slice(0, 80);
  if (last.type === 'rr-web') return '🌐 ' + L('работаю с интернетом: ', 'working with the web: ') + String(args.query || args.url || args.place || '').slice(0, 80);
  if (last.type === 'rr-video') return '🎬 ' + L('генерирую видео: ', 'generating video: ') + String(args.prompt || '').slice(0, 80);
  if (last.type === 'rr-rfile') return '🗂 ' + L('файлы на сервере: ', 'remote files: ') + String(args.op || '') + ' ' + String(args.path || '').slice(0, 60);
  return '📁 ' + L('работаю с файлами: ', 'working with files: ') + String(args.op || '') + ' ' + String(args.path || '').slice(0, 60);
}
function liveActDefault(m) {
  const L = (ru, en) => LANG === 'en' ? en : ru;
  return '💭 ' + L('рассуждаю и готовлю ответ…', 'reasoning and preparing an answer…');
}
function showVersionBadge() {
  try {
    rr.invoke('app:info').then((i) => {
      IS_DARWIN = /darwin|mac/i.test(String((i && i.platform) || ''));   // V-MACNOFILTER
      IS_WIN = /win/i.test(String((i && i.platform) || '')); // 1.2.83
      let b = $('#rr-version-badge');
      if (!b) { b = document.createElement('div'); b.id = 'rr-version-badge'; b.className = 'rr-version-badge'; document.body.appendChild(b); }
      b.textContent = 'v' + (i.version || '?') + ' · UI ' + (i.uiVersion || '?');
    }).catch(() => {});
  } catch (e) {}
}
function tokenShieldText(text, kind, filePath) {
  let s = normalizeNewlines(text).replace(/[ \t]+$/gm, '');
  const before = s;
  const ext = extOf(filePath || '');
  if (kind === 'json' || ext === 'json' || ext === 'jsonc') {
    try { s = JSON.stringify(JSON.parse(s)); } catch (e) {}
  }
  if (['html', 'htm', 'xml', 'svg'].includes(ext)) s = s.replace(/<!--[\s\S]*?-->/g, ' ');
  if (['css', 'scss', 'less'].includes(ext)) s = s.replace(/\/\*[\s\S]*?\*\//g, ' ');
  if (['log', 'txt', 'md', 'markdown', 'csv', 'tsv', 'sql', 'yml', 'yaml', 'ini', 'cfg', 'conf', 'env', 'js', 'ts', 'jsx', 'tsx', 'py', 'rb', 'php', 'c', 'cpp', 'h', 'hpp', 'java', 'kt', 'go', 'rs', 'swift', 'dart', 'vue', 'svelte', 'sh', 'bash', 'ps1'].includes(ext)) {
    s = s.replace(/\n{3,}/g, '\n\n');
  }
  s = s.trim();
  return { text: s, beforeTokens: estimateTokens(before), afterTokens: estimateTokens(s) };
}
function maybeShieldText(text, filePath) {
  if (!S().tokenShield) return { text: text || '', beforeTokens: estimateTokens(text || ''), afterTokens: estimateTokens(text || '') };
  const r = tokenShieldText(text || '', 'text', filePath || '');
  // 1.2.79: учитываем экономию — сколько токенов НЕ ушло в модель благодаря сжатию
  const saved = Math.max(0, (r.beforeTokens || 0) - (r.afterTokens || 0));
  if (saved > 0) {
    sessionStats.tsSaved += saved;
    try { S().tsSavedTotal = (Number(S().tsSavedTotal) || 0) + saved; } catch (e) {}
  }
  return r;
}
function escapeRe(s) { return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function highlightSnippet(text, query) {
  if (!query) return esc(text || '');
  const re = new RegExp(escapeRe(query), 'ig');
  return esc(text || '').replace(re, (m) => `<mark>${m}</mark>`);
}
function renderSearchSnippetHtml(snippet, query) {
  const lines = String(snippet || '').split('\n').map((raw) => {
    const m = raw.match(/^(\d+):\s?(.*)$/);
    return m ? { no: m[1], text: m[2] || '' } : { no: '', text: raw };
  });
  return `<div class="preview match-view search-hit-code">${lines.map((row) => {
    const hit = query && row.text.toLowerCase().includes(String(query).toLowerCase());
    return `<div class="preview-line${hit ? ' hit' : ''}"><span class="ln">${esc(row.no)}</span><span class="lc">${highlightSnippet(row.text, query)}</span></div>`;
  }).join('')}</div>`;
}

/* ------------------------------ темы ------------------------------ */

function applyTheme() {
  const th = S().theme === 'light' ? 'light' : 'dark';
  document.documentElement.dataset.theme = th;
  $('#hljs-dark').disabled = th === 'light';
  $('#hljs-light').disabled = th !== 'light';
}

/* ------------------------------ сайдбар ------------------------------ */

function chatById(id) { return db.chats.find((c) => c.id === id); }
function currentChat() { return chatById(currentChatId); }

function renderChatList() {
  const q = ($('#chat-search').value || '').toLowerCase().trim();
  const list = $('#chat-list');
  list.innerHTML = '';
  const chats = db.chats
    .filter((c) => !q || (c.title || '').toLowerCase().includes(q))
    // V-PIN: закреплённые чаты всегда сверху, дальше — по времени изменения
    .sort((a, b) => ((b.pinned ? 1 : 0) - (a.pinned ? 1 : 0)) || (b.updatedAt - a.updatedAt));
  if (!chats.length) { list.innerHTML = '<div class="empty-note">' + esc(t('noChats')) + '</div>'; return; }
  for (const c of chats) {
    const el = document.createElement('div');
    el.className = 'chat-item' + (c.id === currentChatId ? ' active' : '') + (c.pinned ? ' pinned' : '');
    el.innerHTML = `<span class="ci-pin" title="${esc(c.pinned ? t('unpinChat') : t('pinChat'))}">📌</span>
      <span class="ci-title">${esc(c.title || '—')}${streamsByChat.has(c.id) ? ' <b class="ci-busy">●</b>' : ''}</span>
      <span class="ci-date">${fmtDate(c.updatedAt)}</span>
      <button class="ci-del" title="${esc(t('mDel'))}">✕</button>`;
    el.querySelector('.ci-pin').onclick = (e) => { e.stopPropagation(); togglePinChat(c.id); };
    el.querySelector('.ci-del').onclick = (e) => { e.stopPropagation(); deleteChat(c.id); };
    el.onclick = () => openChat(c.id);
    list.appendChild(el);
  }
}
/* V-PIN: закрепить/открепить чат в списке слева */
function togglePinChat(id) {
  const c = db.chats.find((x) => x.id === id);
  if (!c) return;
  c.pinned = !c.pinned;
  saveDb();
  renderChatList();
  try { toast(c.pinned ? t('chatPinned') : t('chatUnpinned')); } catch (e) {}
}

function newChat(silent) {
  const c = { id: 'c' + Date.now().toString(36), title: '', createdAt: Date.now(), updatedAt: Date.now(), messages: [] };
  db.chats.unshift(c);
  currentChatId = c.id;
  try { const ta = $('#composer-input'); if (ta) { ta.value = ''; autosize(); } } catch (eD) {}
  saveDb();
  renderChatList(); renderMessages(); updateChatTitle(); refreshComposerForChat();
  if (!silent) $('#composer-input').focus();
  return c;
}

function openChat(id) {
  // V-DRAFT (1.2.91): черновик ввода хранится ПО ЧАТАМ — набранный текст не переезжает
  // в другой чат и не теряется при переключении.
  try {
    const prev = currentChat();
    const ta0 = $('#composer-input');
    if (prev && ta0 && prev.id !== id) {
      const v = String(ta0.value || '');
      if (v.trim()) prev.__draft = v; else delete prev.__draft;
      saveDb();
    }
  } catch (eD) {}
  currentChatId = id;
  const chat = currentChat();
  try {
    const ta1 = $('#composer-input');
    if (ta1) { ta1.value = (chat && chat.__draft) || ''; autosize(); }
  } catch (eD) {}
  renderChatList(); renderMessages(); updateChatTitle(); refreshComposerForChat();
  vRunInd();
}
function vRunInd() {
  // V-RUNCHAT (1.2.91): индикатор «генерация» показывает состояние ТЕКУЩЕГО чата,
  // а не любого стрима в приложении.
  try {
    const st = currentChatId && streamsByChat.get(currentChatId);
    if (st) { setRunIndicator('work'); runStartTs = st.startedAt || runStartTs; startRunClock(runStartTs); }
    else if (!chatIsStreaming(currentChatId)) { stopRunClock(); setRunIndicator('idle'); }
  } catch (eR) {}
}

function deleteChat(id) {
  if (streaming && streaming.chatId === id) stopStream();
  db.chats = db.chats.filter((c) => c.id !== id);
  if (currentChatId === id) currentChatId = db.chats.length ? db.chats[0].id : null;
  saveDb(); renderChatList(); renderMessages(); updateChatTitle();
}

function updateChatTitle() {
  const c = currentChat();
  try { updateRequestCounter(); } catch (e) {}
  const el = $('#chat-title');
  if (!el) return;
  const title = c ? (c.title || t('newChat')) : '';
  if (!el.classList.contains('editing')) el.textContent = title;
  el.title = title || t('newChat');
}
function commitChatTitle(next) {
  const c = currentChat();
  if (!c) return;
  const value = String(next || '').trim().replace(/\s+/g, ' ').slice(0, 120);
  c.title = value || (c.messages.find((m) => m.role === 'user' && m.content)?.content || t('newChat')).slice(0, 48);
  c.updatedAt = Date.now();
  saveDb();
  renderChatList();
  updateChatTitle();
  toast(t('titleSaved'));
}
function enableChatTitleEditing() {
  const el = $('#chat-title');
  const c = currentChat();
  if (!el || !c) return;
  el.contentEditable = 'true';
  el.classList.add('editing');
  el.spellcheck = false;
  el.textContent = c.title || '';
  const sel = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(el); range.collapse(false);
  sel.removeAllRanges(); sel.addRange(range);
  el.focus();
}
function disableChatTitleEditing(save) {
  const el = $('#chat-title');
  if (!el || !el.classList.contains('editing')) return;
  const next = el.textContent;
  el.contentEditable = 'false';
  el.classList.remove('editing');
  if (save) commitChatTitle(next);
  else updateChatTitle();
}

/* ------------------------------ сообщения ------------------------------ */

function renderMessages() {
  try { updateContChip(); } catch (eC) {}
    let c = currentChat();
  const welcome = $('#welcome'), scroll = $('#chat-scroll'), comp = $('#composer-wrap');
  if (!c && !db.chats.length) {
    if (S().apiKey) {
      c = newChat(true);
    } else {
      welcome.classList.remove('hidden'); scroll.classList.add('hidden'); comp.classList.add('hidden');
      const wk = $('#welcome-key'); if (wk && S().apiKey) wk.value = S().apiKey;
      updateWelcomeVisibility();
      return;
    }
  }
  if (!c) c = newChat(true);
  welcome.classList.add('hidden'); scroll.classList.remove('hidden'); comp.classList.remove('hidden');

  const box = $('#messages');
  box.innerHTML = '';
  // V-HIST1: строки действий терминала остаются в истории — не пропускаем role==='tool'.
  for (const m of currentChat().messages) {
    box.appendChild(renderMessage(m));
  }
  enhanceCode(box);
  scrollDown(true);
}

function renderMessage(m) {
  // ---- тул-результат (SSH/файлы от ИИ) ----
  if (m.role === 'tool') {
    const el = document.createElement('div');
    el.className = 'msg tool';
    const okTxt = m.ok ? '<span class="tstat ok">exit 0 ✓</span>' : '<span class="tstat fail">exit ✗</span>';
    const icon = /SSH/i.test(m.label||'') ? '🖥' : /remote/i.test(m.label||'') ? '🗂' : /balance/i.test(m.label||'') ? '💰' : '▶';
    el.innerHTML = `<details class="tool-line" ${m.ok?'':'open'}>
      <summary><span class="ticon">${icon}</span><span class="tlabel">${esc(m.label || '🔧')}</span>${okTxt}</summary>
      <pre class="tool-out ${m.ok ? 'ok' : 'fail'}">${esc((m.content || '').slice(0, 8000))}</pre>
    </details>`;
    // V-FILEONCE: новые сообщения копят пути в общую сводку; старые (из БД) — как раньше
    const found = extractFilePaths((m.content || '') + '\n' + (m.label || ''));
    if (m.collectFiles) collectTurnFilePaths(found);
    else if (found.length && !m.noCards) el.appendChild(fileActionCards(found));
    return el;
  }
  const el = document.createElement('div');
  el.className = 'msg ' + (m.role === 'user' ? 'user' : 'assistant');
  const av = m.role === 'user' ? '👤' : '🤖'; // 1.2.83: логотип-робот (видим и в тёмной, и в светлой теме)
  const who = m.role === 'user' ? (LANG === 'en' ? 'You' : 'Вы') : (m.modelName || 'RiskRadar');
  let contentHtml;
  if (m.error) contentHtml = '<div class="error-box">⚠ ' + esc(m.content) + '</div>';
  else if (m.role === 'user') contentHtml = esc(m.content || '');
  else {
    const visibleText = stripAssistantDisplayText(m.content || '');
    const toolOnly = !visibleText.trim() && extractToolBlocks(m.content || '').length > 0;
    if (toolOnly) {
      // V-LIVEACT: вместо голого «Генерация…» показываем, КАКОЕ действие сейчас идёт
      contentHtml = '<div class="tool-call-note live-act">' + esc(activityForBlocks(extractToolBlocks(m.content || ''))) + '</div>';
    } else {
      contentHtml = renderMd(visibleText);
      // V-LIVEACT: пузырь пуст, модель «молчит» (поиск/размышление) — видно, что делает ИИ
      if (m.streaming && !visibleText.trim() && !m.reasoning) contentHtml = '<div class="live-act">' + esc(liveActDefault(m)) + '</div>';
    }
    if (m.streaming) contentHtml += '<span class="stream-cursor"></span>';
  }
  const reasoning = (m.role === 'assistant' && m.reasoning)
    ? `<details class="reason-box"${m.streaming ? ' open' : ''}><summary>💭 ${esc(t('reasonTitle'))}</summary><pre class="reason-txt">${esc(String(m.reasoning).slice(-6000))}</pre></details>`
    : '';
  let atts = '';
  if (m.role === 'user' && (m.attachments || []).length + (m.images || []).length) {
    atts = '<div class="msg-attach">' +
      (m.images || []).map((i) => `<span class="chip"><img src="${i.dataUrl}" alt=""><span>${esc(i.name || 'img')}</span></span>`).join('') +
      (m.attachments || []).map((a, ai) => {
        // V-MEMFIX: кнопка DOCX на текстовых вложениях (.md/.txt) — конвертация в один клик
        const canDocx = a && a.kind === 'text' && typeof a.content === 'string' && a.content.length > 0 && /\.(md|markdown|txt)$/i.test(String(a.name || ''));
        return `<span class="chip">📄<span title="${esc(a.path || a.name)}">${esc(a.name)}</span>` +
          (canDocx ? `<button class="chip-btn" data-docx="${ai}" title="${esc(t('docxBtn'))}">DOCX</button>` : '') + `</span>`;
      }).join('') +
      '</div>';
  }
  const meta = !m.streaming
    ? `<div class="meta">
         <button data-act="copy" title="${esc(t('mCopy'))}">📋 ${esc(t('mCopy'))}</button>
         <button data-act="regen" title="${esc(t('mRegen'))}">↻ ${esc(t('mRegen'))}</button>
         <button data-act="del" class="danger" title="${esc(t('mDel'))}">🗑</button>
         ${m.role === 'assistant' && !m.error ? `<button data-act="save" title="${esc(t('mSave'))}">💾</button>` : ''}
       </div>` : '';
  el.innerHTML = `<div class="avatar">${av}</div>
    <div class="body">
      <div class="who">${esc(who)}${m.ts ? `<span style="font-weight:400;color:var(--text-faint)">${new Date(m.ts).toLocaleTimeString(LANG === 'en' ? 'en-GB' : 'ru-RU', {hour:'2-digit',minute:'2-digit'})}</span>` : ''}</div>
      ${reasoning}
      <div class="content">${atts}${contentHtml}</div>
      ${meta}
    </div>`;
  const chat = currentChat();
  const idx = chat ? chat.messages.indexOf(m) : -1;
  el.dataset.msgIndex = String(idx);
  const metaEl = el.querySelector('.meta');
  if (metaEl) metaEl.onclick = (e) => {
    const act = e.target.dataset && e.target.dataset.act;
    if (!act) return;
    if (act === 'copy') navigator.clipboard.writeText(m.content || '');
    if (act === 'save') saveMessageToFile(m);
    if (act === 'del') {
      if (streaming && streaming.chatId === currentChatId) return;
      const ch = currentChat();
      ch.messages.splice(idx, 1);
      saveDb(); renderMessages();
    }
    if (act === 'regen') {
      if (streaming && streaming.chatId === currentChatId) return;
      const ch = currentChat();
      if (m.role === 'assistant') {
        let i = idx;
        while (i < ch.messages.length && ch.messages[i].role !== 'user') i++;
        ch.messages = ch.messages.slice(0, i);
      } else {
        ch.messages = ch.messages.slice(0, idx + 1);
      }
      saveDb(); renderMessages();
      runAssistant(ch);
    }
  };
  const attEl = el.querySelector('.msg-attach');
  if (attEl) attEl.onclick = (e) => {
    const b = e.target && e.target.closest ? e.target.closest('[data-docx]') : null;
    if (!b) return;
    const a = (m.attachments || [])[Number(b.getAttribute('data-docx'))];
    if (a) convertAttachmentToDocx(a);
  };
  // V-FILEONCE: одна сводка файлов + чипы @-упоминаний
  try {
    const bodyEl = el.querySelector('.body');
    /* V-NOFILELIST: пользователь попросил убрать список «📁 Файлы из ответа» из сообщений.
       Блок не рендерится (кнопки docx-конвертации вложениями остаются в .msg-attach). */
    if (false && bodyEl && m.role === 'assistant' && Array.isArray(m.fileActions) && m.fileActions.length) {
      const wrap = document.createElement('div');
      wrap.className = 'files-summary';
      const cap = document.createElement('div');
      cap.className = 'files-summary-cap';
      cap.textContent = '📁 ' + t('filesSummary');
      wrap.appendChild(cap);
      wrap.appendChild(fileActionCards(m.fileActions.slice(0, 12)));
      bodyEl.appendChild(wrap);
    }
    if (bodyEl && m.role === 'user' && Array.isArray(m.mentions) && m.mentions.length) {
      const chips = document.createElement('div');
      chips.className = 'msg-attach';
      chips.innerHTML = m.mentions.map((x) => `<span class="chip">@<span title="${esc(x.path || x.name || '')}">${esc(x.name || x.path || '')}</span></span>`).join('');
      const contentEl = bodyEl.querySelector('.content');
      if (contentEl) contentEl.insertBefore(chips, contentEl.firstChild);
    }
  } catch (e) {}
  return el;
}

function scrollDown(force) {
  const sc = $('#chat-scroll');
  if (!sc) return;
  const nearBottom = sc.scrollHeight - sc.scrollTop - sc.clientHeight < 160;
  if (force || nearBottom) sc.scrollTop = sc.scrollHeight;
}

/* ------------------------------ протокол ИИ-инструментов ------------------------------ */

/* V-SKILLS: каталог навыков терминала. Взят из списка навыков Chatbox.
   n — идентификатор, s — источник, d — когда применять, g — как применять в терминале. */
const RR_SKILLS = [{"n":"chatbox-product-info","s":"Встроенные навыки","d":"Chatbox product and billing information specialist. Use when the conversation mentions Chatbox AI, Chatbox product features, subscriptions, pricing, paid plans, licenses, billing, authentication, developer docs, or MCP access.","g":"Справка по продукту Chatbox (тарифы, лицензии, биллинг). Нужна, только когда вопрос реально про Chatbox."},{"n":"vibedrop","s":"Встроенные навыки","d":"Deploy any static site or build output to a public URL via the VibeDrop hosting service. Use when the user asks to share, deploy, publish, host, or preview a web page, landing page, static site, or HTML/CSS/JS bundle — including \"give me a URL\", \"send this to a friend\", or \"put this on the internet\". Also handles redeploys and surfacing existing site URLs.","g":"Публикация статики в интернет. Нужна, когда просят дать ссылку на готовую страницу."},{"n":"a-stock-data","s":"Встроенные навыки","d":"Node.js-only A-share market data specialist. Use for China A-stock quotes, valuation, research reports, sector themes, capital flow, dragon tiger board, lockup expiry, financing and securities lending, block trades, shareholder counts, dividends, filings, limit-up sentiment, ETF quotes/options, investor Q&A, hot lists, and market heat analysis.","g":"Данные по рынку акций Китая. Бери реальные цифры через rr-web, не выдумывай."},{"n":"data-analysis","s":"Встроенные навыки","d":"Data analysis specialist. Analyzes datasets, identifies patterns, generates insights, and creates summary reports. Use when working with data, statistics, or analytical tasks.","g":"Разбор данных: файл читай через rr-file, считай и проверяй через rr-ssh, результат сохраняй файлом."},{"n":"frontend-design","s":"Встроенные навыки","d":"Guidance for distinctive, intentional visual design when building new UI or reshaping an existing one. Helps with aesthetic direction, typography, and making choices that don't read as templated defaults.","g":"Вёрстка: правки через rr-file, проверка результата через rr-web view или сборку."},{"n":"global-stock-data","s":"Встроенные навыки","d":"Node.js-only global stock data specialist for US and Hong Kong markets. Use for US/HK stock quotes, K-lines, technical indicators, financial statements, key fundamentals, analyst expectations, institutional holdings, fund flow, options chains, SEC filings, XBRL metrics, stock search, news, market ranking, and full-market screening.","g":"Данные по рынкам США и Гонконга. Бери реальные цифры через rr-web, не выдумывай."},{"n":"guizang-ppt-skill","s":"Встроенные навыки","d":"HTML-only horizontal web PPT skill with electronic magazine and Swiss-style templates. Use when the user wants a single-file HTML presentation, magazine-style PPT, Swiss-style PPT, or horizontal swipe deck. Image generation is disabled; use user-provided local images or HTML/CSS placeholders.","g":"HTML-презентация одним файлом: собирай через rr-file и сохраняй на диск."},{"n":"humanizer-zh","s":"Встроенные навыки","d":"Chinese writing editor that removes common AI-generated writing traces and rewrites text in a more natural human voice. Use when editing, reviewing, or humanizing Chinese text.","g":"Редактирование китайского текста: убирай машинные обороты, делай речь естественной."},{"n":"brainstorming","s":"obra/superpowers","d":"You MUST use this before any creative work - creating features, building components, adding functionality, or modifying behavior. Explores user intent, requirements and design before implementation.","g":"Перед созданием новой функции сначала выясни требования вопросами. Не начинай писать код, пока не ясны цель и ограничения."},{"n":"browser-use","s":"browser-use/browser-use","d":"Direct browser control via CDP for web interaction: automation, scraping, testing, screenshots, and site/app work.","g":"Браузером управляет сам терминал: rr-web {\"op\":\"view\",\"url\":\"…\"} — открыть страницу и посмотреть её, rr-web {\"op\":\"fetch\",\"url\":\"…\"} — прочитать текст. Всегда указывай ПОЛНЫЙ URL вместе с путём и не подменяй адрес корнем сайта. Если текста мало — открой через view и опиши, что видно."},{"n":"cloud","s":"browser-use/browser-use","d":"Documentation reference for using Browser Use Cloud — the hosted API and SDK for browser automation. Use this skill whenever the user needs help with the Cloud REST API (v2, v3, or v4), browser-use-sdk (Python or TypeScript), X-Browser-Use-API-Key authentication, cloud sessions, browser profiles, profile sync, CDP WebSocket connections, stealth browsers, residential proxies, CAPTCHA handling, webhooks, workspaces, skills marketplace, liveUrl streaming, pricing, or integration patterns (chat UI, subagent, adding browser tools to existing agents). Also trigger for questions about n8n/Make/Zapier integration, Playwright/ Puppeteer/Selenium on cloud infrastructure, or 1Password vault integration. Do NOT use this for the open-source Python library (Agent, Browser, Tools config) — use the open-source skill instead.","g":"Справочный навык по Browser Use Cloud. Кодом в терминале не исполняется, используй как документацию."},{"n":"dispatching-parallel-agents","s":"obra/superpowers","d":"Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies","g":"Независимые задачи выполняй отдельными проходами, не смешивай их в одном шаге."},{"n":"executing-plans","s":"obra/superpowers","d":"Use when you have a written implementation plan to execute in a separate session with review checkpoints","g":"Исполняй план по шагам, после каждого шага проверяй результат и отмечай прогресс в progress.md."},{"n":"finishing-a-development-branch","s":"obra/superpowers","d":"Use when implementation is complete, all tests pass, and you need to decide how to integrate the work","g":"Завершение ветки: прогони проверки, покажи их вывод, затем предложи слияние."},{"n":"impeccable","s":"pbakaus/impeccable","d":"Use when the user wants to design, redesign, shape, critique, audit, polish, clarify, distill, harden, optimize, adapt, animate, colorize, extract, or otherwise improve a frontend interface. Covers websites, landing pages, dashboards, product UI, app shells, components, forms, settings, onboarding, and empty states. Handles UX review, visual hierarchy, information architecture, cognitive load, accessibility, performance, responsive behavior, theming, anti-patterns, typography, fonts, spacing, layout, alignment, color, motion, micro-interactions, UX copy, error states, edge cases, i18n, and reusable design systems or tokens. Also use for bland designs that need to become bolder or more delightful, loud designs that should become quieter, live browser iteration on UI elements, or ambitious visual effects that should feel technically extraordinary. Not for backend-only or non-UI tasks.","g":"Работа над интерфейсом: правь HTML/CSS/JS через rr-file, затем проверяй результат — открой страницу через rr-web view."},{"n":"open-source","s":"browser-use/browser-use","d":"Documentation reference for writing Python code using the browser-use open-source library. Use this skill whenever the user needs help with Agent, Browser, or Tools configuration, is writing code that imports from browser_use, asks about @sandbox deployment, supported LLM models, Actor API, custom tools, lifecycle hooks, MCP server setup, or monitoring/observability with Laminar or OpenLIT. Also trigger for questions about browser-use installation, prompting strategies, or sensitive data handling. Do NOT use this for Cloud API/SDK usage or pricing — use the cloud skill instead. Do NOT use this for directly automating a browser via CLI commands — use the browser-use skill instead.","g":"Справочный навык по библиотеке browser-use. В терминале не исполняется, используй как справку."},{"n":"pi-planning-with-files","s":"OthmanAdi/planning-with-files","d":"Persistent file-based planning for multi-step AI-agent work. Keeps task_plan.md, findings.md, and progress.md on disk; lifecycle hooks inject selected project planning context. Automatic recovery reads project planning files only. Explicit session-catchup.py --metadata reads same-project local agent session records and emits aggregate counts only; --replay may emit bounded nonce-framed excerpts. Optional gated mode can request continuation only when the host supports it and never runs commands declared in Markdown. The skill has no network upload path. Use for research or work needing 5+ tool calls."},{"n":"planning-with-files","s":"OthmanAdi/planning-with-files","d":"Persistent file-based planning for multi-step AI-agent work. Keeps task_plan.md, findings.md, and progress.md on disk; lifecycle hooks inject selected project planning context. Automatic recovery reads project planning files only. Explicit session-catchup.py --metadata reads same-project local agent session records and emits aggregate counts only; --replay may emit bounded nonce-framed excerpts. Optional gated mode can request continuation only when the host supports it and never runs commands declared in Markdown. The skill has no network upload path. Use for research or work needing 5+ tool calls.","g":"Держи task_plan.md и progress.md в рабочем каталоге (rr-file write/append), чтобы не терять состояние между шагами."},{"n":"planning-with-files-ar","s":"OthmanAdi/planning-with-files","d":"تخطيط مستمر قائم على الملفات لعمل وكلاء الذكاء الاصطناعي متعدد الخطوات. يحتفظ بملفات task_plan.md و findings.md و progress.md على القرص، وتحقن خطافات دورة الحياة سياق التخطيط المحدد للمشروع. تقرأ الاستعادة التلقائية ملفات تخطيط المشروع فقط. يمكن للأمر الصريح session-catchup.py --metadata فحص بيانات وصفية لجلسات الوكيل المحلية التابعة للمشروع نفسه، بينما قد يصدر --replay مقتطفات محدودة مؤطرة بقيمة nonce. يمكن للوضع المحكوم الاختياري طلب المتابعة فقط عندما يدعمه المضيف، ولا ينفذ أبدًا أوامر معلنة في Markdown. لا تتضمن المهارة مسارًا لرفع البيانات عبر الشبكة. تُستخدم للبحث أو العمل الذي يحتاج إلى 5 استدعاءات أدوات أو أكثر."},{"n":"planning-with-files-de","s":"OthmanAdi/planning-with-files","d":"Persistente dateibasierte Planung für mehrstufige Arbeit mit KI-Agenten. Hält task_plan.md, findings.md und progress.md auf dem Datenträger; Lebenszyklus-Hooks speisen ausgewählten Planungskontext des Projekts ein. Die automatische Wiederherstellung liest nur die Planungsdateien des Projekts. Nur ein ausdrücklicher Aufruf von session-catchup.py --metadata darf lokale Sitzungsmetadaten desselben Projekts prüfen; --replay darf begrenzte, nonce-gerahmte Auszüge ausgeben. Der optionale Gate-Modus kann nur bei Unterstützung durch den Host eine Fortsetzung anfordern und führt niemals in Markdown angegebene Befehle aus. Der Skill hat keinen Netzwerk-Uploadpfad. Verwenden für Forschung oder Arbeit mit mehr als 5 Tool-Aufrufen."},{"n":"planning-with-files-es","s":"OthmanAdi/planning-with-files","d":"Planificación persistente basada en archivos para tareas multipaso de agentes de IA. Mantiene task_plan.md, findings.md y progress.md en disco; los hooks del ciclo de vida inyectan contexto seleccionado de planificación del proyecto. La recuperación automática solo lee los archivos de planificación del proyecto. session-catchup.py --metadata, solicitado de forma explícita, puede inspeccionar metadatos locales de sesiones del mismo proyecto; --replay puede emitir extractos limitados y enmarcados con nonce. El modo con gate opcional solo puede solicitar que el host continúe si este lo admite y nunca ejecuta comandos declarados en Markdown. El skill no tiene ninguna ruta de carga por red. Úsalo para investigación o trabajo que requiera 5 o más llamadas a herramientas."},{"n":"planning-with-files-zh","s":"OthmanAdi/planning-with-files","d":"用于多步骤 AI 代理工作的持久化文件规划系统。将 task_plan.md、findings.md 和 progress.md 保存在磁盘上，生命周期钩子会注入选定的项目规划上下文。自动恢复只读取项目规划文件。只有显式运行 session-catchup.py --metadata 才会检查本机同项目的会话元数据；--replay 可输出有长度限制且由 nonce 框定的同项目摘录。可选门禁仅在宿主支持时请求继续，绝不执行 Markdown 中声明的命令。本技能没有网络上传路径。适用于研究或需要 5 次以上工具调用的工作。触发词：任务规划、项目计划、制定计划、分解任务、多步骤规划、进度跟踪、文件规划、帮我规划、拆解项目"},{"n":"planning-with-files-zht","s":"OthmanAdi/planning-with-files","d":"用於多步驟 AI 代理工作的持久化檔案規劃。將 task_plan.md、findings.md 與 progress.md 保存在磁碟上，生命週期鉤子會注入選定的專案規劃內容。自動恢復只讀取專案規劃檔案；只有明確執行 session-catchup.py --metadata 才會檢查本機同一專案的代理工作階段中繼資料，--replay 則會輸出有界且以 nonce 框定的摘錄。選用的閘門模式只會在主機支援時要求繼續，而且絕不執行 Markdown 中宣告的命令。此技能沒有網路上傳路徑。適用於研究或需要超過 5 次工具呼叫的工作。觸發詞：任務規劃、專案計畫、制定計畫、分解任務、多步驟規劃、進度追蹤、檔案規劃、幫我規劃、拆解專案"},{"n":"playwright-skill","s":"lackeyjb/playwright-skill","d":"Complete browser automation with Playwright. Auto-detects dev servers, writes reusable test scripts, and supports screenshots, responsive checks, UX validation, login flows, link checks, and arbitrary browser automation. Use when the user wants to test a website, automate browser interactions, validate web functionality, or perform browser-based testing.","g":"Playwright в терминал не встроен. Проверяй страницу так: rr-web view — посмотреть, rr-web fetch — прочитать текст, затем сверить ожидаемое с фактическим и показать разницу."},{"n":"qa","s":"browser-use/browser-use","d":"QA-test a website or web app and return a 1-5 quality score (5 = flawless, 1 = broken) with evidence. Use when the user wants to test, QA, evaluate, score, or \"check how good\" a site, page, flow, or app — including a local dev server (e.g. \"qa test localhost:5173\", \"does the checkout work?\", \"rate this landing page\"). Drives a real Browser Use cloud browser, tunneling localhost automatically.","g":"Оцени страницу по шкале 1-5: открой через rr-web view, прочитай через fetch, перечисли проблемы с доказательствами — что именно на странице это подтверждает."},{"n":"receiving-code-review","s":"obra/superpowers","d":"Use when receiving code review feedback, before implementing suggestions, especially if feedback seems unclear or technically questionable - requires technical rigor and verification, not performative agreement or blind implementation","g":"Проверяй замечания по фактам: воспроизведи, подтверди или опровергни. Не соглашайся вслепую, даже если замечание звучит уверенно."},{"n":"remote-browser","s":"browser-use/browser-use","d":"Controls an isolated Browser Use Cloud browser from a sandboxed machine with the current Browser Use CLI.","g":"Облачный браузер недоступен. Используй встроенный браузер терминала: rr-web {\"op\":\"view\",\"url\":\"…\"}."},{"n":"requesting-code-review","s":"obra/superpowers","d":"Use when completing tasks, implementing major features, or before merging to verify work meets requirements","g":"Перед тем как объявить работу законченной, пройди по требованиям и подтверди каждое фактом из кода или команды."},{"n":"subagent-driven-development","s":"obra/superpowers","d":"Use when executing implementation plans with independent tasks in the current session","g":"Раздели работу на независимые задачи и выполняй их по очереди блоками, проверяя каждую."},{"n":"systematic-debugging","s":"obra/superpowers","d":"Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes","g":"Работай фактами, а не догадками: сначала воспроизведи проблему и собери реальный вывод (rr-ssh для сервера и логов, rr-file для кода), найди корневую причину, и только потом правь."},{"n":"test-driven-development","s":"obra/superpowers","d":"Use when implementing any feature or bugfix, before writing implementation code","g":"Сначала проверка, потом код: создай тест или сценарий проверки через rr-file, запусти через rr-ssh, и только затем правь реализацию."},{"n":"understand","s":"Egonex-AI/Understand-Anything","d":"Analyze a codebase to produce an interactive knowledge graph for understanding architecture, components, and relationships","g":"Разбор кода: найди символы через rr-file {\"op\":\"search\"} и rr-file {\"op\":\"open\"}, затем объясни связи между файлами и модулями."},{"n":"understand-chat","s":"Egonex-AI/Understand-Anything","d":"Use when you need to ask questions about a codebase or understand code using a knowledge graph","g":"Отвечай на вопросы по коду, опираясь на реально прочитанные файлы (rr-file read/search), а не на предположения."},{"n":"understand-dashboard","s":"Egonex-AI/Understand-Anything","d":"Launch the interactive web dashboard to visualize a codebase's knowledge graph"},{"n":"understand-diff","s":"Egonex-AI/Understand-Anything","d":"Use when you need to analyze git diffs or pull requests to understand what changed, affected components, and risks","g":"Разбор изменений: прочитай diff или файлы через rr-file, перечисли затронутые компоненты и риски."},{"n":"understand-domain","s":"Egonex-AI/Understand-Anything","d":"Extract business domain knowledge from a codebase and generate an interactive domain flow graph. Works standalone (lightweight scan) or derives from an existing /understand knowledge graph.","g":"Разбор предметной области: пройди по коду и выпиши сущности и потоки данных."},{"n":"understand-explain","s":"Egonex-AI/Understand-Anything","d":"Use when you need a deep-dive explanation of a specific file, function, or module in the codebase","g":"Глубокий разбор файла или функции: rr-file open с запросом, затем объяснение по строкам."},{"n":"understand-figma","s":"Egonex-AI/Understand-Anything","d":"Analyze a Figma file via the Figma REST API and generate an interactive design knowledge graph (pages, screens, components, component sets, instances, design tokens) with a kind:\"design\" dashboard."},{"n":"understand-knowledge","s":"Egonex-AI/Understand-Anything","d":"Analyze a Karpathy-pattern LLM wiki knowledge base and generate an interactive knowledge graph with entity extraction, implicit relationships, and topic clustering."},{"n":"understand-onboard","s":"Egonex-AI/Understand-Anything","d":"Use when you need to generate an onboarding guide for new team members joining a project","g":"Составь руководство для нового разработчика: структура проекта, точки входа, как запускать и проверять."},{"n":"using-git-worktrees","s":"obra/superpowers","d":"Use when starting feature work that needs isolation from current workspace or before executing implementation plans - ensures an isolated workspace exists via native tools or git worktree fallback","g":"Работа с ветками и изоляцией: команды через rr-ssh либо файловые операции в рабочем каталоге."},{"n":"using-superpowers","s":"obra/superpowers","d":"Use when starting any conversation - establishes how to find and use skills, requiring skill invocation before ANY response including clarifying questions","g":"Перед работой подбери подходящий навык через rr-skill и следуй ему."},{"n":"verification-before-completion","s":"obra/superpowers","d":"Use when about to claim work is complete, fixed, or passing, before committing or creating PRs - requires running verification commands and confirming output before making any success claims; evidence before assertions always","g":"Перед словом «готово» обязательно запусти проверку — команду, открытие страницы, чтение файла — и покажи её настоящий вывод. Без подтверждённого вывода успех не объявляй."},{"n":"writing-plans","s":"obra/superpowers","d":"Use when you have a spec or requirements for a multi-step task, before touching code","g":"Сначала план шагами в файле (rr-file write), затем исполнение по шагам с проверкой после каждого шага."},{"n":"writing-skills","s":"obra/superpowers","d":"Use when creating new skills, editing existing skills, or verifying skills work before deployment","g":"Навык про создание навыков: новый навык — это описание «когда применять» плюс инструкция."},{"n":"x402","s":"browser-use/browser-use","d":"Set up Browser Use Cloud payments with x402 — pay per request from a crypto wallet (USDC on Base mainnet), no signup or API key. Two setups it works out up front — \"just use it\" (set up a wallet so you or Claude Code can run cloud browser tasks paid from the wallet — Claude writes and runs throwaway scripts, nothing touches your codebase) or \"build it in\" (install the SDK and write the key + code into your project). Walks through wallet setup, funding, .env, and a ~$1 test run. Use when the user asks about x402, pay-per-use, USDC payments, or wants Browser Use Cloud without an API key. For the free-tier signup (reverse-CAPTCHA → API key), use `browser-use cloud signup` or the `cloud` skill instead.","g":"Навык про оплату x402 крипто-кошельком. В терминале не исполняется, используй как справку."}];

/* V-GHSKILLS: навыки, установленные с GitHub (папка с SKILL.md) */
let githubSkills = [];
function allSkills() { return RR_SKILLS.concat(githubSkills); }
function skillByName(name) {
  const n = String(name || '').trim().toLowerCase();
  if (!n) return null;
  const all = allSkills();
  return all.find((s) => s.n.toLowerCase() === n)
    || all.find((s) => s.n.toLowerCase().indexOf(n) === 0)
    || null;
}
function firstSentence(text) {
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  const m = t.match(/^(.{40,160}?[.!?])\s/);
  return (m ? m[1] : t.slice(0, 160)).trim();
}
function skillsPrompt() {
  const all = allSkills();
  if (!all.length) return '';
  const lines = all.map((s) => '- ' + s.n + ': ' + firstSentence(s.d));
  const fence = String.fromCharCode(96, 96, 96);
  return '\n\n=== SKILLS (навыки) ===\n'
    + 'Терминал умеет подгружать навыки. Загрузи нужный так:\n'
    + fence + 'rr-skill\n{"name":"<навык>"}\n' + fence + '\n'
    + 'Если описание навыка подходит к задаче — сначала загрузи навык и следуй ему, а не импровизируй. Доступные навыки:\n'
    + lines.join('\n');
}
function executeSkillTool(args) {
  const name = (args && (args.name || args.skill || args.id)) || '';
  const s = skillByName(name);
  if (!s) {
    return { ok: false, output: 'Навык не найден: ' + String(name) + '. Список навыков — в системном промпте, раздел SKILLS.' };
  }
  let out = '# Навык: ' + s.n + '\nисточник: ' + (s.s || 'builtin') + '\n\nКОГДА ПРИМЕНЯТЬ:\n' + s.d;
  out += s.g
    ? '\n\nКАК ПРИМЕНЯТЬ В ТЕРМИНАЛЕ:\n' + s.g
    : '\n\nКАК ПРИМЕНЯТЬ: следуй описанию навыка, используя инструменты терминала (rr-web, rr-file, rr-ssh).';
  return { ok: true, output: out };
}

const TOOL_PROTOCOL = `
=== RISKRADAR TERMINAL TOOLS ===
You are running inside RiskRadar Terminal on the user's PC and can perform REAL actions.

=== RESPONSE STYLE (mandatory) ===
- Отвечай КРАТКО и аккуратно: 3–12 строк на типичный ответ. Короткие абзацы, одна мысль — одна строка.
- Ключевые факты — списками и **жирным**; при 3+ сопоставимых пунктах — таблицей. Без воды, без повторения вопроса.
- Структура: 1 строка — ответ/вердикт → ключевые детали списком → (только если полезно) следующий шаг.
- Никогда не пиши простыни текста: длинные детали сжимай в буллеты.

=== AUTONOMY RULES (mandatory) ===
- You are an autonomous agent: after describing what you will do, KEEP GOING and actually do it —
  emit the tool block in the SAME message and continue in the next round. A message that only
  announces a plan ("сделаю… затем…", "выберу вариант", "предлагаю варианты") WITHOUT executing the
  first step is INCOMPLETE: if you stop, the user must not have to type "продолжи".
- NEVER stop to offer the user numbered variants/options when you can decide and act yourself.
  Pick the best option, state it in one line, and execute. Ask a question ONLY when a decision
  is impossible without user-specific data (credentials, which file, their personal choice).
- If a tool fails: read the error, fix the approach, retry with a different method — up to 3
  attempts. Only when all attempts genuinely failed, report the error with the exact reason.
- Stop ONLY when: (a) the task is fully done and the result is verified; (b) an unrecoverable
  error is reported; (c) a genuine clarifying question is asked.

1) SSH — execute a command on a remote server. Emit exactly one fenced block:
\`\`\`rr-ssh
{"host":"1.2.3.4","port":22,"user":"root","password":"...","cmd":"uptime"}
\`\`\`
You may use "profile":"<saved connection name>" instead of credentials.
If connection details are missing — ask the user. One command per block.

1b) LOCAL SHELL — run a command ON THIS PC (like Codex / Claude Code). Use it for anything that must run on the user's machine: build, test, lint, git, npm/yarn/pnpm, pip/uv, cargo, go, ls/cat/grep/find, running scripts, installing dependencies, starting a dev server, compiling, migrations, etc.
\`\`\`rr-shell
{"cmd":"npm install && npm run build","cwd":".","timeoutMs":180000}
\`\`\`
"cwd" is relative to the project root (omit it to run in the project root). The terminal asks the user to approve the command (they may also allow it permanently). stdout + stderr + exit code come back to you as a "[TOOL RESULT]" message — read it and continue. On macOS the command runs in the user's LOGIN shell, so Homebrew / nvm / pyenv / rustup tools are on PATH exactly like in Terminal.app. PREFER rr-shell for any local build/test/run/git task; use rr-ssh ONLY for a REMOTE server the user gave you. One command per block; chain with && or ; when needed. Never claim you cannot run local commands — emit an rr-shell block instead.

2) Local files — see FS_ACCESS_RULES below. The system prompt already contains PROJECT CONTEXT
(auto): project root, a PROJECT TREE file list, session files and recalled snippets — use them
instead of guessing paths. The user can attach files with @path mentions (they arrive as
MENTIONED_FILE blocks). mkdir/delete are supported. All relative paths resolve from the project root.
\`\`\`rr-file
{"op":"list","path":"."}
{"op":"read","path":"notes.txt"}
{"op":"write","path":"notes.txt","content":"..."}
{"op":"append","path":"log.txt","content":"..."}
{"op":"mkdir","path":"newdir"}
{"op":"delete","path":"old.txt"}
{"op":"search","path":".","query":"renderMessage"}
{"op":"open","path":"src/app.js","query":"renderMessage"}
{"op":"patch","path":"app.js","old":"ТОЧНЫЙ текущий текст (дословно, с отступами)","new":"новый текст"}
{"op":"read","path":"server.log","start":100,"end":250}
{"op":"stats","path":"src"}
\`\`\`
For large writes you may use this easier format instead of escaped JSON:
\`\`\`rr-file
{"op":"write","path":"notes.txt"}
<<<CONTENT
full file content here
CONTENT>>>
\`\`\`
search = search in local code/files, open = show the exact snippet around a function/class/query.
V-FSPATH PATH RULES (важно):
- A name you saw inside a "list" result is NOT a path by itself. Always pass the FULL path of that entry (the parent folder + the name), never just the name relative to the working root.
- After every "list", the reply states the real directory it listed. Build next paths from THAT directory.
- If a path does not exist, the terminal tells you it is missing (not a permission error) and lists the top-level folders — pick the right parent and retry with the full path.
FS_ACCESS_RULES

3) Remote text files over SSH — read/search/write REAL files on the connected server:
\`\`\`rr-rfile
{"op":"read","path":"/etc/nginx/nginx.conf"}
{"op":"write","path":"/etc/nginx/nginx.conf","content":"..."}
{"op":"search","path":"/var/www/app","query":"server_name"}
{"op":"open","path":"/etc/nginx/nginx.conf","query":"server_name"}
\`\`\`
Large write form is also allowed:
\`\`\`rr-rfile
{"op":"write","path":"/etc/nginx/nginx.conf"}
<<<CONTENT
full remote file content here
CONTENT>>>
\`\`\`
If an SSH session is already open, host/profile can be omitted and the active connection is used.
Otherwise you may add the same credentials/profile fields as rr-ssh.

4) Balance — get the REAL balance for the current API key:
\`\`\`rr-balance
{}
\`\`\`
Use this when the user asks about balance / tokens.

5) Internet / web — search the web, read a page, or get live weather:
\`\`\`rr-web
{"op":"search","query":"погода Челябинск"}
{"op":"fetch","url":"https://example.com/page"}
{"op":"view","url":"https://example.com/page"}
{"op":"weather","place":"Челябинск"}
\`\`\`
Use rr-web whenever the user asks for current/real-world information from the internet: news, weather, prices, facts, "погода", "найди в интернете", "посмотри на сайте".
search = web search (Wikipedia + optional configured proxy), fetch = download a page/JSON and return its text, view = OPEN the page for the user in the terminal's built-in browser, weather = live weather for a place.
Use "view" when the user says the terminal should OPEN / SHOW / LOOK AT a site ("зайди на сайт", "открой ссылку", "посмотри страницу"). Use "fetch" when you need the text content to read.
CRITICAL: always use the EXACT url the user gave, including its path and trailing slash. Never replace https://site/SECTION/ with https://site/ — the root page is a DIFFERENT page. If a page returns little text, say so and offer the browser view instead of silently switching to the site root.три на сайте", "загугли". Do NOT claim you have no internet access — call rr-web instead.
search = web search (Wikipedia + optional configured proxy), fetch = download a page/JSON and return its text, weather = live weather for a place.
Search uses the REAL search engines (DuckDuckGo / Bing / Google) and runs from the user's own IP through the desktop app, so results are live.
If an rr-web call fails with "channel blocked" or "Failed to fetch", the desktop shell is outdated — use the rr_web_search / rr_web_fetch function tools instead (same purpose, they run on the server side). Never tell the user the internet is unavailable until you have tried the function tools.

5.5) Видео — генерация видео по описанию (долго: 1–10 минут; деньги списываются только за ГОТОВОЕ видео):
\`\`\`rr-video
{"prompt":"A cinematic drone shot flying over a snowy mountain ridge at sunrise, golden light, smooth forward motion","model":"sora-2","seconds":4,"size":"1280x720"}
\`\`\`
models: "sora-2" (default), "sora-2-pro" (качественнее, seconds 8–12), "veo-3.1-generate-preview", "grok-imagine-video" (быстрая дешёвая проверка). size: "1280x720" горизонталь или "720x1280" вертикаль. Для veo можно "aspect_ratio":"16:9".
Write "prompt" in ENGLISH: subject + motion/camera + lighting + style, 1–3 sentences. If the user attached a picture to animate, put its URL into "input_reference".
Use rr-video ONLY when the user explicitly asks for a video / animation ("сделай видео", "оживи картинку"). Say first that generation takes a few minutes, emit ONE rr-video block and stop; the terminal polls with live progress, charges the account only on success and renders the player card itself. After [TOOL RESULT] VIDEO_READY simply confirm and offer to save. If the result reports "no video channels" — relay it honestly; do not retry more than once in the same turn.

5.1) Skills / навыки — загрузить навык из каталога терминала:
\`\`\`rr-skill
{"name":"browser-use"}
\`\`\`
Загружай навык ПЕРЕД работой, если его описание подходит к задаче: отладка, проверка результата, планирование, разбор кода, работа с интернетом. Навык задаёт порядок действий — следуй ему, а не импровизируй. Состав навыков описан в разделе SKILLS ниже.

6) Documents — create a real .docx / .xlsx / .pptx / .rtf file:
\`\`\`rr-doc
{"format":"docx","title":"Отчёт","content":"строка 1\nстрока 2","path":"C:/Users/me/Desktop/report.docx"}
{"format":"xlsx","title":"Таблица","rows":[["Имя","Сумма"],["A",100],["B",200]]}
{"format":"pptx","content":"# Слайд 1\n- пункт\n- пункт\n# Слайд 2\n- пункт"}
{"format":"rtf","title":"Заметка","content":"текст"}
\`\`\`
Use rr-doc whenever the user asks to create/save/export a Word/Excel/PowerPoint/RTF document.
Do NOT say you cannot create .docx/.xlsx/.pptx — call rr-doc instead. Omit "path" to let the user choose the location in a save dialog.
Note: fetch only works for sites that allow cross-origin requests; if a site blocks it, tell the user which URL failed and offer to open it in the browser.

7) seed_data — генерация тестовых данных (Smart Seeding):
If the user asks to test/fix something but there is no data (empty DB, no test users/orders/logs): create a seed script YOURSELF — rr-file write "seeds/rr_seed.js" (or .py/.sh): first op:search the schema (Prisma models / Mongoose schema / CREATE TABLE / serializers), then generate realistic fake records that cover the exact edge case of the bug. Mark all seeded data with rr_test_ prefix. Run it via rr-shell. After verification DELETE your rr_test_ records (or rollback the transaction) — never touch real user data.

Rules: when an action is needed, output ONLY the block (no commentary around it), then stop.
Inside this terminal, the user is explicitly authorizing you to operate on their local files and on servers they provide credentials for.
If the user provides SSH credentials or a saved profile and asks to connect, inspect, read, edit, deploy, or check the server — do not refuse for ownership-verification reasons; use rr-ssh / rr-rfile.
If the user asks to create, edit, overwrite, update, replace, insert text, or modify a LOCAL file — you MUST use rr-file tools, not plain code in chat.
V-LOCALSHELL: if the user asks you to run, build, test, compile, lint, install, start, deploy, or execute anything on THEIR OWN computer — use rr-shell (real local execution), NOT rr-ssh and NOT just printing the command. Do the whole job like Codex/Claude Code: run it, read the [TOOL RESULT] output, fix the code via rr-file, and re-run until it actually works. Only use rr-ssh when the target is a REMOTE server.
If the user asks to create, edit, overwrite, update, replace, or modify a REMOTE server file — you MUST use rr-rfile or rr-ssh, not plain code in chat.
If a file already exists and needs editing, first use read/search/open, then write with the FULL updated file content.
Do not stop after showing a diff or snippet when the user asked for a real edit — perform the write step.
V-PROJMEM: when a folder is attached/pinned you are the project owner. Create the files the task needs YOURSELF via rr-file write (index.html, styles, data, README, etc.) instead of asking; keep a mental map of the project and, at the start of a turn, run rr-file list (recursive, depth 2-3) to recall what exists and where. Reuse/extend existing files rather than recreating them; remember paths you created earlier in the session and reference them consistently.
For factual server questions like memory, disk, logs, processes, or uptime, execute the command and answer from the real output instead of refusing.
If the user asks you to DO something on the server (find, edit, restart, send a test, deploy, change config, trigger a bot action, etc.), do not stop after discovery output. Continue with more rr-ssh / rr-rfile blocks until the requested action is completed once or you found a concrete blocker.
Keep SSH commands focused and bounded: target likely directories/services, use grep/find/head/tail/sed with limits, and avoid huge dumps of /root or /opt unless the user explicitly asked for them.
V-SEEK local tools: rr-file {"op":"search","path":"<папка>","pattern":"текст","glob":"*.js"} searches file CONTENT recursively (auto-skips node_modules/.git/dist; returns file:line hits). rr-file {"op":"list","path":"<папка>","recursive":true,"depth":3} prints a tree. Use them BEFORE saying "I don't see / can't find".
V-SMARTSEARCH (semantic-style search): there is NO vector DB/AST search — compensate with synonym expansion: if op:search returns nothing, rerun with 3-5 synonym identifiers (e.g. registerAccount / createUser / signup / register / auth) and also search comments/docstrings; use the PROJECT TREE to pick the right module folder. 2-3 sharper synonym queries beat one "semantic" guess.
V-CACHE: the gateway caches the request PREFIX (tools + system prompt are sent first and are frozen). Keep the prefix stable: do not re-read files that are already in context, do not dump the same large output twice, keep tool outputs narrow (head -40, one file at a time, start/end pagination).
V-DEBATE: when the ⚖ debate mode is ON, a second model (critic) reviews every code write/patch BEFORE it hits disk. If you receive "⚖ CRITIC REJECTED", treat it as a test failure: read the bullets, fix the code, re-send the corrected block. Same mistake twice = the critic will block again.
V-PATCH RULE (Claude Code parity): when editing an EXISTING file, PREFER op:patch (точечная замена) over op:write (full rewrite) — it is faster and cheaper. Procedure: op:open/op:read to see the exact current text → copy it VERBATIM (whitespace included) into "old" → op:patch. If "old" is not found, re-read the file — never guess. After every patch VERIFY with op:open on the changed spot. For large files use op:read with "start"/"end" (numbered lines) instead of reading the whole file. Git parity: in a git repo run \`git status --short\` via rr-shell before code work and \`git diff --stat\` after — include the real output in your report. TDD: if TDD-mode is enabled, write the failing test FIRST (op:write/patch), run it via rr-shell and SHOW the failure, then implement, then show green.
Truncated output rule: if an output shows …[пропущено…] or is cut, DO NOT conclude "nothing found" — rerun narrowed (grep -l, head -60, -m 5, --exclude-dir, one subfolder at a time) until you get a definitive result. Never give up after one truncated dump; try 2-3 sharper queries first.
JS-rendered pages: if rr-web fetch returns the "Текстового контента почти нет" notice, fetch the listed .js asset URLs (they contain the real text), or read the site files via rr-ssh when it's the user's own server.
When the user attaches a text/code file, its content is already included in the prompt below — do not say you only see the filename if file content is present.
Do not output chain-of-thought, "🧠" reasoning sections, UI words like "Копировать/Заново", or extra markdown around a tool call.
After the requested server/file action is completed, answer briefly and STOP. Do not propose or auto-run extra diagnostic commands unless the user explicitly asked for more.
The terminal executes it and sends you a "[TOOL RESULT]" message — continue the task using it.
Never invent passwords or hosts: ask the user. Multiple sequential blocks across turns are fine.`;

function parsePseudoToolBlocks(text) {
  const src = normalizeNewlines(String(text || ''));
  const cleaned = src
    .replace(/^\s*🧠.*$/gmi, '')
    .replace(/^\s*📋\s*Копировать\s*$/gmi, '')
    .replace(/^\s*↻\s*Заново\s*$/gmi, '')
    .replace(/^\s*🗑\s*$/gmi, '')
    .replace(/^\s*💾\s*$/gmi, '')
    .trim();
  const out = [];
  const seen = new Set();
  const push = (type, args) => {
    const key = type + '|' + JSON.stringify(args || {});
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ type, args });
  };
  const parseCommandLine = (line) => {
    const s = String(line || '').trim();
    if (!s) return false;
    if (/^💰\s*balance$/i.test(s)) { push('rr-balance', {}); return true; }
    const ssh = s.match(/^🖥\s*SSH\s*[→:-]\s*([\s\S]+?)(?:\s+@([A-Za-z0-9_.:-]+))?$/i);
    if (ssh) {
      const cmd = String(ssh[1] || '').trim();
      const host = String(ssh[2] || '').trim();
      push('rr-ssh', host ? { host, cmd } : { cmd });
      return true;
    }
    const remote = s.match(/^🗂\s*remote\s+(read|write|search|open)\s+([^\n]+)$/i);
    if (remote) { push('rr-rfile', { op: remote[1].toLowerCase(), path: String(remote[2] || '').trim() }); return true; }
    const local = s.match(/^📁\s*(list|read|write|append|mkdir|delete|search|open)\s+([^\n]+)$/i);
    if (local) { push('rr-file', { op: local[1].toLowerCase(), path: String(local[2] || '').trim() }); return true; }
    return false;
  };
  const fenceRe = /```(?:bash|sh|shell|text)?\n([\s\S]*?)```/gi;
  const fences = [];
  let fm;
  while ((fm = fenceRe.exec(cleaned))) fences.push(fm[1].trim());
  if (fences.length) {
    const outside = cleaned.replace(fenceRe, '').trim();
    if (outside) return [];
    parseCommandLine(fences[0].split('\n').find((x) => x.trim()) || '');
    return out.slice(0, 1);
  }
  const lines = cleaned.split('\n').map((x) => x.trim()).filter(Boolean);
  if (lines.length !== 1) return [];
  parseCommandLine(lines[0]);
  return out.slice(0, 1);
}
function parseToolBlockBody(kind, body) {
  const src = String(body || '').trim();
  if (!src) return null;
  if (kind === 'balance') return { type: 'rr-balance', args: {} };
  try { return { type: 'rr-' + kind, args: JSON.parse(src) }; } catch (e) {}
  const lines = src.split('\n');
  try {
    const head = JSON.parse(lines[0].trim());
    if (head && typeof head === 'object' && (head.op || head.cmd || head.path || head.host || head.user)) {
      let rest = lines.slice(1).join('\n');
      rest = rest.replace(/^<<<CONTENT\n?/i, '').replace(/\n?CONTENT>>>$/i, '');
      if ((kind === 'file' || kind === 'rfile') && /^(write|append)$/i.test(String(head.op || '')) && rest.trim()) head.content = rest;
      return { type: 'rr-' + kind, args: head };
    }
  } catch (e) {}
  return null;
}
function parseGenericJsonToolBlocks(text) {
  const out = [];
  const pushObj = (obj, rest) => {
    if (!obj || typeof obj !== 'object') return;
    const tail = String(rest || '').replace(/^<<<CONTENT\n?/i, '').replace(/\n?CONTENT>>>$/i, '');
    if ((obj.op || '').match(/^(write|append)$/i) && tail.trim() && !obj.content) obj.content = tail;
    if (obj.cmd && (obj.host || obj.profile || obj.user || obj.username)) out.push({ type: 'rr-ssh', args: obj });
    else if (obj.cmd && !obj.op) out.push({ type: 'rr-shell', args: obj });
    else if ((obj.op || '').match(/^(read|write|search|open)$/i) && obj.path && (obj.host || obj.profile || obj.user || obj.username || obj.remote)) out.push({ type: 'rr-rfile', args: obj });
    else if ((obj.op || '').match(/^(read|write|append|mkdir|delete|search|open|list|patch|stats)$/i) && obj.path) out.push({ type: 'rr-file', args: obj });
  };
  const fenceRe = /```(?:[\w.-]+)?\n([\s\S]*?)```/g;
  let m;
  while ((m = fenceRe.exec(text || ''))) {
    const body = String(m[1] || '').trim();
    if (!body) continue;
    try { pushObj(JSON.parse(body), ''); continue; } catch (e) {}
    const lines = body.split('\n');
    try { pushObj(JSON.parse(lines[0].trim()), lines.slice(1).join('\n')); } catch (e) {}
  }
  return out;
}
function extractToolBlocks(text) {
  const out = [];
  const re = /```rr-(blender|photoshop|shell|ssh|file|rfile|balance|web|doc|skill|video)[ \t]*\n([\s\S]*?)```/g;
  let m;
  while ((m = re.exec(text || ''))) {
    const parsed = parseToolBlockBody(m[1], m[2]);
    if (parsed) out.push(parsed);
  }
  if (out.length) return out;
  const generic = parseGenericJsonToolBlocks(text);
  if (generic.length) return generic;
  const pseudo = parsePseudoToolBlocks(text);
  if (pseudo.length) return pseudo;
  // V-BAREFENCE (1.2.92): ```rr-ssh без закрывающего ``` или оборванный JSON — раньше модель
  // «затыкала» себя незакрытым фенсом и чат вставал («замолчал и ничего не делает»).
  // Теперь: починить хвост (кавычки/скобки) и исполнить команду как есть.
  return parseBareRrFences(text);
}
function rrRepairJson(src) {
  let s = String(src || '').trim();
  if (!s || s[0] !== '{') { const i = s.indexOf('{'); if (i < 0) return null; s = s.slice(i); }
  s = s.replace(/[,.]+\s*$/, '');
  const st = [];
  let inStr = false, esc = false;
  for (const ch of s) {
    if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
    if (ch === '"') inStr = true;
    else if (ch === '{' || ch === '[') st.push(ch);
    else if (ch === '}' || ch === ']') st.pop();
  }
  if (inStr) s += '"';
  for (let i = st.length - 1; i >= 0; i--) s += st[i] === '{' ? '}' : ']';
  try { return JSON.parse(s); } catch (e) { return null; }
}
function parseBareRrFences(text) {
  const out = [];
  try {
    const src = normalizeNewlines(String(text || ''));
    const re = /```rr-([a-z]+)[ \t]*\n([\s\S]*?)(?:```|$)/g;
    let m;
    const seenB = new Set();
    const pushB = (type, args) => {
      let key = type;
      try { key += '|' + JSON.stringify(args); } catch (eK) { return; }
      if (seenB.has(key)) return;
      seenB.add(key);
      out.push({ type, args });
    };
    while ((m = re.exec(src))) {
      const kind = m[1];
      let args = null;
      try { args = JSON.parse(m[2].trim()); } catch (e) { args = rrRepairJson(m[2]); }
      if (args && typeof args === 'object') pushB('rr-' + kind, args);
    }
    // V-BAREFENCE2 (1.2.93): имя тула вообще без ```: «…бота.rr-ssh {json}» — минимакс так
    // делает на длинных задачах; чат «молчал, пока снова не нажмешь». Вытаскиваем и чиним JSON.
    const reBare = /\brr-(video|ssh|shell|file|rfile|web|doc|skill|balance|blender|photoshop)\b[ \t]*\n?[ \t]*\{/g;
    let mb;
    while ((mb = reBare.exec(src))) {
      const rest = src.slice(mb.index + mb[0].length - 1);
      const fenceEnd = rest.indexOf('```');
      const body = fenceEnd > 0 ? rest.slice(0, fenceEnd) : rest;
      let args = null;
      try { args = JSON.parse(body.trim()); } catch (e) { args = rrRepairJson(body); }
      if (args && typeof args === 'object') pushB('rr-' + mb[1], args);
    }
  } catch (eB) {}
  return out;
}
function stripAssistantDisplayText(text) {
  const src = normalizeNewlines(String(text || ''));
  let out = src.replace(/```rr-(blender|photoshop|shell|ssh|file|rfile|balance|web|doc|skill|video)[ \t]*\n[\s\S]*?```/g, '');
  out = out.replace(/```(?:[\w.-]+)?\n([\s\S]*?)```/g, (full) => parseGenericJsonToolBlocks(full).length ? '' : full).trim();
  if (!out && extractToolBlocks(src).length) return '';
  return out;
}
function parseToolPreviewArgs(rawText, cls) {
  try {
    const kind = /rr-photoshop/.test(cls || '') ? 'photoshop' : /rr-blender/.test(cls || '') ? 'blender' : /rr-video/.test(cls || '') ? 'video' : /rr-rfile/.test(cls || '') ? 'rfile' : /rr-file/.test(cls || '') ? 'file' : /rr-ssh/.test(cls || '') ? 'ssh' : /rr-balance/.test(cls || '') ? 'balance' : /rr-web/.test(cls || '') ? 'web' : /rr-doc/.test(cls || '') ? 'doc' : /rr-skill/.test(cls || '') ? 'skill' : '';
    if (kind) {
      const parsed = parseToolBlockBody(kind, rawText);
      if (parsed && parsed.args) return parsed.args;
    }
  } catch (e) {}
  try { return JSON.parse(String(rawText || '').trim()); } catch (e) {}
  try { return JSON.parse(String(rawText || '').trim().split('\n')[0].trim()); } catch (e) {}
  return {};
}
async function withTimeout(promise, ms, label) {
  let timer = null;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label || 'Timeout')), ms || 25000); })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
function splitLocalExecTarget(inputPath, fallbackWd) {
  const raw = String(inputPath || '').trim();
  const fallback = String(fallbackWd || '').trim();
  if (!raw) return { path: raw, workDir: fallback };
  if (/^[A-Za-z]:[\\/]/.test(raw)) {
    const norm = raw.replace(/\//g, '\\');
    const idx = norm.lastIndexOf('\\');
    return idx > 1 ? { path: norm.slice(idx + 1), workDir: norm.slice(0, idx) } : { path: norm, workDir: fallback };
  }
  if (raw.startsWith('/')) {
    const idx = raw.lastIndexOf('/');
    return idx > 0 ? { path: raw.slice(idx + 1), workDir: raw.slice(0, idx) || '/' } : { path: raw, workDir: fallback };
  }
  return { path: raw, workDir: fallback };
}
function normalizeLocalFsPath(input) {
  let s = String(input || '').trim().replace(/\\/g, '/');
  if (!s) return '';
  let drive = '';
  if (/^[A-Za-z]:/.test(s)) {
    drive = s.slice(0, 2).toUpperCase();
    s = s.slice(2);
  }
  const abs = s.startsWith('/');
  const parts = [];
  for (const part of s.split('/')) {
    if (!part || part === '.') continue;
    if (part === '..') {
      if (parts.length && parts[parts.length - 1] !== '..') parts.pop();
      else if (!abs) parts.push(part);
      continue;
    }
    parts.push(part);
  }
  let out = (drive ? drive : '') + (abs || drive ? '/' : '') + parts.join('/');
  if (!out) out = drive ? (drive + '/') : (abs ? '/' : '');
  return out;
}
function localPathStartsWith(base, target) {
  const a = normalizeLocalFsPath(base);
  const b = normalizeLocalFsPath(target);
  if (!a || !b) return false;
  const aw = /^[A-Z]:\//.test(a), bw = /^[A-Z]:\//.test(b);
  if (aw || bw) {
    if (!aw || !bw) return false;
    const al = a.toLowerCase(), bl = b.toLowerCase();
    return bl === al || bl.startsWith(al.replace(/\/$/, '') + '/');
  }
  return b === a || b.startsWith(a.replace(/\/$/, '') + '/');
}
function localRelativeFromBase(base, target) {
  const a = normalizeLocalFsPath(base).replace(/\/$/, '');
  const b = normalizeLocalFsPath(target);
  if (!a || !b) return '';
  const rel = (/^[A-Z]:\//.test(a) ? b.slice(a.length) : b.slice(a.length)).replace(/^\//, '');
  return rel || '.';
}
function isWorkDirPinned() {
  return !!S().workDirPinned;
}
// V-FSACCESS: текст про доступ к файлам зависит от режима. По умолчанию терминал видит весь ПК;
// если пользователь закрепил рабочий каталог (📁 «Закрепить»), запись ограничена этой папкой.
function fsAccessRules() {
  const wd = String(S().workDir || '').trim();
  if (isWorkDirPinned() && wd) {
    return `Local file access is PINNED to the working directory: ${wd}. Read/write/create/delete only inside this folder (relative paths resolve here). You may still read/write a file the user attached via the paperclip by its attached path even outside the folder. If the user asks to work outside this folder, tell them to unpin it in the 📁 chip first.`;
  }
  return `You have access to the ENTIRE PC filesystem. Use absolute paths (e.g. C:/Users/... or /home/...) or paths relative to the working directory (${wd || 'your home'}). When the user asks to edit files in a specific project folder, prefer that folder; when they ask for full-PC access, use absolute paths freely. Always confirm destructive actions (delete/overwrite) with the user first. Never touch OS-critical or key files unless explicitly instructed.`;
}
/* V-FSPATH: список папок верхнего уровня рабочей директории — чтобы по имени из
   вывода `list` модель не собирала путь от корня, а видела реального родителя. */
let topLevelCache = { dir: '', at: 0, names: [] };
async function listTopLevel(dir) {
  const key = String(dir || '');
  if (!key) return [];
  if (topLevelCache.dir === key && Date.now() - topLevelCache.at < 30000) return topLevelCache.names;
  try {
    const r = await withTimeout(rr.invoke('fs:list', { dir: key }), 15000, 'list timeout');
    const names = ((r && r.entries) || []).filter((e) => e && e.dir).map((e) => e.name);
    topLevelCache = { dir: key, at: Date.now(), names };
    return names;
  } catch (e) { return []; }
}
/* V-FSPATH: если имя нашлось ровно в одной подпапке — чиним путь вместо «нет доступа».
   Возвращает исправленный абсолютный путь или ''. */
async function findNestedPath(abs, wd) {
  const base = normalizeLocalFsPath(wd || '');
  if (!base || !abs || localPathStartsWith(base, abs)) return '';
  const rel = abs.slice(Math.min(abs.length, base.length + 1));
  if (!rel || rel.indexOf('/') >= 0) return '';
  const tops = await listTopLevel(base);
  const hit = tops.find((name) => name.toLowerCase() === rel.toLowerCase());
  return hit ? (base.replace(/\/$/, '') + '/' + hit) : '';
}
function resolveScopedLocalTarget(inputPath, fallbackWd, opts) {
  const options = opts || {};
  const wd = String(fallbackWd || homeDirCache || '').trim();
  const raw = String(inputPath || '').trim();
  if (!raw) return { ok: true, path: raw, workDir: wd, absolute: wd };
  const abs = /^[A-Za-z]:[\\/]|^\//.test(raw)
    ? normalizeLocalFsPath(raw)
    : normalizeLocalFsPath(((wd || '').replace(/[\\/]+$/, '')) + (wd ? '/' : '') + raw);
  // V-ABSPATH: относительный путь никогда не уходит в main (там он резолвится от cwd процесса)
  if (raw && !/^[A-Za-z]:[\\/]|^\//.test(abs)) {
    return { ok: false, error: 'Не удалось построить абсолютный путь для «' + raw + '»: задайте рабочую папку (📁) или укажите полный путь' };
  }
  if (options.allowOutsideWorkDir) {
    const free = splitLocalExecTarget(abs || raw, wd);
    return { ok: true, path: free.path, workDir: free.workDir || wd, absolute: abs || normalizeLocalFsPath(raw), fromAttachment: true };
  }
  if (!isWorkDirPinned() || !wd) {
    const free = splitLocalExecTarget(raw, wd);
    return { ok: true, path: free.path, workDir: free.workDir || wd, absolute: abs };
  }
  const base = normalizeLocalFsPath(wd);
  if (!localPathStartsWith(base, abs)) {
    return { ok: false, error: 'Разрешены только файлы внутри выбранной папки проекта: ' + wd };
  }
  return { ok: true, path: localRelativeFromBase(base, abs), workDir: wd, absolute: abs };
}
function isBlockedChannelError(err) {
  const msg = String(err && (err.message || err.error || err.output) || err || '').toLowerCase();
  return /channel blocked|not implemented|unsupported/.test(msg);
}
/* Локальные файловые операции — через разрешённые IPC-каналы main-процесса.
   Канал files:exec приложением не разрешён и в main не реализован, поэтому используем
   fs:readText / fs:writeText / fs:list. Запись идёт напрямую, без окна «куда сохранить». */
/* V-VERIFY: после записи проверяем файл через fs:list (имя+размер) — молчаливые
   "успехи" с записью не туда / усечением превращаются в явную ошибку. */
async function verifyLocalWrite(abs, content) {
  const target = String(abs || '').trim();
  let expected = 0;
  try { expected = new TextEncoder().encode(String(content == null ? '' : content)).length; } catch (e) { expected = -1; }
  const m = target.replace(/[\\/]+$/, '').match(/^(.*)[\\/][^\\/]+$/);
  if (!m) return { ok: false, error: 'странный путь ' + target };
  let dir = m[1] || '';
  if (/^[A-Za-z]:$/.test(dir)) dir += '/';
  if (!dir) dir = '/';
  const base = target.slice(target.replace(/[\\/]+$/, '').lastIndexOf(dir) + dir.length).replace(/^[\\/]+/, '');
  const name = base || target.split(/[\\/]/).pop();
  const r = await withTimeout(rr.invoke('fs:list', { dir }), 15000, 'verify timeout');
  if (!r || !r.ok) return { ok: false, error: 'папка недоступна: ' + dir };
  const hit = (r.entries || []).find((e) => !e.dir && String(e.name || '').toLowerCase() === String(name || '').toLowerCase());
  if (!hit) return { ok: false, error: 'файл не найден после записи: ' + target };
  const size = Number(hit.size || 0);
  if (expected >= 0 && size !== expected) return { ok: false, error: 'размер ' + size + ' вместо ' + expected + ': ' + target };
  return { ok: true, path: target, size };
}
async function localWriteDirect(op, target, content) {
  const abs = String((target && (target.absolute || target.path)) || '').trim();
  if (!abs) return { ok: false, error: 'Нужен путь к файлу для записи' };
  if (!/^[A-Za-z]:[\\/]|^\//.test(abs)) return { ok: false, error: 'Относительный путь «' + abs + '» — задайте рабочую папку (📁) или укажите полный путь' };
  const normOp = String(op || '').trim().toLowerCase();
  let finalContent = String(content == null ? '' : content);
  if (normOp === 'append') {
    try {
      const ex = await withTimeout(rr.invoke('fs:readText', { filePath: abs }), 15000, 'read timeout');
      if (ex && ex.ok) finalContent = String(ex.content || '') + finalContent;
    } catch (e) {}
  }
  let r = await withTimeout(rr.invoke('fs:writeText', { filePath: abs, content: finalContent }), 20000, 'write timeout');
  let _mkErr = '';
  if (r && r.error && /ENOENT/i.test(String(r.error))) {
    const m2 = abs.replace(/[\\/]+$/, '').match(/^(.*)[\\/][^\\/]+$/);
    if (m2 && m2[1]) {
      try { await rr.invoke('fs:mkdir', { dir: m2[1] }); } catch (e) { _mkErr = String((e && e.message) || e || ''); }
      r = await withTimeout(rr.invoke('fs:writeText', { filePath: abs, content: finalContent }), 20000, 'write timeout');
    }
  }
  if (r && r.ok) {
    const v = await verifyLocalWrite(r.path || abs, finalContent).catch((e) => ({ ok: false, error: String((e && e.message) || e) }));
    if (!v.ok) return { ok: false, error: t('writeVerifyFail') + ' ' + v.error };
    return { ok: true, path: v.path, bytes: v.size, via: 'fs:writeText' };
  }
  const err = String((r && r.error) || '');
  if (/ENOENT/i.test(err)) {
    if (isBlockedChannelError(_mkErr)) return { ok: false, error: 'Папки нет, а создать её не даёт оболочка приложения (канал fs:mkdir заблокирован). Обновите RiskRadar Terminal до сборки с fs:mkdir либо сохраните файл в существующую папку.' };
    return { ok: false, error: 'Папка не существует: ' + abs };
  }
  return { ok: false, error: err || 'Не удалось записать файл' };
}
/* V-FSERR: старая сборка main.js называла «Нет доступа» даже когда папки просто нет.
 * Переписываем такое сообщение на понятное: ENOENT — это «не найдено», а не «нет прав».
 * Работает и без обновления exe, поэтому доезжает до клиента через hot-UI. */
function humanizeFsError(err, target) {
  const s = String(err || '');
  const where = String(target || '').trim();
  if (/ENOENT|no such file or directory/i.test(s)) {
    return 'Такой папки нет: ' + where + '\nПроверь точное имя: сначала list по родительской папке — не угадывай названия.';
  }
  if (/EACCES|EPERM|permission denied/i.test(s)) {
    return 'Нет прав на доступ: ' + where + '\nНужны права на этот каталог либо выбери другую папку.';
  }
  if (/ENOTDIR/i.test(s)) return 'Это не папка: ' + where;
  return s;
}
async function localExecWithFallback(op, target, content, opts) {
  const normOp = String(op || '').trim().toLowerCase();
  const abs = String((target && (target.absolute || target.path)) || '').trim();
  if (!abs) return { ok: false, error: 'Нужен путь к файлу' };
  try {
    if (normOp === 'read') {
      const r = await withTimeout(rr.invoke('fs:readText', { filePath: abs }), 15000, 'read timeout');
      if (r && r.ok) return { ok: true, path: r.path || abs, content: r.content };
      return { ok: false, error: humanizeFsError((r && r.error) || 'Не удалось прочитать файл', abs) };
    }
    if (normOp === 'list') {
      if (opts && (opts.recursive === true || Number(opts.depth) > 1)) {
        // V-SEEK: рекурсивное дерево каталога (глубина<=6, кап 700 строк)
        const depthWanted = Math.max(1, Math.min(6, Number(opts.depth) || 4));
        const SKIPD = new Set(['node_modules', '.git', 'dist', 'build', 'out', 'target', '__pycache__', '.venv', 'venv', '.next', '.cache', '.idea', '.vscode', 'app.zip.d']);
        const flat = []; const queue = [{ dir: abs, rel: '', d: 0 }];
        while (queue.length && flat.length < 700) {
          const cur = queue.shift();
          let lr = null;
          try { lr = await withTimeout(rr.invoke('fs:list', { dir: cur.dir }), 9000, 'list timeout'); } catch (e) { continue; }
          if (!lr || !lr.ok) continue;
          for (const e of (lr.entries || [])) {
            const nm = String(e.name || '').replace(/\\/g, '/').replace(/^[\/]+/, '');
            if (!nm) continue;
            const full = cur.dir.replace(/[\\/]+$/, '') + '/' + nm;
            const rel = (cur.rel ? cur.rel + '/' : '') + nm;
            if (e.dir) {
              flat.push({ name: rel, dir: true });
              if (cur.d + 1 < depthWanted && !SKIPD.has(nm.toLowerCase())) queue.push({ dir: full, rel, d: cur.d + 1 });
            } else flat.push({ name: rel, dir: false });
            if (flat.length >= 700) break;
          }
        }
        return { ok: true, path: abs, entries: flat, recursive: true };
      }
      const r = await withTimeout(rr.invoke('fs:list', { dir: abs }), 15000, 'list timeout');
      if (r && r.ok) return { ok: true, path: r.path || abs, entries: r.entries || [] };
      return { ok: false, error: humanizeFsError((r && r.error) || 'Не удалось прочитать каталог', abs) };
    }
    if (normOp === 'write' || normOp === 'append') return await localWriteDirect(normOp, target, content);
    if (normOp === 'mkdir') {
      const r = await withTimeout(rr.invoke('fs:mkdir', { dir: abs }), 15000, 'mkdir timeout').catch((e) => ({ ok: false, error: String((e && e.message) || e) }));
      if (r && r.ok) return { ok: true, path: r.path || abs };
      if (isBlockedChannelError(r && r.error)) return { ok: false, error: 'Создание папок требует обновления приложения (нет канала fs:mkdir)' };
      return { ok: false, error: (r && r.error) || 'Не удалось создать папку' };
    }
    if (normOp === 'delete' || normOp === 'rm' || normOp === 'remove') {
      const r = await withTimeout(rr.invoke('fs:remove', { target: abs }), 15000, 'delete timeout').catch((e) => ({ ok: false, error: String((e && e.message) || e) }));
      if (r && r.ok) return { ok: true, path: r.path || abs, deleted: true };
      if (isBlockedChannelError(r && r.error)) return { ok: false, error: 'Удаление требует обновления приложения (нет канала fs:remove)' };
      return { ok: false, error: (r && r.error) || 'Не удалось удалить' };
    }
    return { ok: false, error: 'Операция «' + normOp + '» пока не поддерживается этой сборкой приложения' };
  } catch (e) {
    return { ok: false, error: (e && e.message) ? e.message : String(e || 'Локальная операция не удалась') };
  }
}

/* V-SEEK: локальный рекурсивный поиск по имени/содержимому (fs:list + fs:readText). */
function __globToRe(g) {
  return new RegExp('^' + String(g || '').split('*').map((x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('.*') + '$', 'i');
}
async function localSearchTool(rootDir, args) {
  const a = args || {};
  const dir = String(rootDir || '').replace(/[\\/]+$/, '');
  if (!dir) return { ok: false, output: 'Нужен каталог (path) для поиска' };
  const pat = String(a.pattern || a.query || a.q || a.text || '');
  const glob = String(a.glob || a.name || '').trim();
  const nameOnly = !!a.name_only || (!pat && !!glob);
  if (!pat && !glob) return { ok: false, output: 'search: нужен pattern (текст) и/или glob (имя, напр. *.js)' };
  const SKIPD = new Set(['node_modules', '.git', 'dist', 'build', 'out', 'target', '__pycache__', '.venv', 'venv', '.next', '.cache', '.idea', '.vscode', 'app.zip.d']);
  const globRe = glob ? __globToRe(glob) : null;
  const deadline = Date.now() + 45000;
  const hits = []; const stats = { scanned: 0, bytes: 0, dirs: 0 };
  const queue = [dir];
  const patLow = pat.toLowerCase();
  while (queue.length && hits.length < 30 && Date.now() < deadline && stats.scanned < 2500) {
    const cur = queue.shift(); stats.dirs++;
    let lr = null;
    try { lr = await withTimeout(rr.invoke('fs:list', { dir: cur }), 9000, 'scan timeout'); } catch (e) { continue; }
    if (!lr || !lr.ok) continue;
    for (const e of (lr.entries || [])) {
      const nm = String(e.name || '').replace(/\\/g, '/').replace(/^[\\/]+/, '');
      if (!nm) continue;
      const full = cur.replace(/[\\/]+$/, '') + '/' + nm;
      if (e.dir) {
        if (!SKIPD.has(nm.toLowerCase()) && cur.split(/[\\/]/).filter(Boolean).length <= 9) queue.push(full);
        continue;
      }
      if (globRe && !globRe.test(nm)) continue;
      if (nameOnly) { hits.push(full); if (hits.length >= 30) break; continue; }
      if (Number(e.size || 0) > 800000) continue;
      stats.scanned++;
      let fr = null;
      try { fr = await withTimeout(rr.invoke('fs:readText', { filePath: full }), 9000, 'read timeout'); } catch (e2) { continue; }
      if (!fr || !fr.ok || !fr.content) continue;
      stats.bytes += String(fr.content).length;
      const lines = String(fr.content).split(/\r?\n/);
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].toLowerCase().includes(patLow)) {
          hits.push(full + ':' + (i + 1) + ': ' + lines[i].trim().slice(0, 200));
          if (hits.length >= 30) break;
        }
      }
      if (stats.bytes > 28e6 || Date.now() > deadline) break;
    }
  }
  const tail = ' (просканировано ' + stats.scanned + ' файлов в ' + stats.dirs + ' папках: ' + dir + ')';
  if (!hits.length) return { ok: true, output: 'Ничего не найдено по «' + (pat || glob) + '»' + tail };
  return { ok: true, output: hits.slice(0, 30).join('\n') + '\n— найдено ' + hits.length + tail };
}
function latestChatAttachmentRef(nameOrPath) {
  const raw = String(nameOrPath || '').trim();
  const wantedName = raw.split(/[\\/]/).pop().toLowerCase();
  const wantedPath = normalizeLocalFsPath(raw);
  const chat = currentChat();
  const matchAttachment = (a) => {
    if (!a || !a.path) return false;
    const an = String(a.name || '').trim().toLowerCase();
    const ap = normalizeLocalFsPath(a.path);
    return !!(an && an === wantedName) || !!(wantedPath && ap && ap === wantedPath) || !!(wantedName && ap && ap.toLowerCase().endsWith('/' + wantedName));
  };
  if (chat && Array.isArray(chat.messages)) {
    for (let i = chat.messages.length - 1; i >= 0; i--) {
      const m = chat.messages[i];
      if (!m || m.role !== 'user' || !Array.isArray(m.attachments)) continue;
      for (const a of m.attachments) if (matchAttachment(a)) return a;
    }
  }
  for (const a of pendingAttachments || []) if (matchAttachment(a)) return a;
  return null;
}
function latestChatAttachmentPath(nameOrPath) {
  const ref = latestChatAttachmentRef(nameOrPath);
  return ref && ref.path ? ref.path : '';
}
function resolveLocalPathHint(path) {
  const p = String(path || '').trim();
  if (!p) return { path: '', fromAttachment: false };
  const ref = latestChatAttachmentRef(p);
  if (ref && ref.path) return { path: ref.path, fromAttachment: true, attachment: ref };
  return { path: p, fromAttachment: false, attachment: null };
}
function latestChatSshHint() {
  const chat = currentChat();
  if (!chat || !Array.isArray(chat.messages)) return null;
  for (let i = chat.messages.length - 1; i >= 0; i--) {
    const m = chat.messages[i];
    if (!m || m.role !== 'user' || !m.content) continue;
    const text = normalizeNewlines(String(m.content || '')).replace(/\u00a0/g, ' ');
    const host = (text.match(/(?:^|\n)\s*(?:IP|Хост|Host)\s*:\s*([^\s\n]+)/i) || [])[1];
    const port = (text.match(/(?:^|\n)\s*(?:Порт|Port)\s*:\s*(\d{1,5})/i) || [])[1];
    const user = (text.match(/(?:^|\n)\s*(?:Пользователь|User|Login|Логин)\s*:\s*([^\s\n]+)/i) || [])[1];
    const password = (text.match(/(?:^|\n)\s*(?:Пароль|Password)\s*:\s*([^\s\n]+)/i) || [])[1];
    const privateKeyPath = (text.match(/(?:^|\n)\s*(?:Ключ|Key(?: file| path)?)\s*:\s*([^\n]+)/i) || [])[1];
    if (host || user || password || privateKeyPath) {
      return { host: host || '', port: port ? Number(port) : 22, username: user || '', password: password || '', privateKeyPath: (privateKeyPath || '').trim(), passphrase: '' };
    }
  }
  return null;
}
function resolveSshCfg(args) {
  args = args || {};
  if (args.profile) {
    const p = db.sshProfiles.find((x) => x.name === args.profile || x.host === args.profile);
    if (!p) return { error: 'Профиль "' + args.profile + '" не найден. Сохранённые: ' + (db.sshProfiles.map((x) => x.name).join(', ') || '—') };
    const hint = latestChatSshHint() || {};
    return { host: p.host, port: p.port || 22, username: p.user, privateKeyPath: p.privateKeyPath || hint.privateKeyPath || '', password: args.password || hint.password || '', passphrase: args.passphrase || '' };
  }
  const hint = latestChatSshHint() || {};
  const host = args.host || hint.host || '';
  const username = args.user || args.username || hint.username || '';
  const port = Number(args.port || hint.port || 22) || 22;
  const password = args.password || hint.password || '';
  const privateKeyPath = args.privateKeyPath || hint.privateKeyPath || '';
  if (!host || !username) return { error: 'Не хватает данных: нужен host и user (и password или key).' };
  return { host, port, username, password, privateKeyPath, passphrase: args.passphrase || '' };
}

const SEARCH_SKIP_DIRS = new Set(['node_modules', '.git', '.idea', '.vscode', 'dist', 'build', 'out', 'target', 'coverage', '__pycache__', '.next', '.nuxt']);

async function walkLocalFiles(dir, out, limit) {
  if (out.length >= limit) return;
  const r = await rr.invoke('fs:list', { dir });
  if (r.error) return;
  for (const e of r.entries || []) {
    if (out.length >= limit) break;
    if (e.dir) {
      if (SEARCH_SKIP_DIRS.has(e.name)) continue;
      await walkLocalFiles(e.path, out, limit);
    } else if (TEXT_EXT.has(e.ext || extOf(e.name)) && Number(e.size || 0) <= 350000) {
      out.push(e);
    }
  }
}

async function searchLocalCode(query, baseDir) {
  const q = String(query || '').trim();
  if (!q) return [];
  const files = [];
  await walkLocalFiles(baseDir, files, 500);
  const hits = [];
  for (const file of files) {
    const r = await rr.invoke('fs:readText', { filePath: file.path });
    if (!r.ok || !r.content) continue;
    const text = normalizeNewlines(r.content);
    const lower = text.toLowerCase();
    const needle = q.toLowerCase();
    let idx = 0;
    let perFile = 0;
    while ((idx = lower.indexOf(needle, idx)) >= 0 && hits.length < 40) {
      perFile += 1;
      const before = text.slice(0, idx);
      const line = before.split('\n').length;
      const lines = text.split('\n');
      const start = Math.max(1, line - 2);
      const end = Math.min(lines.length, line + 2);
      const snippet = lines.slice(start - 1, end).map((ln, i) => `${start + i}: ${ln}`).join('\n');
      hits.push({ file: file.path, name: file.name, line, query: q, snippet });
      idx += needle.length || 1;
      if (perFile >= 5) break;
    }
  }
  return hits;
}

async function openSnippetAt(filePath, query, lineHint) {
  const r = await rr.invoke('fs:readText', { filePath });
  if (!r.ok || !r.content) return { ok: false, output: r.error || 'Не удалось открыть файл' };
  const text = normalizeNewlines(r.content);
  const lines = text.split('\n');
  let line = Number(lineHint) || 1;
  if (query) {
    const idx = text.toLowerCase().indexOf(String(query).toLowerCase());
    if (idx >= 0) line = text.slice(0, idx).split('\n').length;
  }
  const start = Math.max(1, line - 8);
  const end = Math.min(lines.length, line + 10);
  const snippetLines = [];
  for (let i = start; i <= end; i++) snippetLines.push({ no: i, text: lines[i - 1], hit: i === line });
  previewSnippet({ path: filePath, query, line, lines: snippetLines });
  return { ok: true, output: `${filePath}\nстрока ${line}\n\n` + snippetLines.map((x) => `${String(x.no).padStart(4, ' ')} | ${x.text}`).join('\n') };
}

function previewSnippet(data) {
  currentPreviewFile = { path: data.path, name: data.path.split(/[\\/]/).pop(), size: 0, target: 'local' };
  $('#preview-title').textContent = `${currentPreviewFile.name} · line ${data.line}`;
  const body = $('#preview-body');
  const editBtn = $('#preview-edit'); if (editBtn) editBtn.classList.remove('hidden');
  body.classList.add('match-view');
  body.innerHTML = data.lines.map((row) => `<div class="preview-line${row.hit ? ' hit' : ''}"><span class="ln">${row.no}</span><span class="lc">${highlightSnippet(row.text, data.query)}</span></div>`).join('');
  openModal('#preview-modal');
  setTimeout(() => body.querySelector('.preview-line.hit')?.scrollIntoView({ block: 'center' }), 40);
}
function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
function sameSshCfg(a, b) {
  if (!a || !b) return false;
  return String(a.host || '') === String(b.host || '')
    && Number(a.port || 22) === Number(b.port || 22)
    && String(a.username || a.user || '') === String(b.username || b.user || '')
    && String(a.privateKeyPath || '') === String(b.privateKeyPath || '');
}
async function ensureAiSshSession(cfg) {
  if (sshSession && sshSession.id && sameSshCfg(sshSession.cfg || sshSession, cfg)) return { id: sshSession.id, interactive: true, cfg: sshSession.cfg || cfg };
  if (aiSshSession && aiSshSession.id && sameSshCfg(aiSshSession.cfg, cfg)) return aiSshSession;
  if (aiSshSession && aiSshSession.id) {
    try { await rr.invoke('ssh:close', { id: aiSshSession.id }); } catch (e) {}
    aiSshSession = null;
  }
  const r = await rr.invoke('ssh:connect', { host: cfg.host, port: cfg.port, username: cfg.username, password: cfg.password, privateKeyPath: cfg.privateKeyPath, passphrase: cfg.passphrase, cols: 120, rows: 40 });
  if (!r || !r.ok || !r.id) throw new Error((r && r.error) || 'ssh connect failed');
  aiSshSession = { id: r.id, cfg, interactive: false };
  await sleep(900);
  return aiSshSession;
}
async function closeAiSshSession() {
  if (!aiSshSession || !aiSshSession.id) return;
  const id = aiSshSession.id;
  if (sshSession && sshSession.id === id) return;
  aiSshSession = null;
  if (aiSshPending && aiSshPending.id === id) {
    try { aiSshPending.reject(new Error('SSH session closed')); } catch (e) {}
    aiSshPending = null;
  }
  try { await rr.invoke('ssh:close', { id }); } catch (e) {}
}
async function sshExecViaPty(cfg, cmd) {
  const sess = await ensureAiSshSession(cfg);
  if (aiSshPending) throw new Error('SSH busy');
  const marker = '__RR_CMD_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
  const wrapped = `__rr_marker=${shellQuote(marker)}; printf '%s BEGIN\\n' "$__rr_marker"; {\n${String(cmd || '')}\n}; __rr_ec=$?; printf '\\n%s EXIT %s\\n' "$__rr_marker" "$__rr_ec"\n`;
  return new Promise(async (resolve, reject) => {
    const timer = setTimeout(() => {
      if (aiSshPending && aiSshPending.marker === marker) aiSshPending = null;
      reject(new Error('ssh pty timeout'));
    }, 30000);
    aiSshPending = { id: sess.id, marker, buffer: '', resolve: (res) => { clearTimeout(timer); aiSshPending = null; resolve(res); }, reject: (err) => { clearTimeout(timer); aiSshPending = null; reject(err); } };
    try {
      await rr.invoke('ssh:write', { id: sess.id, data: encodeBase64Utf8(wrapped) });
    } catch (e) {
      clearTimeout(timer);
      aiSshPending = null;
      reject(e);
    }
  });
}
async function sshExecWithRetry(cfg, cmd) {
  let last = null;
  const MAX_SSH_ATTEMPTS = 3;
  for (let attempt = 1; attempt <= MAX_SSH_ATTEMPTS; attempt++) {
    try {
      try { $('#stream-status').textContent = t('sshAttempt') + ' ' + attempt + '/' + MAX_SSH_ATTEMPTS + ' · ' + t('sshRunning'); } catch (e) {}
      const r = await rr.invoke('ssh:exec', Object.assign({ cmd }, cfg));
      if (r && r.ok) return { ok: true, output: r.output || '(пусто)', attempts: attempt };
      last = r;
      const msg = String((last && (last.error || last.output)) || '');
      if (/channel blocked: ssh:exec|not implemented|unsupported/i.test(msg)) {
        const pty = await sshExecViaPty(cfg, cmd);
        return { ok: true, output: pty.output || '(пусто)', attempts: attempt, via: 'pty' };
      }
    } catch (e) {
      const msg = e && e.message ? e.message : String(e);
      if (/channel blocked: ssh:exec|not implemented|unsupported/i.test(msg)) {
        try {
          const pty = await sshExecViaPty(cfg, cmd);
          return { ok: true, output: pty.output || '(пусто)', attempts: attempt, via: 'pty' };
        } catch (e2) {
          last = { ok: false, error: e2 && e2.message ? e2.message : String(e2) };
        }
      } else {
        last = { ok: false, error: msg };
      }
    }
    const errText = String((last && (last.error || last.output)) || '').toLowerCase();
    const transient = /timeout|timed out|econnreset|econnaborted|socket hang up|handshake|reset by peer|temporarily|try again|busy/.test(errText);
    if (!transient || attempt === MAX_SSH_ATTEMPTS) break;
    try { await closeAiSshSession(); } catch (e) {}
    await sleep(900 * attempt);
  }
  return last && last.ok ? last : { ok: false, output: (last && (last.error || last.output)) || 'SSH execution failed' };
}
function resolveRemoteToolCfg(args) {
  if (!args || (!args.profile && !args.host && !args.user)) {
    if (sshSession && sshSession.cfg) return sshSession.cfg;
    if (aiSshSession && aiSshSession.cfg) return aiSshSession.cfg;
  }
  const cfg = resolveSshCfg(args || {});
  return cfg && cfg.error ? cfg : cfg;
}
async function executeRemoteFileTool(args) {
  const cfg = resolveRemoteToolCfg(args);
  if (!cfg || cfg.error) return { ok: false, output: (cfg && cfg.error) || t('remoteNeedsSsh') };
  const path = String(args.path || '').trim();
  const op = String(args.op || '').trim();
  if (!path && !['list', 'search'].includes(op)) return { ok: false, output: 'Нужен путь к удалённому файлу' };
  if (op === 'read') {
    const r = await remoteReadTextFile(path, args);
    return r.ok ? { ok: true, output: r.content || '(пусто)' } : { ok: false, output: r.error };
  }
  if (op === 'write') {
    const r = await remoteWriteTextFile(path, String(args.content || ''), args);
    return r.ok ? { ok: true, output: 'OK: ' + path } : { ok: false, output: r.error };
  }
  if (op === 'search') {
    const base = path || '.';
    const cmd = `grep -RIn --binary-files=without-match --exclude-dir=.git --exclude-dir=node_modules -F -- ${shellQuote(args.query || '')} ${shellQuote(base)} | head -n 40`;
    const r = await sshExecWithRetry(cfg, cmd);
    return r.ok ? { ok: true, output: (r.output || '').trim() || t('codeSearchNone') } : { ok: false, output: r.output || r.error };
  }
  if (op === 'open') {
    const query = String(args.query || '');
    const findLineCmd = query
      ? `grep -n -F -- ${shellQuote(query)} ${shellQuote(path)} | head -n 1 | cut -d: -f1`
      : `printf '1\n'`;
    const lineRes = await sshExecWithRetry(cfg, findLineCmd);
    const line = Math.max(1, Number(String(lineRes.output || '1').trim()) || 1);
    const start = Math.max(1, line - 8);
    const end = line + 10;
    const r = await sshExecWithRetry(cfg, `nl -ba ${shellQuote(path)} | sed -n '${start},${end}p'`);
    return r.ok ? { ok: true, output: `${path}\nстрока ${line}\n\n${r.output || ''}` } : { ok: false, output: r.output || r.error };
  }
  return { ok: false, output: 'Неизвестная операция удалённого файла: ' + op };
}

/* V-WEB: интернет-инструмент — поиск / чтение веб-страниц / погода.
   Работает через CORS-разрешённые источники (наш API, Wikipedia, Open-Meteo).
   Если в настройках задан webSearchUrl — поиск идёт через него ('{q}' = запрос). */
function htmlToText(html) {
  let s = String(html || '');
  // V-WEBTEXT: сначала вырезаем служебные блоки целиком.
  // Раньше CSS протекал в ответ модели — она видела мусор вместо страницы и уходила на корень сайта.
  s = s.replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<template[\s\S]*?<\/template>/gi, ' ')
    .replace(/<svg[\s\S]*?<\/svg>/gi, ' ')
    .replace(/<head[\s\S]*?<\/head>/gi, ' ')
    .replace(/<link\b[^>]*>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<\/(p|div|li|tr|h[1-6]|br|section|article|header|footer|main|nav|aside|ul|ol|table|thead|tbody|form|button|label|span)>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t\u00a0]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  // V-WEBTEXT: построчный фильтр — страховка, если вёрстка нестандартная и CSS всё же просочился
  const kept = s.split('\n').filter((ln) => {
    const t = ln.trim();
    if (!t) return true;
    if (/^(-{2}[\w-]+:|@media|@keyframes|@supports|@font-face)/.test(t)) return false;
    const braces = (t.match(/[{}]/g) || []).length;
    const decls = (t.match(/[a-z-]+\s*:\s*[^;{}]+;/g) || []).length;
    if (decls >= 2 && braces >= 2) return false;
    if (braces >= 4 && decls >= 1) return false;
    if (t.length > 200 && (t.match(/;/g) || []).length >= 4 && !/[.!?]\s/.test(t)) return false;
    return true;
  });
  return kept.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}
/* Сетевой слой: сначала main-процесс (IP клиента, без CORS), затем прямой fetch (CORS-сайты). */
async function rrWebFetch(url, maxChars) {
  let mainErr = '';
  try {
    const r = await rr.invoke('web:fetch', { url: url, maxChars: maxChars || 400000 });
    if (r && r.ok) return { ok: true, text: r.text, status: r.status, contentType: r.contentType, via: 'main' };
    mainErr = (r && r.error) || 'нет ответа';
  } catch (e) { mainErr = (e && e.message) ? e.message : String(e); }
  try {
    const res = await fetch(url, { mode: 'cors', cache: 'no-store' });
    const body = await res.text();
    return { ok: true, text: body, status: res.status, contentType: String(res.headers.get('content-type') || ''), via: 'renderer' };
  } catch (e2) {
    return { ok: false, error: 'main: ' + mainErr + ' | renderer: ' + ((e2 && e2.message) ? e2.message : String(e2)) };
  }
}
async function webFetchText(url, maxChars) {
  const r = await rrWebFetch(url, maxChars || 400000);
  if (!r.ok) throw new Error(r.error);
  if (String((r.headers && r.headers['x-rr-final-url']) || '').trim() && r.finalUrl) url = r.finalUrl;
  const text = /json/i.test(r.contentType) ? r.text : htmlToText(r.text);
  // V-WEBRAW: пустой текст = JS-рендеринг. Отдаём список <script>-ассетов + кусок HTML,
  // чтобы модель дошла до .js с реальным содержимым вместо «страница пустая».
  if (!/json/i.test(r.contentType) && String(text).trim().length < 60) {
    let scripts = [];
    try { const re = /<script[^>]+src=["']([^"']+)["']/gi; let mm; while ((mm = re.exec(String(r.text))) && scripts.length < 12) { try { scripts.push(new URL(mm[1], url).href); } catch (e) { scripts.push(mm[1]); } } } catch (e) {}
    let links = [];
    try { const re2 = /<link[^>]+href=["']([^"']+\.js[^"']*)["']/gi; let mm2; while ((mm2 = re2.exec(String(r.text))) && links.length < 6) { try { links.push(new URL(mm2[1], url).href); } catch (e) {} } } catch (e) {}
    const raw = String(r.text).replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/\s+/g, ' ').slice(0, 2500);
    return '⚠ Текстового контента в HTML почти нет — страница рендерится JS. Ассеты, где лежит реальный текст/логика:\n' +
      scripts.concat(links).map((u) => '- ' + u).join('\n') +
      '\n\nСкачай нужный .js через rr-web fetch (или возьми текст через rr-ssh с сервера, если это ваш сайт).\n\nФРАГМЕНТ HTML: ' + raw;
  }
  const lim = maxChars || 6000;
  return text.length > lim ? text.slice(0, lim) + '\n…(обрезано)' : text;
}
/* Разбор выдачи поисковиков (HTML приходит с IP клиента через main-процесс). */
function parseDdgLite(html) {
  const out = [];
  const re = /<a[^>]+href="([^"]+)"[^>]*class=['"]result-link['"][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) && out.length < 8) {
    let url = m[1];
    const u = url.match(/[?&]uddg=([^&]+)/);
    if (u) { try { url = decodeURIComponent(u[1]); } catch (e) {} }
    else if (url.indexOf('//') === 0) url = 'https:' + url;
    const title = htmlToText(m[2]);
    if (title && url) out.push({ title: title, url: url });
  }
  return out;
}
/* Bing отдаёт ссылки через редирект ck/a, настоящий URL лежит в параметре u=a1<base64url>. */
function b64urlDecode(s) {
  try {
    const b = String(s).replace(/-/g, '+').replace(/_/g, '/');
    return atob(b + '='.repeat((4 - (b.length % 4)) % 4));
  } catch (e) { return ''; }
}
function parseBing(html) {
  const out = [];
  const blocks = String(html || '').split(/<li class="b_algo"/i).slice(1);
  for (const chunk of blocks) {
    const h2 = chunk.match(/<h2[^>]*>([\s\S]*?)<\/h2>/i);
    if (!h2) continue;
    const a = h2[1].match(/<a[^>]*href="([^"]+)"/i);
    if (!a) continue;
    let url = a[1].replace(/&amp;/g, '&');
    const u = url.match(/[?&]u=a1([^&]+)/);
    if (u) { const d = b64urlDecode(u[1]); if (d) url = d; }
    const title = htmlToText(h2[1]);
    if (title && /^https?:/i.test(url)) out.push({ title: title, url: url });
    if (out.length >= 8) break;
  }
  return out;
}
function parseGoogle(html) {
  const out = [];
  const re = /<a[^>]+href="\/url\?q=([^"&]+)[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) && out.length < 8) { let u = m[1]; try { u = decodeURIComponent(u); } catch (e) {} const t = htmlToText(m[2]); if (t && /^https?:/i.test(u)) out.push({ title: t, url: u }); }
  return out;
}
async function webSearch(query) {
  const proxy = String(S().webSearchUrl || '').trim();
  if (proxy) { try { return await webFetchText(proxy.replace('{q}', encodeURIComponent(query)), 20000); } catch (e) {} }
  const q = encodeURIComponent(query);
  const engines = [
    ['DuckDuckGo', 'https://lite.duckduckgo.com/lite/?q=' + q, parseDdgLite],
    ['Bing', 'https://www.bing.com/search?q=' + q, parseBing],
    ['Google', 'https://www.google.com/search?num=10&q=' + q, parseGoogle]
  ];
  const tried = [];
  for (const e of engines) {
    const r = await rrWebFetch(e[1], 800000);
    if (!r.ok) { tried.push(e[0] + ' — ' + r.error); continue; }
    const hits = e[2](r.text);
    if (hits.length) {
      return 'Поиск (' + e[0] + '): ' + query + '\n' + hits.map((h, i) => (i + 1) + '. ' + h.title + '\n   ' + h.url).join('\n');
    }
    tried.push(e[0] + ' — выдача не разобрана');
  }
  return 'Ничего не найдено по запросу «' + query + '». Попытки: ' + tried.join(' | ');
}
async function webWeather(place) {
  const g = JSON.parse(await webFetchText('https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&format=json&name=' + encodeURIComponent(place), 400000));
  const hit = g && g.results && g.results[0];
  if (!hit) return 'Не нашёл населённый пункт: ' + place;
  const f = JSON.parse(await webFetchText('https://api.open-meteo.com/v1/forecast?current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=3&latitude=' + hit.latitude + '&longitude=' + hit.longitude, 400000));
  const cur = (f && f.current) || {};
  const d = (f && f.daily) || {};
  const codes = { 0: 'ясно', 1: 'малооблачно', 2: 'переменная облачность', 3: 'пасмурно', 45: 'туман', 48: 'туман', 51: 'морось', 53: 'морось', 55: 'морось', 61: 'небольшой дождь', 63: 'дождь', 65: 'сильный дождь', 71: 'небольшой снег', 73: 'снег', 75: 'сильный снег', 80: 'ливни', 81: 'ливни', 82: 'сильные ливни', 95: 'гроза', 96: 'гроза с градом', 99: 'гроза с градом' };
  let out = 'Погода: ' + (hit.name || place) + (hit.country ? ', ' + hit.country : '') + '\n';
  out += 'Сейчас: ' + cur.temperature_2m + '°C (ощущается ' + cur.apparent_temperature + '°C), ' + (codes[cur.weather_code] || ('код ' + cur.weather_code)) + ', ветер ' + cur.wind_speed_10m + ' км/ч\n';
  if (d.time) for (let i = 0; i < d.time.length; i++) out += d.time[i] + ': ' + d.temperature_2m_min[i] + '…' + d.temperature_2m_max[i] + '°C\n';
  return out;
}
async function executeWebTool(args) {
  const op = String((args && args.op) || 'fetch').toLowerCase();
  try {
    if (op === 'weather') return { ok: true, output: await webWeather(args.place || args.city || args.query || '') };
    if (op === 'search') return { ok: true, output: await webSearch(args.query || args.q || '') };
    if (op === 'fetch' || op === 'open') {
      const url = String(args.url || '').trim();
      if (!/^https?:\/\//i.test(url)) return { ok: false, output: 'Нужен полный URL (http/https)' };
      const out = await webFetchText(url, Number(args.maxChars) || 12000);
      // V-WEBTEXT: явно указываем, какая страница прочитана — модель не должна подменять её корнем сайта
      return { ok: true, output: 'СТРАНИЦА: ' + url + '\n\n' + out };
    }
    // V-BROWSER: показать страницу пользователю во встроенном браузере терминала
    if (op === 'view' || op === 'browse' || op === 'show') {
      const url = String(args.url || '').trim();
      if (!/^https?:\/\//i.test(url)) return { ok: false, output: 'Нужен полный URL (http/https)' };
      return openBrowserResult(url);
    }
    return { ok: false, output: 'Неизвестная операция: ' + op };
  } catch (e) {
    return { ok: false, output: 'Веб-запрос не удался: ' + (e && e.message ? e.message : String(e)) };
  }
}

/* V-DOC: создание документов. Бинарные форматы пишутся через fs:writeBinary (main-процесс). */
function normalizeDocumentTarget(input, ext) {
  const wanted = String(ext || 'docx').replace(/^\\./, '').toLowerCase();
  let p = String(input || '').trim();
  if (!p) return 'document.' + wanted;
  if (!/\.[A-Za-z0-9]{1,8}$/.test(p)) return p + '.' + wanted;
  return p.replace(/\.[A-Za-z0-9]{1,8}$/, '.' + wanted);
}
/* V-DOCPATH: если папки нет — создаём родителя и повторяем запись один раз */
async function writeWithMkdirRetry(invokeName, payload, absPath) {
  let r = null;
  try { r = await rr.invoke(invokeName, payload); } catch (e) { r = { error: String((e && e.message) || e) }; }
  const err = String((r && (r.error || r.message)) || '');
  if (!/ENOENT/i.test(err)) return r;
  const m = String(absPath || '').replace(/[\\/]+$/, '').match(/^(.*)[\\/][^\\/]+$/);
  const dir = m ? (m[1] || (absPath[1] === ':' ? absPath.slice(0, 2) + '/' : '/')) : '';
  if (!dir) return r;
  try { await rr.invoke('fs:mkdir', { dir }); } catch (e) { return r; }
  try { return await rr.invoke(invokeName, payload); } catch (e) { return { error: String((e && e.message) || e) }; }
}
/* V-DOCPATH: подтверждение, что документ реально лёг на диск (fs:list родителя, размер) */
async function verifyDocWritten(absPath, expectedBytes) {
  try {
    const t = String(absPath || '').replace(/[\\/]+$/, '');
    let m = t.match(/^(.*)[\\/][^\\/]+$/);
    if (!m) return { ok: true };
    let dir = m[1] || '';
    if (/^[A-Za-z]:$/.test(dir)) dir += '/';
    if (!dir) dir = '/';
    const name = t.slice(dir.length).replace(/^[\\/]+/, '');
    const r = await withTimeout(rr.invoke('fs:list', { dir }), 15000, 'doc verify timeout');
    if (!r || !r.ok) return { ok: false, error: 'папка недоступна после записи: ' + dir };
    const hit = (r.entries || []).find((e) => !e.dir && String(e.name || '').toLowerCase() === String(name || '').toLowerCase());
    if (!hit) return { ok: false, error: 'файл не найден после записи: ' + t };
    if (expectedBytes > 0 && Number(hit.size || 0) !== expectedBytes) return { ok: false, error: 'размер ' + hit.size + ' вместо ' + expectedBytes + ': ' + t };
    return { ok: true, path: t };
  } catch (e) { return { ok: true }; }
}
async function executeDocTool(args) {
  let built;
  try { built = buildDocument(args || {}); } catch (e) { return { ok: false, output: 'Ошибка генерации: ' + ((e && e.message) || String(e)) }; }
  if (!built || built.kind === 'error') return { ok: false, output: (built && built.error) || 'не удалось собрать документ' };
  const requestedTarget = String((args && (args.path || args.file)) || '').trim();
  const baseName = (args && args.title) ? String(args.title).slice(0, 60) : 'document';
  const suggested = normalizeDocumentTarget(requestedTarget || baseName, built.ext);
  let target = '';
  if (requestedTarget) {
    if (!homeDirCache) { try { homeDirCache = await rr.invoke('fs:home'); } catch (e) {} }
    const sc = resolveScopedLocalTarget(normalizeDocumentTarget(requestedTarget, built.ext), S().workDir || homeDirCache || '', {});
    if (!sc.ok) return { ok: false, output: sc.error };
    target = sc.absolute;
  }
  try {
    if (built.kind === 'text') {
      const r = target
        ? await writeWithMkdirRetry('fs:writeText', { filePath: target, content: built.text }, target)
        : await rr.invoke('fs:saveDialog', { suggestedName: suggested, content: built.text });
      if (r && r.ok) {
        const path2 = r.path || suggested;
        let blen = 0; try { blen = new TextEncoder().encode(built.text).length; } catch (e) {}
        const v = await verifyDocWritten(path2, blen);
        if (!v.ok) return { ok: false, output: t('writeVerifyFail') + ' ' + v.error };
        return { ok: true, output: built.ext.toUpperCase() + ' создан: ' + path2 };
      }
      return { ok: false, output: (r && r.error) || 'не удалось сохранить' };
    }
    const base64 = u8ToBase64(built.bytes);
    const filters = [{ name: built.ext.toUpperCase(), extensions: [built.ext] }, { name: 'Все файлы', extensions: ['*'] }];
    const r = target
      ? await writeWithMkdirRetry('fs:writeBinary', { filePath: target, base64: base64 }, target)
      : await rr.invoke('fs:writeBinary', { askPath: true, suggestedName: suggested, base64: base64, filters: filters });
    if (r && r.canceled) return { ok: false, output: 'Сохранение отменено пользователем' };
    if (r && r.ok) {
      const path3 = r.path || suggested;
      const v3 = await verifyDocWritten(path3, built.bytes.length);
      if (!v3.ok) return { ok: false, output: t('writeVerifyFail') + ' ' + v3.error };
      return { ok: true, output: built.ext.toUpperCase() + ' создан: ' + path3 + ' (' + (r.bytes || built.bytes.length) + ' байт)' };
    }
    // V-MEMFIX: у старого шелла нет fs:writeBinary — отдаём файл через скачивание в окне терминала
    if (!target) {
      try {
        const bin = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
        const blob = new Blob([bin], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url; link.download = suggested;
        document.body.appendChild(link); link.click();
        setTimeout(() => { try { URL.revokeObjectURL(url); link.remove(); } catch (e2) {} }, 5000);
        return { ok: true, output: built.ext.toUpperCase() + ' сформирован и скачан: ' + suggested + ' (' + built.bytes.length + ' байт)' };
      } catch (e2) { /* ниже — текст ошибки */ }
    }
    return { ok: false, output: (r && r.error) || 'не удалось записать файл — нужен пропатченный main.js (fs:writeBinary)' };
  } catch (e) {
    return { ok: false, output: 'Ошибка записи: ' + ((e && e.message) || String(e)) };
  }
}

/* V-LOCALSHELL: исполнение команд на ПК пользователя — как в Codex / Claude Code.
 * Канал sys:exec живёт в оболочке (main.js). Если оболочка старая и канала нет —
 * честно сообщаем, что нужно обновить оболочку, и предлагаем rr-ssh/rr-file. */
let shellAlwaysAllow = false;   // «всегда разрешать» в рамках сессии
function resolveShellCwd(rel, wd) {
  const base = String(wd || '');
  const rel2 = String(rel || '').trim();
  if (!rel2 || rel2 === '.') return base;
  if (/^([A-Za-z]:[\\/]|\/)/.test(rel2)) return rel2;                 // абсолютный путь
  if (rel2.charAt(0) === '~') return rel2.replace(/^~/, base);        // ~/ → рабочая папка
  return base.replace(/[\\/]+$/, '') + '/' + rel2;
}
async function executeShellTool(args) {
  const cmd = String((args && (args.cmd || args.command)) || '').trim();
  if (!cmd) return { ok: false, output: 'Пустая команда: нужен параметр "cmd".' };
  if (S().allowLocalShell === false) {
    return { ok: false, output: 'Локальное выполнение команд выключено в настройках («Выполнять команды на этом ПК»). Попросите пользователя включить его в настройках терминала.' };
  }
  const wd = S().workDir || homeDirCache || '';
  const cwdAbs = resolveShellCwd(args && args.cwd, wd);
  // Подтверждение (как в Codex / Claude Code): спрашиваем каждый раз, если не включён авто-режим
  const autoApprove = (shellAlwaysAllow || S().shellAutoApprove === true);
  if (!autoApprove) {
    const decision = await askShellConfirm(cmd, cwdAbs);
    if (decision === 'always') shellAlwaysAllow = true;
    else if (decision !== 'run') return { ok: false, output: 'Пользователь отклонил выполнение команды.' };
  }
  let r;
  try {
    r = await rr.invoke('sys:exec', {
      cmd,
      cwd: cwdAbs,
      timeoutMs: Math.min(Math.max(Number(args && args.timeoutMs) || 180000, 1000), 600000)
    });
  } catch (e) {
    const msg = String((e && e.message) || e || '');
    if (/No handler registered|sys:exec/i.test(msg)) {
      return { ok: false, output: 'Оболочка терминала ещё не обновлена: локальное выполнение команд появится после обновления оболочки (нужна одна пересборка EXE). Пока используйте rr-ssh для серверов и rr-file для файлов.' };
    }
    return { ok: false, output: 'Ошибка выполнения: ' + msg };
  }
  if (!r || typeof r !== 'object') return { ok: false, output: 'Пустой ответ оболочки.' };
  const parts = [];
  if (r.stdout) parts.push(String(r.stdout));
  if (r.stderr) parts.push('[stderr]\n' + String(r.stderr));
  let text = parts.join('\n').trim() || '(нет вывода)';
  const code = (r.exitCode == null ? '?' : r.exitCode);
  text += '\n\n[exit ' + code + (r.timedOut ? ' · TIMEOUT' : '') + ' · ' + (cwdAbs || 'cwd') + ']';
  // 1.2.83: ENV SNAPSHOT — при ошибке команды автоматически подмешиваем слепок окружения
  // (версии CLI, свободная память, слушающие порты), чтобы модель сразу видела причину «порт занят/не та версия»
  if (!r.ok) {
    try {
      const snap = await buildEnvSnapshot();
      if (snap) text += '\n\n[ENV SNAPSHOT]\n' + snap;
    } catch (e) {}
  }
  return { ok: !!r.ok, output: text };
}
// 1.2.83: быстрый слепок окружения (кросс-платформа, ≤15 с)
async function buildEnvSnapshot() {
  const cmd = IS_WIN
    ? 'node -v & npm -v & python --version & git --version & powershell -NoProfile -Command "(Get-CimInstance Win32_OperatingSystem | ForEach-Object {{ \'RAM free/total: \' + [math]::Round($_.FreePhysicalMemory/1MB) + \'/\' + [math]::Round($_.TotalVisibleMemorySize/1MB) + \' MB\' }}); Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Select-Object -First 12 LocalPort,OwningProcess | Format-Table -AutoSize | Out-String"'
    : IS_DARWIN
      ? 'node -v; npm -v; python3 -V; git --version; memory_pressure 2>/dev/null | head -2 || vm_stat | head -4; (lsof -iTCP -sTCP:LISTEN -P -n 2>/dev/null || netstat -an 2>/dev/null | grep LISTEN) | head -14'
      : 'node -v; npm -v; python3 -V; git --version; free -m | head -2; (ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | head -14';
  try {
    const r = await withTimeout(rr.invoke('sys:exec', { cmd, cwd: '', timeoutMs: 15000 }), 16000, 'env snapshot timeout');
    const out = ((r && r.stdout) || '') + (r && r.stderr ? '\n' + r.stderr : '');
    return String(out).trim().slice(0, 1600) || null;
  } catch (e) { return null; }
}
function askShellConfirm(cmd, cwd) {
  return new Promise((resolve) => {
    let bd = $('#shell-confirm-backdrop');
    if (!bd) {
      bd = document.createElement('div');
      bd.id = 'shell-confirm-backdrop';
      bd.className = 'shell-confirm-backdrop hidden';
      bd.innerHTML = '<div class="shell-confirm">'
        + '<div class="sc-head">⌨️ <span id="sc-title"></span></div>'
        + '<div class="sc-cwd" id="sc-cwd"></div>'
        + '<pre class="sc-cmd" id="sc-cmd"></pre>'
        + '<div class="sc-btns">'
        + '<button id="sc-run" class="btn-accent"></button>'
        + '<button id="sc-always" class="btn-ghost"></button>'
        + '<button id="sc-deny" class="btn-ghost"></button>'
        + '</div></div>';
      document.body.appendChild(bd);
    }
    const L = (ru, en) => LANG === 'en' ? en : ru;
    $('#sc-title').textContent = L('Выполнить команду на этом ПК?', 'Run this command on your PC?');
    $('#sc-cwd').textContent = (L('Рабочая папка', 'Working dir') + ': ') + (cwd || '—');
    $('#sc-cmd').textContent = cmd;
    $('#sc-run').textContent = '▶ ' + L('Выполнить', 'Run');
    $('#sc-always').textContent = L('Всегда разрешать', 'Always allow');
    $('#sc-deny').textContent = L('Отклонить', 'Deny');
    bd.classList.remove('hidden');
    const done = (v) => {
      bd.classList.add('hidden');
      $('#sc-run').onclick = null; $('#sc-always').onclick = null; $('#sc-deny').onclick = null;
      resolve(v);
    };
    $('#sc-run').onclick = () => done('run');
    $('#sc-always').onclick = () => done('always');
    $('#sc-deny').onclick = () => done('deny');
  });
}

// ==== V-VIDEO-CLI (1.2.96): генерация видео через шлюз (POST /v1/videos), опрос статуса,
// карточка-плеер в чате. Списание на шлюзе — только при completed, потому «не готово»
// всегда дёшево. Статус пишем в индикатор прогона, чтобы пользователь видел жизнь.
function gwOrigin() {
  const base = String(S().baseUrl || 'https://riskradarai.ru/v1').replace(/\/+$/, '');
  try { return new URL(base).origin; } catch (e) { return 'https://riskradarai.ru'; }
}
function gwV1() {
  return String(S().baseUrl || 'https://riskradarai.ru/v1').replace(/\/+$/, '');
}
function pushVideoCard(j, origin) {
  try {
    const chat = currentChat();
    if (!chat) return;
    const id = String(j.id || '');
    const gw = j.gateway || {};
    const src = gw.content_url ? origin + gw.content_url : (origin + '/v1/videos/' + encodeURIComponent(id) + '/content');
    const model = String(j.model || gw.task || 'sora-2');
    const secs = Number(j.seconds || 0);
    const md = '🎬 **Видео готово** — `' + model + '`' + (secs ? ', ' + secs + ' с' : '') + '\n\n'
      + '<video src="' + src + '" controls preload="metadata" style="max-width:100%;border-radius:10px"></video>\n\n'
      + '[💾 Скачать mp4](' + src + ') · id задачи: `' + id + '`';
    chat.messages.push({ role: 'assistant', content: md, reasoning: '', modelName: 'видео', ts: Date.now(), streaming: false });
    saveDb();
    renderMessages();
  } catch (ePc) { try { toast('Не удалось показать карточку видео: ' + (ePc.message || ePc), 'err'); } catch (e) {} }
}
async function executeVideoTool(args) {
  const L = (ru, en) => LANG === 'en' ? en : ru;
  try {
    const a = args || {};
    const prompt = String(a.prompt || '').trim();
    if (!prompt) return { ok: false, output: L('rr-video: пустой prompt', 'rr-video: empty prompt') };
    const model = String(a.model || 'sora-2').trim();
    const base = gwV1();
    const key = String(S().apiKey || '').trim();
    const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key };
    const body = { model: model, prompt: prompt };
    if (a.seconds) body.seconds = Math.min(12, Math.max(1, Number(a.seconds) || 4));
    if (a.size) body.size = String(a.size);
    if (a.aspect_ratio) body.aspect_ratio = String(a.aspect_ratio);
    if (a.input_reference) body.input_reference = a.input_reference;
    const r0 = await fetch(base + '/videos', { method: 'POST', headers: H, body: JSON.stringify(body) });
    const t0 = await r0.text().catch(() => '');
    let j0 = null; try { j0 = JSON.parse(t0); } catch (e) {}
    if (!r0.ok) {
      const em = j0 && j0.error && (j0.error.message || j0.error) || (t0 || '').slice(0, 240) || ('HTTP ' + r0.status);
      return { ok: false, output: L('Видео не создано: ', 'Video not created: ') + String(em) };
    }
    const vid = String((j0 && j0.id) || '');
    if (!vid) return { ok: false, output: L('Ответ без id задачи: ', 'Response without task id: ') + t0.slice(0, 200) };
    const origin = gwOrigin();
    if (j0 && /completed|succeeded/i.test(String(j0.status || ''))) {
      pushVideoCard(Object.assign({ id: vid, model: model }, j0), origin);
      return { ok: true, output: 'VIDEO_READY id=' + vid + L(' — карточка с плеером добавлена в чат.', ' — player card added to chat.') };
    }
    const t0ms = Date.now();
    let status = String(j0 && j0.status || 'queued');
    let last = j0 || {};
    while (true) {
      await new Promise((rS) => setTimeout(rS, 7000));
      try {
        const rs = await fetch(base + '/videos/' + encodeURIComponent(vid), { headers: { Authorization: 'Bearer ' + key } });
        const ts = await rs.text().catch(() => '');
        let js = null; try { js = JSON.parse(ts); } catch (e) {}
        if (js && typeof js === 'object') { last = js; status = String(js.status || status); }
      } catch (ePoll) { /* сеть мигнула — продолжаем опрос, не прерывая */ }
      const el = Math.round((Date.now() - t0ms) / 1000);
      try { const ss = document.querySelector('#stream-status'); if (ss) ss.textContent = '🎬 ' + L('генерация видео — ', 'generating video — ') + el + 's · ' + status; } catch (e) {}
      if (/completed|succeeded/i.test(status)) break;
      if (/failed|cancelled|expired/i.test(status)) {
        const em = (last && last.error && (last.error.message || last.error)) || L('модель вернула ошибку', 'model returned an error');
        return { ok: false, output: L('Видео НЕ готово (списание не производилось): ', 'Video failed (nothing was charged): ') + String(em).slice(0, 300) };
      }
      if (Date.now() - t0ms > 13 * 60 * 1000) {
        return { ok: false, output: L('Генерация дольше 13 минут — задача id=', 'Generation over 13 minutes — task id=') + vid + L(' ещё живёт на сервере, результат можно забрать позже. Не списывай повторно.', ' is still on the server; the result can be fetched later. Do not re-charge.') };
      }
    }
    pushVideoCard(Object.assign({ id: vid, model: model, seconds: body.seconds }, last), origin);
    return { ok: true, output: 'VIDEO_READY (' + Math.round((Date.now() - t0ms) / 1000) + L('s) id=', 's) id=') + vid + L(' — карточка с плеером добавлена в чат.', ' — player card added to chat.') };
  } catch (eV) {
    return { ok: false, output: L('Видео: ошибка ', 'Video: error ') + String((eV && eV.message) || eV) };
  }
}
async function executeToolBlock(b) {
  // V-SKILLS: подгрузка навыка из каталога
  if (b.type === 'rr-blender') {
    const r = await rr.invoke('graphics:blender', b.args || {});
    return { ok: !!r.ok, output: r.ok ? JSON.stringify(r, null, 2) : (r.error || 'Blender failed') };
  }
  if (b.type === 'rr-photoshop') {
    const r = await rr.invoke('graphics:photoshop', b.args || {});
    return { ok: !!r.ok, output: r.ok ? JSON.stringify(r, null, 2) : (r.error || 'Photoshop failed') };
  }
  if (b.type === 'rr-skill') {
    return executeSkillTool(b.args);
  }
  if (b.type === 'rr-shell') {
    return executeShellTool(b.args);
  }
  if (b.type === 'rr-doc') {
    return executeDocTool(b.args);
  }
  if (b.type === 'rr-web') {
    return executeWebTool(b.args);
  }
  if (b.type === 'rr-video') {
    return await executeVideoTool(b.args);
  }
  if (b.type === 'rr-ssh') {
    const cfg = resolveSshCfg(b.args);
    if (cfg.error) return { ok: false, output: cfg.error };
    const r = await sshExecWithRetry(cfg, b.args.cmd);
    return r.ok ? { ok: true, output: r.output || '(пусто)' } : { ok: false, output: r.output || r.error };
  }
  if (b.type === 'rr-balance') {
    try {
      const viaHttp = await fetchBalanceDirect();
      const normalized = normalizeBalancePayload(viaHttp);
      if (normalized) {
        applyBalanceUi(normalized);
        return { ok: true, output: JSON.stringify(normalized.raw || normalized, null, 2) };
      }
    } catch (e) {}
    try {
      const viaBridge = await rr.invoke('gw:balance', { baseUrl: S().baseUrl, apiKey: S().apiKey });
      const normalized = normalizeBalancePayload(viaBridge);
      if (normalized) {
        applyBalanceUi(normalized);
        return { ok: true, output: JSON.stringify(normalized.raw || normalized, null, 2) };
      }
    } catch (e) {}
    return { ok: false, output: 'Balance response parse failed' };
  }
  if (b.type === 'rr-rfile') {
    return executeRemoteFileTool(b.args);
  }
  const wd = S().workDir || homeDirCache;
  const hinted = resolveLocalPathHint(b.args.path);
  const hintedPath = hinted.path;
  if (b.args.op === 'search') {
    // V-SEEK: сначала честный рекурсивный поиск по ФС; индекс открытых файлов — как фолбэк
    const pat0 = String(b.args.pattern || b.args.q || b.args.query || '');
    if (pat0 || b.args.glob || b.args.name || b.args.name_only) {
      const scoped0 = resolveScopedLocalTarget((hintedPath && hintedPath !== '.') ? hintedPath : wd, wd, { allowOutsideWorkDir: true });
      const rootAbs = (scoped0 && scoped0.ok && (scoped0.absolute || scoped0.workDir)) || wd;
      const sr = await localSearchTool(rootAbs, { pattern: pat0, glob: b.args.glob || b.args.name, name_only: b.args.name_only });
      window.__RR_LAST_SEARCH__ = null;
      return sr;
    }
    const hits = await searchLocalCode(b.args.query, wd);
    window.__RR_LAST_SEARCH__ = hits;
    return { ok: true, output: hits.length ? hits.map((x) => `${x.file}:${x.line}\n${x.snippet}`).join('\n\n') : t('codeSearchNone') };
  }
  if (b.args.op === 'open') {
    const scoped = resolveScopedLocalTarget(hintedPath === '.' ? wd : hintedPath, wd, { allowOutsideWorkDir: !!hinted.fromAttachment });
    if (!scoped.ok) return { ok: false, output: scoped.error };
    const filePath = scoped.path === '.' ? (scoped.workDir || wd) : scoped.absolute;
    return filePath ? openSnippetAt(filePath, b.args.query, b.args.line) : { ok: false, output: 'Нужен путь к файлу' };
  }
  const execTarget = resolveScopedLocalTarget(hintedPath, wd, { allowOutsideWorkDir: !!hinted.fromAttachment });
  if (!execTarget.ok) return { ok: false, output: execTarget.error };
  // V-FSPATH: путь мог быть собран от корня рабочей папки по имени из вывода `list`,
  // хотя реально лежит вложеннее. Пробуем найти его и чиним, а не отдаём «нет доступа».
  let finalTarget = execTarget;
  const fixedAbs = await findNestedPath(execTarget.absolute, wd);
  if (fixedAbs) {
    finalTarget = { ok: true, path: fixedAbs.slice(wd.length + 1), workDir: wd, absolute: fixedAbs, autoFixed: true };
  }
  const sop = String(b.args.op || '').toLowerCase();
  if (sop === 'grep' || sop === 'find') {
    return await localSearchTool(finalTarget.absolute || finalTarget.workDir, b.args);
  }
  // 1.2.84 V-PATCH: точечные правки (аналог patch_file из Claude Code) — без перезаписи всего файла
  if (sop === 'patch') {
    const oldTxt = String(b.args.old != null ? b.args.old : (b.args.old_content != null ? b.args.old_content : b.args.from) || '');
    const newTxt = b.args['new'] != null ? String(b.args['new']) : (b.args.new_content != null ? String(b.args.new_content) : (b.args.to != null ? String(b.args.to) : ''));
    if (!oldTxt) return { ok: false, output: 'patch: нужен "old" — точный текст, который заменяем' };
    const absP = finalTarget.absolute || finalTarget.workDir;
    // 1.2.85 V-DEBATE: критик смотрит правку до записи
    if (S().debateMode) {
      const chatD = currentChat();
      const gP = await criticGate('patch', absP, 'OLD:\n' + oldTxt.slice(0, 2500) + '\n===== NEW =====\n' + newTxt.slice(0, 3500), chatD);
      if (gP && !gP.ok && !(chatD && Number(chatD.__criticBlocks) > 2)) return { ok: false, output: criticRejectOutput(gP) };
      if (gP && !gP.ok) { try { toast('⚖ Критик отклоняет 3-й раз — записываю с предупреждением', 'warn'); } catch (e) {} }
    }
    const rr2 = await localExecWithFallback('read', finalTarget, null, {});
    if (!rr2 || !rr2.ok) return { ok: false, output: 'patch: не могу прочитать файл: ' + ((rr2 && (rr2.error || rr2.output)) || absP) };
    const srcP = rr2.content || '';
    const idx = srcP.indexOf(oldTxt);
    if (idx < 0) {
      const lines = srcP.split('\n');
      const needle = (oldTxt.split('\n')[0] || '').trim();
      const near = [];
      if (needle.length > 3) {
        for (let i = 0; i < lines.length && near.length < 6; i++) {
          const t2 = lines[i].trim();
          if (t2 && (t2 === needle || t2.includes(needle))) near.push(`  ${i + 1}: ${lines[i].slice(0, 160)}`);
        }
      }
      return { ok: false, output: `patch: точный текст "old" не найден в ${absP}.${near.length ? '\nПохожие строки:\n' + near.join('\n') : ''}\nСначала op:read с нумерацией или op:open, скопируйте ТЕКУЩИЙ текст дословно (пробелы/отступы!) и повторите.` };
    }
    const cnt = srcP.split(oldTxt).length - 1;
    if (cnt > 1 && !b.args.all) return { ok: false, output: `patch: в ${absP} найдено ${cnt} совпадения. Уточните "old" (больше контекста вокруг) либо добавьте "all": true, чтобы заменить все.` };
    const updated = b.args.all ? srcP.split(oldTxt).join(newTxt) : srcP.slice(0, idx) + newTxt + srcP.slice(idx + oldTxt.length);
    const wr = await localExecWithFallback('write', finalTarget, updated, {});
    if (!wr || !wr.ok) return { ok: false, output: 'patch: запись не удалась: ' + ((wr && (wr.error || wr.output)) || '') };
    const lineNo = srcP.slice(0, idx).split('\n').length;
    return { ok: true, output: `OK: пропатчен ${absP} (строка ${lineNo}${cnt > 1 ? ', заменено мест: ' + cnt : ''}; новый размер ${updated.length} символов). Проверьте: op:open с query из нового кода.` };
  }
  if (sop === 'stats') {
    const absS = finalTarget.absolute || finalTarget.workDir;
    const rs = await localExecWithFallback('read', finalTarget, null, {});
    if (rs && rs.ok) {
      const c = rs.content || '';
      return { ok: true, output: `FILE ${absS}\nsize: ${c.length} символов (${(c.length / 1024).toFixed(1)} KB)\nlines: ${c.length ? c.split('\n').length : 0}` };
    }
    const rl = await localExecWithFallback('list', finalTarget, null, {});
    if (rl && rl.ok) return { ok: true, output: `DIR ${absS}\nentries: ${(rl.entries || []).length}\n` + (rl.entries || []).slice(0, 50).map((x) => (x.dir ? '📁 ' : '   ') + x.name).join('\n') };
    return { ok: false, output: 'stats: ' + ((rs && (rs.error || rs.output)) || absS) };
  }
  if (sop === 'write') {
    // 1.2.85 V-DEBATE: критик смотрит содержимое до записи на диск
    if (S().debateMode) {
      const chatD = currentChat();
      const absW = finalTarget.absolute || finalTarget.workDir;
      const gW = await criticGate('write', absW, String(b.args.content || ''), chatD);
      if (gW && !gW.ok && !(chatD && Number(chatD.__criticBlocks) > 2)) return { ok: false, output: criticRejectOutput(gW) };
      if (gW && !gW.ok) { try { toast('⚖ Критик отклоняет 3-й раз — записываю с предупреждением', 'warn'); } catch (e) {} }
    }
  }
  if (sop === 'read' && (b.args.start || b.args.end)) {
    // 1.2.84 V-PAGE: чтение с пагинацией по строкам (большие логи/дампы без съедания контекста)
    const rr3 = await localExecWithFallback('read', finalTarget, null, {});
    if (!rr3 || !rr3.ok) return { ok: false, output: 'read: ' + ((rr3 && (rr3.error || rr3.output)) || '') };
    const ls = (rr3.content || '').split('\n');
    const st = Math.max(1, parseInt(b.args.start, 10) || 1);
    const en = Math.min(ls.length, parseInt(b.args.end, 10) || (st + 199));
    const chunk = ls.slice(st - 1, en).map((l2, i) => `${st + i}│ ${l2}`).join('\n');
    return { ok: true, output: `${finalTarget.absolute || finalTarget.workDir} · строки ${st}–${en} из ${ls.length}\n${chunk}` };
  }
  const r = await localExecWithFallback(b.args.op, finalTarget, b.args.content, b.args);
  if (r && r.ok) {
    let out;
    if (b.args.op === 'read') out = r.content || '(пусто)';
    else if (b.args.op === 'list') {
      out = (r.entries || []).map((e2) => (e2.dir ? '📁 ' : '   ') + e2.name).join('\n') || '(пусто)';
      // V-FSPATH: сразу показываем, чем дополнять путь, чтобы модель не гадала
      if (r.path) out += '\n\n(путь внутри рабочей папки задавайте относительно ' + r.path + ' — например "' + r.path.replace(/\/$/, '') + '/имя-файла")';
    }
    else out = 'OK: ' + (r.path || r.deleted || finalTarget.absolute || finalTarget.path || '');
    if (finalTarget.autoFixed) out = '[путь уточнён: ' + finalTarget.absolute + ']\n' + out;
    return { ok: true, output: out };
  }
  // V-FSPATH: если папки нет — объясняем причину человеческим языком и предлагаем варианты
  const errText = String((r && (r.error || r.output)) || '');
  if (/ENOENT|no such file/i.test(errText)) {
    const base = normalizeLocalFsPath(wd || '');
    const tops = await listTopLevel(base);
    const tried = finalTarget.absolute || '';
    let hint = 'По пути ничего нет: ' + tried + '. Это НЕ отказ в доступе — файл/папка там отсутствует.';
    if (tops.length) hint += '\nСразу внутри рабочей папки есть такие каталоги: ' + tops.slice(0, 25).join(', ') + '.';
    hint += '\nСначала сделайте list нужного каталога и используйте путь из его вывода целиком, не только имя.';
    return { ok: false, output: hint };
  }
  return { ok: false, output: (r && (r.error || r.output)) || 'Local file operation failed' };
}

/* ------------------------------ отправка ------------------------------ */
/* ------------------------------ отправка ------------------------------ */

// V-PAYFIX: если ответ модели оборвался, достраиваем его с места обрыва (а не начинаем заново).
function buildContinuationMessages(chat, partial) {
  const msgs = buildApiMessages(chat);
  const tail = String(partial || '');
  if (!tail) return msgs;
  msgs.push({ role: 'assistant', content: sanitizeHistoryText(tail) });
  msgs.push({ role: 'user', content: 'Ответ оборвался на середине. Продолжи его ровно с места обрыва: не повторяй уже написанное, не начинай заново, просто продолжи текст.' });
  return msgs;
}
/* V-HIST2: в историю нельзя отправлять base64-картинки (они весят мегабайты) —
 * иначе запрос раздувается до миллионов токенов и модель теряет реальный контекст. */
function sanitizeHistoryText(text, cap) {
  let t = String(text == null ? '' : text);
  t = t.replace(/!\[[^\]]*\]\(\s*data:image\/[^)]*\)/gi, '[изображение]');
  t = t.replace(/data:image\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=\r\n]{200,}/gi, '[изображение]');
  t = t.replace(/([A-Za-z0-9+/]{2000,}={0,2})/g, '…[длинные данные вырезаны]…');
  const lim = cap || 60000;  // V-MEMFIX: было 20000 — длинные разборы обрезались на полуслове
  if (t.length > lim) t = t.slice(0, lim) + '\n…(сообщение обрезано)';
  return t;
}

/* V-IMGSHRINK: большие фото перед отправкой уменьшаем — запрос не должен весить мегабайты.
 * Сжимаем один раз, результат сохраняем в чат (db тоже перестаёт пухнуть). */
async function shrinkDataUrl(dataUrl, maxDim, quality) {
  if (typeof dataUrl !== 'string' || !/^data:image\//i.test(dataUrl)) return dataUrl;
  if (dataUrl.length < 500000) return dataUrl;
  try {
    const img = await new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i); i.onerror = rej; i.src = dataUrl;
    });
    const scale = Math.min(1, (maxDim || 1536) / Math.max(img.width || 1, img.height || 1));
    const w = Math.max(1, Math.round((img.width || 1) * scale));
    const h = Math.max(1, Math.round((img.height || 1) * scale));
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const ctx = cv.getContext('2d');
    ctx.drawImage(img, 0, 0, w, h);
    const out = cv.toDataURL('image/jpeg', quality || 0.9);
    return (out && out.length < dataUrl.length) ? out : dataUrl;
  } catch (e) { return dataUrl; }
}
async function optimizeChatImages(chat) {
  if (!chat) return;
  const win = chat.messages.slice(-(Math.max(4, Number(S().maxHistory) || 20) + 2));
  let changed = false;
  for (const msg of win) {
    for (const im of (msg.images || [])) {
      if (!im || typeof im.dataUrl !== 'string') continue;
      const small = await shrinkDataUrl(im.dataUrl, 1536, 0.9);
      if (small !== im.dataUrl) { im.dataUrl = small; changed = true; }
    }
  }
  if (changed) { try { saveDb(); } catch (e) {} }
}


/* ============ V-CTXENGINE: контекст проекта в духе Cursor/Chatbox/Cline ============
   Корень проекта, карта файлов (.gitignore), @-упоминания, файлы сессии,
   лёгкий keyword-recall вместо тяжёлых эмбеддингов (офлайн, без зависимостей). */
const CTX_MARKERS = ['.git', '.hg', '.svn', 'package.json', 'go.mod', 'pyproject.toml', 'Cargo.toml', 'composer.json', 'pom.xml', 'build.gradle', 'Gemfile', 'setup.py', 'requirements.txt', 'CMakeLists.txt', 'Makefile', '.rr-root'];
const CTX_IGNORE_DEFAULT = ['node_modules', '.git', '.hg', '.svn', '.venv', 'venv', '__pycache__', 'dist', 'build', 'out', 'target', '.next', '.nuxt', '.idea', '.vscode', '.DS_Store', 'coverage', '.turbo', '.parcel-cache'];
let ctxRootCache = { dir: '', at: 0, root: '' };
let ctxTreeCache = { root: '', at: 0, text: '', count: 0 };
function isAbsPathLike(p) {
  const s = String(p || '').trim();
  if (!s) return false;
  if (s[0] === '/' || s[0] === '\\') return true;
  return /^[A-Za-z]:/.test(s);
}
async function detectProjectRoot(startDir) {
  const dir0 = String(startDir || '').trim();
  if (!dir0) return '';
  const key = dir0.toLowerCase();
  if (ctxRootCache.dir === key && Date.now() - ctxRootCache.at < 60000) return ctxRootCache.root;
  let dir = dir0, root = '';
  for (let depth = 0; depth < 12 && dir; depth++) {
    let entries = null;
    try {
      const r = await withTimeout(rr.invoke('fs:list', { dir }), 8000, 'root scan timeout');
      if (r && r.ok) entries = r.entries || [];
    } catch (e) { entries = null; }
    if (entries) {
      const names = new Set(entries.map((e) => String(e.name || '').toLowerCase()));
      if (CTX_MARKERS.some((mm) => names.has(mm)) || entries.some((e) => !e.dir && /\.sln$/i.test(e.name || ''))) { root = dir; break; }
    }
    const parent = dir.replace(/[\\/]+$/, '').replace(/[\\/][^\\/]+$/, '');
    if (!parent || parent === dir) break;
    dir = parent;
  }
  if (!root) root = dir0;
  ctxRootCache = { dir: key, at: Date.now(), root };
  return root;
}
function parseGitignore(text) {
  const dirs = new Set(), pats = [];
  for (let line of String(text || '').split('\n')) {
    line = line.trim();
    if (!line || line.startsWith('#') || line.startsWith('!')) continue;
    line = line.replace(/^\//, '');
    if (!line) continue;
    if (line.endsWith('/')) { dirs.add(line.slice(0, -1)); continue; }
    pats.push(line);
  }
  return { dirs, pats };
}
function ignoreMatch(rel, ig) {
  const parts = String(rel || '').split('/');
  for (const d of CTX_IGNORE_DEFAULT) if (parts.includes(d)) return true;
  if (!ig) return false;
  for (const p of parts) if (ig.dirs.has(p)) return true;
  const base = parts[parts.length - 1] || '';
  for (const pat of ig.pats) {
    const rx = '^' + String(pat).split('*').map((s) => s.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*') + '$';
    try { if (new RegExp(rx).test(base) || new RegExp(rx).test(String(rel))) return true; } catch (e) {}
  }
  return false;
}
async function buildProjectTree(root) {
  root = String(root || '').trim();
  if (!root) return { text: '', count: 0 };
  if (ctxTreeCache.root === root && Date.now() - ctxTreeCache.at < 60000) return ctxTreeCache;
  let ig = null;
  try {
    const g = await withTimeout(rr.invoke('fs:readText', { filePath: root.replace(/[\\/]+$/, '') + '/.gitignore' }), 8000, 'gi timeout');
    if (g && g.ok && g.content) ig = parseGitignore(g.content);
  } catch (e) {}
  const out = [];
  let dirCount = 0, truncated = false;
  const queue = [{ dir: root, depth: 0 }];
  const rootPrefix = root.replace(/[\\/]+$/, '');
  while (queue.length && out.length < 500 && dirCount < 80) {
    const cur = queue.shift();
    if (cur.depth > 6) { truncated = true; continue; }
    let entries = null;
    try {
      const r = await withTimeout(rr.invoke('fs:list', { dir: cur.dir }), 8000, 'tree timeout');
      if (r && r.ok) entries = r.entries || [];
    } catch (e) { continue; }
    if (!entries) continue;
    dirCount++;
    for (const e of entries) {
      const full = String(e.path || (cur.dir + '/' + e.name));
      const rel = full.startsWith(rootPrefix) ? full.slice(rootPrefix.length).replace(/^[\\/]+/, '').replace(/\\/g, '/') : String(e.name);
      if (!rel) continue;
      if (ignoreMatch(rel, ig)) continue;
      if (e.dir) { queue.push({ dir: full, depth: cur.depth + 1 }); continue; }
      out.push(rel);
      if (out.length >= 500) { truncated = true; break; }
    }
  }
  const text = out.join('\n') + (truncated ? '\n…(truncated)' : '');
  ctxTreeCache = { root, at: Date.now(), text, count: out.length };
  return ctxTreeCache;
}
function sessionFileList(chat) {
  const out = [];
  const push = (p) => {
    const v = String(p || '').trim();
    if (v && v.length > 3 && !out.includes(v) && out.length < 24) out.push(v);
  };
  try {
    for (const m of (chat && chat.messages) || []) {
      if (!m) continue;
      if (m.role === 'tool') for (const p of extractFilePaths((m.label || '') + '\n' + String(m.content || '').slice(0, 2000))) push(p);
      for (const a of m.attachments || []) if (a && a.path) push(a.path);
      for (const x of m.mentions || []) if (x && x.path) push(x.path);
    }
  } catch (e) {}
  for (const p of turnFilePaths) push(p);
  return out;
}
async function recallRelevantChunks(query, root, tree) {
  const words = Array.from(new Set(String(query || '').toLowerCase().split(/[^a-zа-яё0-9_]+/i).filter((w) => w.length > 2))).slice(0, 12);
  if (!words.length || !root) return '';
  const files = String((tree && tree.text) || '').split('\n').filter((f) => f && /\.(js|ts|jsx|tsx|py|go|rs|java|php|rb|c|h|cpp|hpp|cs|json|md|txt|yml|yaml|toml|ini|env|html|css|vue)$/i.test(f)).slice(0, 30);
  const scored = [];
  for (const rel of files) {
    let content = '';
    try {
      const r = await withTimeout(rr.invoke('fs:readText', { filePath: String(root).replace(/[\\/]+$/, '') + '/' + rel }), 8000, 'recall timeout');
      if (!r || !r.ok || !r.content) continue;
      content = String(r.content).slice(0, 60000);
    } catch (e) { continue; }
    const low = content.toLowerCase();
    let score = 0;
    for (const w of words) if (low.includes(w)) score += w.length;
    if (score > 0) scored.push({ rel, score, content });
    if (scored.length >= 12) break;
  }
  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, 3);
  if (!top.length) return '';
  return top.map((x) => {
    const low = x.content.toLowerCase();
    let bi = -1;
    for (const w of words) { const ix = low.indexOf(w); if (ix >= 0 && (bi < 0 || ix < bi)) bi = ix; }
    const lines = x.content.split('\n');
    let ln = 0;
    if (bi >= 0) ln = x.content.slice(0, bi).split('\n').length - 1;
    const s = Math.max(0, ln - 6), e = Math.min(lines.length, ln + 7);
    return '--- ' + x.rel + ' (lines ' + (s + 1) + '-' + e + ') ---\n' + lines.slice(s, e).join('\n');
  }).join('\n\n').slice(0, 5000);
}
function parseMentions(text) {
  const out = [];
  try {
    for (const m of String(text || '').matchAll(/@([^\s@,;:'"()\[\]{}]+)/g)) {
      const v = String(m[1] || '').replace(/[.,;:!?]+$/, '');
      if (v && !out.includes(v)) out.push(v);
    }
  } catch (e) {}
  return out.slice(0, 8);
}
async function resolveMentions(text, root, wd) {
  const out = [];
  const base = String(root || wd || homeDirCache || '').trim();
  for (const ref of parseMentions(text)) {
    let abs = '';
    if (isAbsPathLike(ref)) abs = ref;
    else if (base) abs = base.replace(/[\\/]+$/, '') + '/' + String(ref).replace(/^\.\//, '');
    else abs = ref;
    const name = String(ref).split(/[\\/]/).pop() || ref;
    try {
      const r = await withTimeout(rr.invoke('fs:readText', { filePath: abs }), 12000, 'mention timeout');
      if (r && r.ok && typeof r.content === 'string') out.push({ path: abs, name, content: r.content.slice(0, 100000) });
      else out.push({ path: abs, name, error: (r && r.error) || 'mention unreadable' });
    } catch (e) {
      out.push({ path: abs, name, error: String((e && e.message) || e) });
    }
  }
  return out;
}
async function buildProjectContext(chat, userText) {
  const wd = String(S().workDir || homeDirCache || '').trim();
  if (!wd) return '';
  let root = wd;
  try { root = await detectProjectRoot(wd); } catch (e) { root = wd; }
  let tree = { text: '', count: 0 };
  try { tree = await buildProjectTree(root || wd); } catch (e) {}
  let sess = [];
  try { sess = sessionFileList(chat); } catch (e) {}
  let recall = '';
  if (String(userText || '').trim().length >= 12 && tree.count > 0) {
    try { recall = await recallRelevantChunks(userText, root || wd, tree); } catch (e) {}
  }
  let out = '\n=== PROJECT CONTEXT (auto) ===\nWorking directory: ' + wd + '\nProject root: ' + (root || wd) + '\nAll relative paths resolve from the project root. Do not guess file names — use the tree below and `list` to verify.\n';
  if (tree.count) out += '\n--- PROJECT TREE (' + tree.count + ' files) ---\n' + String(tree.text).slice(0, 6000) + '\n';
  try { const pm = S().projMap; if (pm && pm.text && String(pm.dir || '').replace(/[\\/]+$/, '') === String(root || wd || '').replace(/[\\/]+$/, '')) out += '\n--- CATALOG MAP (auto) — built when the folder was chosen; trust it for module layout & entrypoints, refresh with rr-file list only if files changed recently ---\n' + pm.text + '\n'; } catch (e) {}
  if (sess.length) out += '\n--- SESSION FILES (already seen) ---\n' + sess.join('\n') + '\n';
  if (recall) out += '\n--- RECALLED CONTEXT (keyword match) ---\n' + recall + '\n';
  out += '=== END PROJECT CONTEXT ===\n';
  return out;
}

const NL = '\n'; // V-NLFIX 1.2.88: undefined NL ломал ОТПРАВКУ при включённом tddMode («NL is not defined»)
function buildApiMessages(chat) {
  const msgs = [];
  const sshCtx = sshSession && sshSession.cfg ? `\nActive SSH session: ${(sshSession.cfg.username || sshSession.cfg.user || 'user')}@${sshSession.cfg.host}:${sshSession.cfg.port || 22}` : '';
  const projectIndex = window.__RR_PROJECT_INDEX__;
  const projectPrompt = projectIndex ? '\n=== КАРТА ПРОЕКТА ===\nТипы: ' + (projectIndex.projectTypes || []).join(', ') + '\nФайлов: ' + (projectIndex.files || []).length + '; каталогов: ' + (projectIndex.directories || []).length + '\nТочки входа: ' + (projectIndex.entrypoints || []).slice(0, 20).join(', ') + '\nНе отправляй весь проект сразу; читай релевантные файлы порциями.\n=== КОНЕЦ КАРТЫ ===\n' : '';
  const durableContext = projectIndex ? projectPrompt : '';
  const tddBlock = S().tddMode ? '\n=== TDD STRICT MODE (user enabled) ===\n'
    + '- Перед написанием продакшен-кода СНАЧАЛА напиши unit-тесты задачи (тест-фреймворк проекта; если нет — создай минимальный).'+NL+''
    + '- Запусти тесты (rr-shell) — они ДОЛЖНЫ ПАСТЬ (реализации ещё нет). Покажи результат.'+NL+''
    + '- ТОЛЬКО после падающих тестов пиши реализацию. Запускай тесты после каждого изменения, итерируй, пока не станут зелёными.'+NL+''
    + '- Не редактируй основной код, пока тесты не написаны и не запущены (не зелёные/красные).'+NL+'' : '';
  // 1.2.85 V-CACHE: стабильные блоки (tools, system prompt, TDD) — ПЕРВЫМИ, чтобы префикс попал в кэш;
  // переменные части (state/durable/ssh/proj) — в конце
  const sys = TOOL_PROTOCOL.replace('FS_ACCESS_RULES', fsAccessRules()) + (S().systemPrompt ? '\n' + S().systemPrompt : '') + tddBlock + taskStatePrompt() + durableContext + (S().workDir ? `\nWorking directory: ${S().workDir}` : '') + sshCtx + (chat.__projCtx || '') + skillsPrompt();
  msgs.push({ role: 'system', content: sys });
  const limit = Math.max(4, Number(S().maxHistory) || 20);
  // V-CHATWEIGHT: сначала ограничение по числу сообщений, затем — по общему весу контекста
  const hist = trimHistoryByWeight(chat.messages.slice(-limit), sys);

  for (const m of hist) {
    if (m.role === 'tool') {
      msgs.push({ role: 'user', content: sanitizeHistoryText(`[TOOL RESULT] ${m.label}\n${m.content}`, 30000) });  // V-MEMFIX: было 12000
    } else if (m.role === 'user') {
      let text = maybeShieldText(sanitizeHistoryText(m.content || ''), 'message').text;
      for (const a of m.attachments || []) {
        if (a.kind === 'text') {
          const src = typeof a.content === 'string' ? a.content : '';
          const shrunk = maybeShieldText(src, a.path || a.name);
          const note = src ? shrunk.text : '(пустой текстовый файл)';
          text += `\n\n[ATTACHED_TEXT_FILE name="${a.name}" path="${a.path || a.name}"]\n${note}\n[/ATTACHED_TEXT_FILE]`;
        } else text += `\n[Прикреплён файл: ${a.name}]`;
      }
      for (const x of m.mentions || []) {
        if (x && !x.error && typeof x.content === 'string') text += `\n\n[MENTIONED_FILE name="${x.name}" path="${x.path}"]\n${maybeShieldText(x.content.slice(0, 60000), x.path).text}\n[/MENTIONED_FILE]`;
        else if (x) text += `\n[Упоминание @${x.name}: не прочитано — ${x.error || 'нет доступа'}]`;
      }
      if ((m.images || []).length && S().sendImages) {
        const parts = [{ type: 'text', text: text || 'Проанализируй изображение.' }];
        for (const img of m.images) parts.push({ type: 'image_url', image_url: { url: img.dataUrl } });
        msgs.push({ role: 'user', content: parts });
      } else {
        if ((m.images || []).length) text += `\n(прикреплено изображений: ${m.images.length})`;
        msgs.push({ role: 'user', content: text });
      }
    } else if (m.role === 'assistant' && m.content && !m.error) {
      msgs.push({ role: 'assistant', content: sanitizeHistoryText(m.content) });
    }
  }
  return msgs;
}

async function sendMessage() {
  const _cid = (currentChat() || {}).id;
  if (streaming && streaming.chatId === _cid) return;
  const input = $('#composer-input');
  const text = input.value.trim();
  if (!text && !pendingAttachments.length) return;

  if (!S().apiKey) { openSettings(); toast(t('needKeyFirst'), 'warn'); return; }
  if (!currentChat()) newChat(true);

  const chat = currentChat();
  if (!activeTaskState && taskProjectPath()) {
    await saveActiveTaskPatch({ goal: text.slice(0, 4000), projectPath: taskProjectPath(), phase: 'analysis', nextStep: 'Понять задачу и построить план действий' });
  }
  const m = { role: 'user', content: text, ts: Date.now(), attachments: [], images: [] };
  for (const a of pendingAttachments) {
    if (a.kind === 'image') m.images.push({ name: a.name, dataUrl: a.content });
    else m.attachments.push({ name: a.name, path: a.path, kind: a.kind, content: a.content });
  }
  chat.messages.push(m);
  // V-CTXENGINE: @-упоминания файлов — читаем сразу, чипы видно в сообщении
  try {
    const wd0 = String(S().workDir || homeDirCache || '').trim();
    let root0 = wd0;
    try { root0 = wd0 ? await detectProjectRoot(wd0) : ''; } catch (e) {}
    m.mentions = await resolveMentions(text, root0, wd0);
    if (m.mentions && m.mentions.length) {
      const okN = m.mentions.filter((x) => !x.error).length;
      toast('@: ' + okN + '/' + m.mentions.length + ' · ' + m.mentions.map((x) => x.name).join(', '));
    }
  } catch (e) { console.warn('[RR] mentions', e); }
  // V-IMGSHRINK: тяжёлые фото сжимаем ДО отправки (иначе запрос весит мегабайты)
  try { await optimizeChatImages(chat); } catch (e) { console.warn('[RR] img shrink', e); }
  if (!chat.title) {
    chat.title = (text || (m.attachments[0] && m.attachments[0].name) || '🖼').slice(0, 48);
    updateChatTitle();
  }
  chat.updatedAt = Date.now();
  clearAttachments();
  input.value = ''; autosize(); saveDb(); renderChatList(); renderMessages();

  try { chat.__projCtx = await buildProjectContext(chat, text); } catch (e) { chat.__projCtx = ''; }
  await runAssistant(chat);
  // V-CTX: авто-сжатие после ответа, если включено
  if (autoCompress) compressCurrentChat(true);
}

/* Один раунд стриминга ответа модели; возвращает {content, error, aborted} */
function isTransientModelError(err) {
  const msg = String(err && (err.error || err.message || err.content) || err || '').toLowerCase();
  // 1.2.78: расширено — IPC/Electron/основной процесс/сеть (обёртка ошибок invoke тоже считается обрывом)
  return /timeout|timed out|network|socket|econn|reset|closed|broken pipe|fetch failed|temporary|unavailable|overloaded|503|502|429|stream ended|unexpected end|connection|ipc|invoke|channel|renderer|window|crashed|main process|sidecar|EPIPE|EAI_AGAIN|ETIMEDOUT|ERR_IN|ERR_UNEXPECTED|UND_ERR|failed to fetch|websocket|premature|hang up|aborted|disconnected|terminated|refused/i.test(msg);
}
// V-SAMECOEF: подбираем замену с ТЕМ ЖЕ коэффициентом (требование: молчащая модель →
// переключение на модель той же цены и продолжение работы).
function sameCoefFallback(model) {
  try {
    const cur = getModelMeta(model);
    if (!cur || cur.isImageGen) return null;
    const coef = cur.coef != null ? cur.coef : 1;
    // models — массив строк-id; если каталог ещё не загружен, берём известные из MODEL_COEF
    let ids = (models || []).filter((x) => typeof x === 'string');
    if (!ids.length) ids = Object.keys(MODEL_COEF || {});
    const cands = ids.filter((id) => id !== model)
      .map((id) => getModelMeta(id))
      .filter((m) => m && !m.isImageGen && m.modality === 'text'
        && Math.abs((m.coef != null ? m.coef : 1) - coef) < 0.001);
    if (!cands.length) return null;
    const pref = cands.find((m) => /luna|sonnet|astra|flash|nano/i.test(m.id)) || cands[0];
    return pref.id;
  } catch (e) { return null; }
}

async function streamOnce(chat, a, model) {
  if (chat && chat.id === currentChatId) setStreamUi(true);
  try { renderChatList(); } catch (e) {}
  let finalResult = null;
  let retryBase = '';          // уже выданная часть ответа — её дотягиваем, а не теряем
  const MAX_ATTEMPTS = 5;      // максимум 5 попыток довести ответ до полного
  let attempt = 1;
  for (; attempt <= MAX_ATTEMPTS; attempt++) {
    const reqId = 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    streaming = { reqId, chatId: chat.id, startedAt: Date.now() };
    streamsByChat.set(chat.id, streaming);
    a.streaming = true;
    a.error = false;
    a.reasoning = '';
    a.content = attempt > 1 ? retryBase : '';
    if (attempt > 1) { saveDb(); renderMessages(); }

    let renderTimer = null;
    function throttledRender() {
      if (renderTimer) return;
      renderTimer = requestAnimationFrame(() => {
        renderTimer = null;
        if (currentChat() !== chat) return;
        const idx = chat.messages.indexOf(a);
        if (idx < 0) return;
        const box = $('#messages');
        const existing = box.children[box.children.length - 1];
        const fresh = renderMessage(a);
        if (existing && existing.dataset.msgIndex === String(idx)) box.replaceChild(fresh, existing);
        else box.appendChild(fresh);
        enhanceCode(fresh, { light: true });
        scrollDown(false);
      });
    }

    /* V-NOSTATUS: пользователь попросил убрать индикатор «⏳ жду ответа модели».
       В обычном режиме статус пуст; показывается только счётчик переподключений. */
    let _lpTimer = null;
    /* V-NOSTATUS2: убраны и «переподключение», и «жду ответа» снизу. */
    const lpLabel = () => '';
    const lpPaint = () => { try { const el = $('#stream-status'); if (el) el.textContent = lpLabel(); } catch (e) {} };
    lpPaint();
    const offDelta = rr.on('chat:delta', (d) => { if (d.reqId !== reqId) return; a.content += d.text; throttledRender(); });
    const offReason = rr.on('chat:reasoning', (d) => { if (d.reqId !== reqId) return; a.reasoning = String(a.reasoning || '') + String((d && d.text) || ''); throttledRender(); });
    let result;
    try {
      lpPaint();
      bumpRequestCount(chat);
      // V-WS-UI: включённый веб-поиск — суффикс -web (шлюз исполняет поиск серверно; работает и на старом шелле)
      const upModel = (S().webSearch !== false && !/-web$/i.test(model || '')) ? (model + '-web') : model;
      result = await rr.invoke('gw:chat', {
        reqId, baseUrl: S().baseUrl, apiKey: S().apiKey, model: upModel,
        messages: (attempt > 1 && retryBase) ? buildContinuationMessages(chat, retryBase) : buildApiMessages(chat),
        temperature: Number(S().temperature) > 0 ? Number(S().temperature) : undefined,
        reasoning_effort: (() => { if (!modelSupportsReasoning(model)) return undefined; const c0 = reasoningChoice(); if (c0 === 'off') return undefined; if (c0 !== 'default') return currentReasoningEffort(); if (/claude|opus|sonnet|haiku/i.test(model || '')) return 'medium'; if (/^(o1|o3|o4|gpt-5|gpt-6|codex)/i.test(model || '')) return 'high'; return undefined; })(),
        // V-MEMFIX: лимит длины ответа (старый шелл его игнорирует — подхватит после обновления оболочки)
        max_tokens: Number(S().maxTokens) > 0 ? Math.floor(Number(S().maxTokens)) : undefined
      });
    } catch (e) {
      result = { error: e && e.message ? e.message : String(e || 'Chat request failed') };
    } finally {
      offDelta();
      offReason();
      if (_lpTimer) { try { clearInterval(_lpTimer); } catch (e) {} _lpTimer = null; }
    }

    // текст этого раунда: либо полный result.content, либо накопленные дельты
    const streamed = String(a.content || '').slice(retryBase.length);
    const got = (result && typeof result.content === 'string' && result.content.length > streamed.length) ? result.content : streamed;
    a.content = retryBase + got;
    finalResult = result || {};
    // V-WSTOOL: шлюз/старая версия вернула tool_calls без текста — не крутим 5 «переподключений»,
    // сразу помечаем ошибку, чтобы V-AUTOSWITCH переключил модель и чат не завис.
    if (result && !result.error && result.finish_reason === 'tool_calls' && !(a.content || '').trim()) {
      result.error = 'web-search loop ended with tool_calls — answer unavailable';
      finalResult = result;
      break;
    }
    if (!(result && result.error) && !(a.content || '').trim() && !(result && result.aborted) && attempt < MAX_ATTEMPTS) {
      // пустой ответ без ошибки — тоже считаем обрывом и пробуем ещё раз
      await sleep(Math.min(8000, 1000 * Math.pow(2, Math.min(attempt - 1, 3))));
      continue;
    }
    // V-MEMFIX2: модель упёрлась в лимит длины ответа (finish_reason=length) — дотягиваем автоматически
    if (result && result.finish_reason === 'length' && !(result && result.aborted) && attempt < MAX_ATTEMPTS) {
      console.log('[RR] ответ обрезан по длине, дотягиваем (попытка ' + (attempt + 1) + ')');
      retryBase = a.content;
      await sleep(500);
      continue;
    }
    if (!(result && result.error) || (result && result.aborted)) break;
    if (!isTransientModelError(result)) break;
    if (attempt >= MAX_ATTEMPTS) break;   // 5 попыток исчерпаны — отдаём то, что успели получить
    retryBase = a.content;                // обрыв: дотягиваем ответ с места остановки
    await sleep(Math.min(8000, 1000 * Math.pow(2, Math.min(attempt - 1, 3))));
  }

  // V-AUTOSWITCH: обрыв/зависание без контента — один раз переходим на живую модель и продолжаем
  if (finalResult && finalResult.error && isTransientModelError(finalResult) && !a.content && !finalResult.aborted && !a.__switchedOnce) {
    a.__switchedOnce = true;
    // V-SAMECOEF: если модель молчит — переключаем на модель с ТЕМ ЖЕ коэффициентом
    const fb = sameCoefFallback(model) || (/luna|terra|sol/.test(model) ? 'claude-sonnet-4-6' : 'gpt-5.6-luna');
    try { toast('⇄ ' + t('modelSwitched') + ': ' + fb, 'warn'); } catch (e) {}
    a.modelName = fb;
    finalResult = await streamOnce(chat, a, fb);
  }
  const result = finalResult || {};
  a.streaming = false;
  if (result && result.error) {
    if (a.content) a.content += '\n\n> ⚠ ' + result.error;
    else { a.error = true; a.content = String(result.error); }
  } else if (!a.content && !a.reasoning && !(result && result.aborted)) {
    a.error = true; a.content = t('emptyReply');
  }
  if (result && result.aborted) a.content += '\n\n' + t('stoppedNote');
  try { await maybeAutoApply(chat, a); } catch (e) {}
  // V-RUNIND: запоминаем итог раунда для индикатора
  runOutcome = (result && result.aborted) ? 'stop' : (result && result.error) ? 'err' : 'done';
  chat.updatedAt = Date.now();
  // V-PARALLEL: гасим только СВОЙ стрим — параллельный чат не должен пострадать
  if (streaming && streaming.chatId === chat.id) streaming = null;
  streamsByChat.delete(chat.id);
  saveDb(); renderMessages(); renderChatList();
  return result || {};
}

function isWriteLikeToolBlock(b) {
  return !!(b && ((b.type === 'rr-file' && /^(write|append|mkdir|delete)$/i.test(String(b.args && b.args.op || ''))) || (b.type === 'rr-rfile' && /^(write)$/i.test(String(b.args && b.args.op || '')))));
}
function summarizeToolOutputText(text, maxLines, maxChars) {
  const lines = normalizeNewlines(String(text || '')).split('\n').map((x) => x.trim()).filter(Boolean).slice(0, maxLines || 3);
  const joined = lines.join('\n');
  return joined.length > (maxChars || 420) ? joined.slice(0, maxChars || 420) + '…' : joined;
}
function clampToolOutput(text, b) {
  const raw = normalizeNewlines(stripAnsi(String(text || ''))).trim();
  if (!raw) return '';
  // V-SEEK: середина режется, начало+конец остаются — модель видит и контекст, и финал
  const maxChars = b && b.type === 'rr-ssh' ? 6000 : 9000;
  const maxLines = b && b.type === 'rr-ssh' ? 140 : 220;
  const lines = raw.split('\n');
  let out = raw;
  if (lines.length > maxLines) {
    const headN = Math.ceil(maxLines * 0.6); const tailN = maxLines - headN;
    out = lines.slice(0, headN).join('\n') + '\n…[пропущено ' + (lines.length - maxLines) + ' строк — уточни вывод фильтрами (grep|head -60|-m 5|--include)]\n' + lines.slice(-tailN).join('\n');
  }
  if (out.length > maxChars) {
    const half = Math.floor(maxChars * 0.62);
    out = out.slice(0, half) + '\n…[пропущено ' + (out.length - maxChars) + ' симв. — сужай запрос фильтрами]\n' + out.slice(-(maxChars - half));
  }
  return out;
}
function shouldAutoFinishAfterTools(blocks, rawAssistantText) {
  if (!Array.isArray(blocks) || !blocks.length) return false;
  if (blocks.every(isWriteLikeToolBlock)) return true;
  return blocks.length === 1 && blocks[0].type === 'rr-balance' && !stripAssistantDisplayText(rawAssistantText || '').trim();
}
function summarizeToolBlocks(blocks, toolResults) {
  const first = blocks && blocks[0] ? blocks[0] : null;
  if (!first) return '';
  const failed = (toolResults || []).find((x) => !x.ok);
  if (failed) return 'Не удалось выполнить действие: ' + String(failed.content || 'ошибка');
  if ((blocks || []).every(isWriteLikeToolBlock)) {
    if ((blocks || []).length === 1) {
      const kind = first.type === 'rr-rfile' ? 'удалённый файл' : 'файл';
      const op = String(first.args && first.args.op || '').toLowerCase();
      if (op === 'mkdir') return 'Готово: папка создана — ' + (first.args.path || '');
      if (op === 'delete') return 'Готово: файл удалён — ' + (first.args.path || '');
      if (op === 'append') return 'Готово: дописал в ' + kind + ' — ' + (first.args.path || '');
      return 'Готово: записал ' + kind + ' — ' + (first.args.path || '');
    }
    return 'Готово: выполнил операции с файлами.';
  }
  if ((blocks || []).length === 1) {
    const res = toolResults && toolResults[0] ? String(toolResults[0].content || '') : '';
    if (first.type === 'rr-ssh') {
      const brief = summarizeToolOutputText(res, 3, 420);
      return brief ? ('Готово:\n' + brief) : 'Готово: SSH-команда выполнена.';
    }
    if (first.type === 'rr-balance') return 'Готово: баланс обновлён.';
    const op = String(first.args && first.args.op || '').toLowerCase();
    if (['read', 'open', 'search', 'list'].includes(op)) return 'Готово. Результат выше.';
  }
  return '';
}

/* Агентный цикл: ответ модели -> выполняем rr-блоки -> продолжаем */
async function runAssistant(chat) {
  let model = $('#model-select').value || S().model;
  try {
    // V-MEMFIX: было жёстко 4 раунда — разбор папки обрывался на середине
    const MAX_ROUNDS = Math.min(60, Math.max(1, Number(S().maxRounds) || 25));
    let round = 0;
    let autoCont = 0;   // V-AUTOCONT: авто-продолжения после «плана без действий»
    let autoResume = 0; // 1.2.76: авто-возобновление после обрыва соединения (без «продолжи»)
    turnFilePaths = [];
    for (; round < MAX_ROUNDS; round++) {
      await saveActiveTaskPatch({ phase: round === 0 ? 'analysis' : 'execution', nextStep: 'Раунд ' + (round + 1) + ': выполнить инструменты и проверить результат' }).catch(() => {});
      const a = { role: 'assistant', content: '', reasoning: '', modelName: model, ts: Date.now(), streaming: true };
      chat.messages.push(a);
      renderMessages();
      const _sentWeight = chatWeight(chat);   // V-TOKENSTATS: сколько токенов уходит в модель
      const result = await streamOnce(chat, a, model);
      recordTokenUsage(chat, a.modelName || model, result, _sentWeight, a);
      if (result.aborted) break;
      if (result.error) {
        // 1.2.76: AUTO-RESUME — обрыв (модель/SSH/сеть) больше не требует от пользователя «продолжи»:
        // терминал сам поднимает прошлое действие — повторяет оборванный шаг и доводит до конца (до 4 раз).
        const AUTO_RESUME_MAX = 4;
        const errTxt = String(result.error || '');
        // 1.2.78: + IPC/Electron/основной процесс — «рвёт выполнение задачи» считаем обрывом и возобновляем
        const transient = /timeout|timed out|econn|socket|reset by peer|connection (closed|refused|lost|reset)|broken pipe|fetch failed|unavailable|overloaded|503|502|429|stream ended|unexpected end|network|temporary|ssh|kex_exchange|send disconnect|terminated|ipc|invoke|channel|renderer|window closed|crashed|main process|sidecar|EPIPE|EAI_AGAIN|ETIMEDOUT|ERR_IN|UND_ERR|failed to fetch|websocket|premature close|hang up|refused|disconnected/i.test(errTxt);
        if (transient && autoResume < AUTO_RESUME_MAX) {
          autoResume++;
          const waitMs = 2000 * Math.pow(2, Math.min(autoResume - 1, 3));
          try { $('#stream-status').textContent = '⟳ соединение оборвалось — авто-возобновление ' + autoResume + '/' + AUTO_RESUME_MAX + '…'; } catch (e) {}
          a.content = (a.content ? a.content + '\n\n' : '') + t('resumingNote');
          a.error = false;
          saveDb(); renderMessages();
          await sleep(waitMs);
          chat.messages.push({ role: 'user', content: '⟳ ' + (LANG === 'en'
            ? 'Connection dropped (' + errTxt.slice(0, 200) + '). Resume from the last COMPLETED step: re-run only the failed command and continue the task to the end. Do NOT repeat already-finished actions.'
            : 'Соединение оборвалось (' + errTxt.slice(0, 200) + '). Продолжи с последнего ВЫПОЛНЕННОГО шага: повтори только оборванную команду и доведи задачу до конца. Не повторяй уже завершённые действия.'), ts: Date.now(), autoCont: true });
          saveDb(); renderMessages();
          continue;
        }
        break;
      }

      const blocks = extractToolBlocks(a.content);
      // V-OPENFENCE (1.2.91): обрыв посреди ```rr-блока (таймаут/网络) — модель ждёт, что её
      // «услышат»; раньше незакрытый фенс считался текстом и чат вставал («не работает дальше»).
      const openFence = (() => {
        try {
          const src = String(a.content || '');
          const opens = Array.from(src.matchAll(/```rr-[a-z]+[ \t]*\n/g));
          if (!opens.length) return false;
          const last = opens[opens.length - 1];
          return src.slice(last.index + last[0].length).indexOf('```') === -1;
        } catch (e) { return false; }
      })();
      if (!blocks.length) {
        // V-AUTOCONT: модель описала план («сделаю… затем…») и остановилась — чат не должен
        // ждать «продолжи»: автоматически просим выполнить следующий шаг СЕЙЧАС (до 3 раз).
        const txt = stripAssistantDisplayText(a.content || '');
        const looksPlan = /(?:затем|сначала|сделаю|сейчас проверю|приступаю|начинаю|следующим шагом|следующий шаг|залью|запишу|выполню|далее|по шагам)\b/i.test(txt)
          && !/\?\s*$/.test(txt.trim()) && txt.length < 2500;
        // 1.2.78: ответ ОБРОВАН ПОСРЕДИ ЗАДАЧИ — модель остановилась с finish_reason=stop,
        // блоков rr-* нет, а текст явно «не закончен»: хвост = маркер списка без содержания
        // («1.», «1)», «-»), двоеточие/тире/многоточие или обрезка по длине. Чат сам продолжает.
        const looksCutOff = openFence || (txt.length > 0 && txt.length < 3000
          && !/\?\s*$/.test(txt.trim())
          && (/(^|\n)\s*\d{1,2}\s*[.):]\s*$/m.test(txt)
            || /(^|\n)\s*[-*•]\s*$/m.test(txt)
            || /[:—–…]\s*$/.test(txt)
            || (result && result.finish_reason === 'length')));
        if ((looksPlan || looksCutOff) && autoCont < (openFence ? 5 : 3) && !(result && result.aborted)) {
          autoCont++;
          chat.messages.push({ role: 'user', content: '⟳ ' + (openFence
            ? (LANG === 'en'
              ? 'Your last rr-* block was CUT OFF (unclosed code fence). Re-send that block COMPLETE and closed, then continue the task.'
              : 'Твой последний блок rr-* ОБРЯСЯ (незакрытый ```). Пришли его ЗАНОВО ПОЛНОСТЬЮ (весь JSON и закрывающий ```) и продолжай задачу. Не извиняйся, не пересказывай — просто допиши блок.')
            : (LANG === 'en'
              ? 'Continue NOW: perform the next step immediately with rr-* tool blocks. Do not describe the plan — execute it.'
              : 'Продолжай СЕЙЧАС: выполни следующий шаг сразу блоками rr-*. Не описывай план — выполняй.')), ts: Date.now(), autoCont: true });
          saveDb(); renderMessages();
          continue;
        }
        break;
      }
      autoCont = 0;

      const toolResults = [];
      for (const b of blocks) {
        const isSsh = b.type === 'rr-ssh';
        const isRemoteFile = b.type === 'rr-rfile';
        const isBalance = b.type === 'rr-balance';
        const isShell = b.type === 'rr-shell';
        const label = isSsh
          ? '🖥 SSH: ' + (b.args.cmd || '') + (b.args.profile ? '  [@' + b.args.profile + ']' : (b.args.host ? '  [@' + b.args.host + ']' : ''))
          : isShell
            ? '⌨️ команда: ' + (b.args.cmd || b.args.command || '')
            : isRemoteFile
            ? '🗂 remote ' + (b.args.op || '') + ' ' + (b.args.path || '')
            : isBalance
              ? '💰 balance'
              : '📁 ' + (b.args.op || '') + ' ' + (b.args.path || '');
        try { $('#stream-status').textContent = t('generating') + ' · ' + (round + 1) + '/' + MAX_ROUNDS; } catch (e) {}
        chat.messages.push({ role: 'tool', label, content: '…', ok: true, ts: Date.now(), collectFiles: true });
        renderMessages();
        const toolMsg = chat.messages[chat.messages.length - 1];
        let res;
        try {
          res = await executeToolBlock(b);
        } catch (e) {
          res = { ok: false, output: (e && e.message) ? e.message : String(e || 'Tool failed') };
        }
        toolMsg.content = clampToolOutput(res.output || '', b);
        // 1.2.76: SSH оборвался — подсказка модели повторить команду (подключение восстановится само)
        if ((b.type === 'rr-ssh' || b.type === 'rr-rfile') && /connection reset|connection closed|timed out|broken pipe|network is unreachable|kex_exchange_identification|send disconnect|connection refused|operation timed out|read: connection/i.test(String(res.output || ''))) {
          toolMsg.content += (toolMsg.content ? '\n\n' : '') + (LANG === 'en'
            ? '[Connection dropped. Re-run the same command in a new rr-ssh block — SSH reconnects automatically.]'
            : '[Соединение оборвалось. Повтори ту же команду новым блоком rr-ssh — SSH переподключится автоматически.]');
        }
        toolMsg.ok = res.ok;
        toolMsg.ts = Date.now();
        // V-FILEONCE2: собираем пути один раз здесь (не на каждом рендере) и гасим карточку внутри блока
        collectTurnFilePaths(extractFilePaths(String(toolMsg.content || '') + '\n' + label));
        toolMsg.collectFiles = false; toolMsg.noCards = true;
        await saveActiveTaskPatch({
          phase: res.ok ? 'execution' : 'correction',
          completed: res.ok ? [label] : [],
          errors: res.ok ? [] : [String(res.output || 'Инструмент завершился с ошибкой').slice(0, 1000)],
          nextStep: res.ok ? 'Проверить результат действия: ' + label : 'Исправить ошибку: ' + label
        }).catch(() => {});
        toolResults.push(toolMsg);
        saveDb(); renderMessages();
      }
      const autoSummary = shouldAutoFinishAfterTools(blocks, a.content) ? summarizeToolBlocks(blocks, toolResults) : '';
      if (autoSummary) {
        chat.messages.push({ role: 'assistant', content: autoSummary, reasoning: '', modelName: model, ts: Date.now(), streaming: false, fileActions: takeTurnFilePaths() });
        saveDb(); renderMessages();
        break;
      }
      // цикл продолжается: новый assistant-ответ получит результаты
    }
    attachLeftoverFileActions(chat);
    if (round >= MAX_ROUNDS) {
      await saveActiveTaskPatch({ phase: 'paused', nextStep: 'Продолжить с раунда ' + (MAX_ROUNDS + 1) + ': проверить незавершённые действия' }).catch(() => {});
      // V-MEMFIX: раунды исчерпаны, а инструменты ещё вызывались — сохраняем следующий шаг
      chat.messages.push({ role: 'assistant', content: '⏸ ' + t('roundsExhausted').replace('{n}', String(MAX_ROUNDS)) + '\nСледующий шаг сохранён локально: продолжите запросом «продолжи».', reasoning: '', modelName: model, ts: Date.now(), streaming: false });
      saveDb(); renderMessages();
    }
  } finally {
    // V-PARALLEL: не закрываем общий AI-SSH и не гасим индикатор, если параллельно
    // работает другой чат — его инструменты должны дожить до конца.
    const othersRunning = Array.from(streamsByChat.keys()).some((cid) => cid !== chat.id);
    if (!othersRunning) { try { await closeAiSshSession(); } catch (e) {} }
    if (!othersRunning && !(currentChatId && streamsByChat.has(currentChatId))) setStreamUi(false);
    updateBalance();
  }
}

function stopStream() {
  const _st = (currentChatId && streamsByChat.get(currentChatId)) || (streaming && streaming.chatId === currentChatId ? streaming : null);
  if (!_st) return; // V-RUNCHAT: останов только текущего чата — чужие стримы не рвём
  rr.invoke('gw:stop', { reqId: _st.reqId }).catch(console.error);
}

/* V-RUNIND: индикатор «работает / остановился / готово» рядом с кнопкой отправки */
let runClock = null, runStartTs = 0, runOutcome = 'done';
function fmtRunElapsed(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return s < 60 ? s + 'с' : Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}
function setRunIndicator(state, label) {
  const el = $('#run-ind');
  if (!el) return;
  el.classList.remove('work', 'err', 'done', 'stop', 'idle');
  el.classList.add(state || 'idle');
  const txt = el.querySelector('.ri-txt');
  if (txt) txt.textContent = label == null ? '' : label;
  el.title = label || '';
}
function startRunClock(startAt) {
  runStartTs = startAt || Date.now();
  stopRunClock();
  const tick = () => {
    const el = $('#run-ind');
    if (!el) return;
    const txt = el.querySelector('.ri-txt');
    if (txt) txt.textContent = t('generating') + ' · ' + fmtRunElapsed(Date.now() - runStartTs);
  };
  tick();
  runClock = setInterval(tick, 1000);
}
function stopRunClock() { if (runClock) { clearInterval(runClock); runClock = null; } }

function updateContChip() {
  // V-CONTCHIP (1.2.92): если последний ответ ассистента оборван (незакрытый ``` или
  // висячий { ) — над полем ввода появляется кнопка «Продолжить с места обрыва».
  try {
    const wrap = $('#composer-wrap');
    if (!wrap) return;
    let el = $('#cont-chip');
    const chat = currentChat();
    const last = chat && chat.messages ? chat.messages[chat.messages.length - 1] : null;
    let show = false;
    if (last && last.role === 'assistant' && !last.streaming && !chatIsStreaming(currentChatId)) {
      const txt = String(last.content || '');
      const ticks = (txt.match(/```/g) || []).length;
      show = (ticks % 2 === 1) || /[,{[]\s*$|\|\s*[A-Za-zА-Яа-яЁё_]{0,30}$/.test(txt.trim().slice(-40)) || /(^|\n)\s*\d{1,2}\s*[.):]\s*$/.test(txt) || /\(пусто\)\s*$|Напиши «продолжи»|не смогла выдать финальный текст/.test(txt);
    }
    if (show) {
      if (!el) {
        el = document.createElement('button');
        el.id = 'cont-chip';
        el.className = 'btn-ghost sm';
        el.style.cssText = 'position:absolute;top:-30px;right:12px;z-index:5;padding:4px 10px;font-size:12px;border-radius:8px;background:#2a2340;border:1px solid #6c5ce7;color:#d9d2ff;cursor:pointer';
        el.textContent = '⟳ Продолжить с места обрыва';
        el.onclick = () => { const ta = $('#composer-input'); if (ta) ta.value = 'Продолжи РОВНО с места обрыва (символ в символ), без извинений и повторов; незакрытый rr-блок пришли заново целиком и доведи задачу до конца.'; sendMessage(); };
        wrap.appendChild(el);
      }
      el.style.display = '';
    } else if (el) el.style.display = 'none';
  } catch (eC) {}
}
function chatIsStreaming(id) { return !!(id && (streamsByChat.has(id) || (streaming && streaming.chatId === id))); }
function refreshComposerForChat() {
  const on = chatIsStreaming(currentChatId);
  const send = $('#btn-send');
  if (send) { send.classList.toggle('stop', on); send.textContent = on ? '⏹' : '➤'; send.title = on ? t('stopGen') : t('send'); }
  if (!on) { try { $('#stream-status').textContent = ''; } catch (e) {} }
}
function setStreamUi(on) {
  const send = $('#btn-send');
  send.classList.toggle('stop', on);
  send.textContent = on ? '⏹' : '➤';
  send.title = on ? t('stopGen') : t('send');
  $('#stream-status').textContent = on ? t('generating') : '';
  if (on) { setRunIndicator('work'); startRunClock(); }
  else {
    stopRunClock();
    const map = { done: ['done', t('runDone')], err: ['err', t('runError')], stop: ['stop', t('runStopped')] };
    const m = map[runOutcome] || map.done;
    setRunIndicator(m[0], m[1]);
  }
  if (on) $('#composer-input').focus();
}

async function saveMessageToFile(m) {
  // V-PNGSAVE (1.2.93): в сообщении есть сгенерированная картинка — сохраняем PNG/JPG,
  // а не .md (пользователь жаловался: «создал фото, а сохранить даёт только мд»).
  try {
    const txt = String(m.content || '');
    const srcs = [];
    for (const x of txt.matchAll(/!\[[^\]]*\]\(\s*<?([^)\s>]+)>?[^)]*\)/g)) {
      const u = x[1];
      if (/^data:image\/(png|jpeg|jpg|webp);base64,/i.test(u)) srcs.push(u);
      else if (/^https?:\/\/\S+\.(png|jpe?g|webp)(\?\S*)?$/i.test(u)) srcs.push(u);
    }
    if (/^data:image\//i.test(String(m.imageDataUrl || ''))) srcs.push(m.imageDataUrl);
    // V-VIDEO-CLI: в сообщении карточка видео — сохраняем mp4 (ссылка вида /v1/videos/<id>/content...)
    const vids = [];
    for (const x of txt.matchAll(/https?:\/\/[^\s)\]"']+\/v1\/videos\/[\w.-]+\/content[^\s)\]"']*/g)) vids.push(x[0]);
    if (!srcs.length && vids.length) {
      for (let i = 0; i < vids.length; i++) {
        let href = vids[i];
        try { href = URL.createObjectURL(await (await fetch(vids[i])).blob()); }
        catch (eVd) { window.open(vids[i], '_blank'); continue; }
        const a = document.createElement('a');
        a.href = href;
        a.download = 'riskradar-video-' + new Date().toISOString().slice(0, 10) + (vids.length > 1 ? '-' + (i + 1) : '') + '.mp4';
        document.body.appendChild(a); a.click(); a.remove();
        if (href.startsWith('blob:')) setTimeout(() => URL.revokeObjectURL(href), 60000);
      }
      toast('Сохранено видео: ' + vids.length + (window.electron ? ' (в папку «Загрузки»)' : ''), 'ok');
      return;
    }

    if (srcs.length) {
      for (let i = 0; i < srcs.length; i++) {
        const src = srcs[i];
        const ext = /^data:image\/jpe?g/i.test(src) ? 'jpg' : ((src.match(/\.(png|jpe?g|webp)/i) || [, 'png'])[1]);
        let href = src;
        if (/^https?:/i.test(src)) {
          try { href = URL.createObjectURL(await (await fetch(src)).blob()); }
          catch (eF) { window.open(src, '_blank'); continue; }
        }
        const a = document.createElement('a');
        a.href = href;
        a.download = 'riskradar-img-' + new Date().toISOString().slice(0, 10) + (srcs.length > 1 ? '-' + (i + 1) : '') + '.' + ext;
        document.body.appendChild(a); a.click(); a.remove();
        if (href.startsWith('blob:')) setTimeout(() => URL.revokeObjectURL(href), 60000);
      }
      toast('Сохранено изображений: ' + srcs.length + (window.electron ? ' (в папку «Загрузки»)' : ''), 'ok');
      return;
    }
  } catch (eP) {}
  const suggested = 'riskradar-' + new Date().toISOString().slice(0, 10) + '.md';
  const r = await rr.invoke('fs:saveDialog', { suggestedName: suggested, content: m.content || '' });
  if (r && r.ok) toast(t('exportDone') + ': ' + r.path);
  else if (r && r.error) toast(r.error, 'err');
}

/* V-MEMFIX: конвертация текстового вложения (.md/.txt) в DOCX одной кнопкой */
async function convertAttachmentToDocx(a) {
  try {
    const title = String(a.name || 'document').replace(/\.(md|markdown|txt)$/i, '');
    const r = await executeDocTool({ format: 'docx', title: title, content: String(a.content || '') });
    if (r && r.ok) toast(t('docxDone') + ': ' + r.output);
    else toast((r && r.output) || 'DOCX failed', 'err');
  } catch (e) { toast(String((e && e.message) || e), 'err'); }
}

/* ------------------------------ вложения ------------------------------ */

function clearAttachments() { pendingAttachments = []; renderAttachments(); }
function renderAttachments() {
  const box = $('#attachments');
  box.classList.toggle('hidden', !pendingAttachments.length);
  box.innerHTML = '';
  for (const a of pendingAttachments) {
    const chip = document.createElement('span');
    chip.className = 'chip';
    if (a.kind === 'image') chip.innerHTML = `<img src="${a.content}" alt=""><span>${esc(a.name)}</span>`;
    else chip.innerHTML = `<span>${esc(a.name)} — ${fmtSize(a.size)}</span>`;
    const rm = document.createElement('button');
    rm.className = 'rm'; rm.textContent = '✕';
    rm.onclick = () => { pendingAttachments = pendingAttachments.filter((x) => x !== a); renderAttachments(); };
    chip.appendChild(rm);
    box.appendChild(chip);
  }
}

async function attachPath(p, silent) {
  const ext = extOf(p);
  const name = p.split(/[\\/]/).pop();
  if (IMG_EXT.has(ext)) {
    const r = await rr.invoke('fs:readImage', { filePath: p });
    if (r.ok) { p = r.path || p; pendingAttachments.push({ name: r.name || name, size: r.size, path: p, kind: 'image', content: r.dataUrl }); renderAttachments(); if (!silent) toast(t('fileAttached')); imageAttachWarn(); }
    else toast(r.error, 'err');
    return;
  }
  const info = await rr.invoke('fs:extInfo', { filePath: p }).catch(() => null);
  if (info && info.isDir) { await attachDirPath(p, silent); return; }
  const r = await rr.invoke('fs:readText', { filePath: p });
  if (r && r.ok === false && r.error && /не является файлом|NOT_A_FILE/i.test(String(r.error))) { await attachDirPath(p, silent); return; }
  if (r.ok) {
    p = r.path || p;
    const _ACap = attachCharLimit();
    const content = r.content.length > _ACap ? r.content.slice(0, _ACap) + '\n…(обрезано: максимум окна модели; читай частями rr-file read start/end)' : r.content;
    pendingAttachments.push({ name: r.name || name, size: r.size, path: p, kind: 'text', content });
    renderAttachments(); if (!silent) toast(`${t('fileAttached')}: «${name}» (${fmtSize(r.size)})`);
  } else toast(r.error, 'err');
}

// 1.2.86 V-IMG-ALWAYS: предупреждение, если картинки выключены / модель без vision
function imageAttachWarn() {
  try {
    if (S().sendImages === false) { toast('⚠ «Отправлять изображения» выключено — модель НЕ увидит картинку. Включите в Настройках', 'warn', null, () => openSettings()); return; }
    const meta = getModelMeta(S().model);
    if (meta && Array.isArray(meta.modalities) && meta.modalities.length && !meta.modalities.includes('image')) {
      toast('⚠ ' + (meta.label || S().model) + ' может не читать картинки — если модель «не видит» их, смените vision-модель (🖼)', 'warn');
    }
  } catch (e) {}
}
// V-PASTE1: прикрепление изображения прямо из File/Blob (без файлового пути) — для скриншотов из буфера.
function attachImageBlob(file, silent) {
  return new Promise((resolve) => {
    if (!file || !/^image\//i.test(file.type || '')) { resolve(false); return; }
    const fr = new FileReader();
    fr.onload = () => {
      const dataUrl = String(fr.result || '');
      if (!dataUrl.startsWith('data:image')) { resolve(false); return; }
      const ext = ((file.type.split('/')[1] || 'png').replace('jpeg', 'jpg'));
      const name = file.name && file.name !== 'image' ? file.name : ('clipboard-' + Date.now() + '.' + ext);
      pendingAttachments.push({ name, size: file.size || 0, path: '', kind: 'image', content: dataUrl });
      imageAttachWarn();
      renderAttachments();
      if (!silent) toast(t('fileAttached'));
      resolve(true);
    };
    fr.onerror = () => resolve(false);
    fr.readAsDataURL(file);
  });
}

async function loadModels(quiet) {
  const sel = $('#model-select'), setSel = $('#set-model');
  let r;
  try {
    r = await rr.invoke('gw:models', { baseUrl: S().baseUrl, apiKey: S().apiKey });
  } catch (e) {
    modelsLastError = e.message || String(e);
    if (!quiet) toast('Модели: ' + (e.message || e), 'err');
    scheduleModelsRetry();
    return;
  }
  if (r.error) { modelsLastError = r.error; if (!quiet) toast('Модели: ' + r.error, 'err'); scheduleModelsRetry(); return; }
  models = (r.models || []).filter((m) => !/^rrx/i.test(m));
  if (models.length) {
    modelsLastError = null; modelsRetryCount = 0;
    if (modelsRetryTimer) { clearTimeout(modelsRetryTimer); modelsRetryTimer = null; }
  } else {
    modelsLastError = modelsLastError || 'шлюз вернул пустой список моделей';
    scheduleModelsRetry();
  }
  modelMeta = applyGatewayModelPricing(r.meta || {});
  if (S().model && !models.includes(S().model)) S().model = '';
  if (r.default && !S().model) S().model = r.default;
  if (S().model && !models.includes(S().model)) S().model = models[0] || '';
  const grouped = {};
  for (const m of models) {
    const meta = getModelMeta(m);
    (grouped[meta.group] ||= []).push(meta);
  }
  const fill = (el) => {
    if (!el) return;
    el.innerHTML = '';
    const groups = MODEL_GROUP_ORDER.concat(Object.keys(grouped).filter((g) => !MODEL_GROUP_ORDER.includes(g)));
    // 1.2.80: избранное — первой группой
    const gmap = {}; for (const gk in grouped) for (const mm of grouped[gk]) gmap[mm.id] = mm;
    const favArr3 = Array.isArray(S().favorites) ? S().favorites : [];
    const favMetas3 = favArr3.map((id3) => gmap[id3] || null).filter(Boolean);
    if (favMetas3.length) {
      const ogf = document.createElement('optgroup');
      ogf.label = '⭐ Избранное';
      for (const meta of favMetas3) { const o = document.createElement('option'); o.value = meta.id; o.textContent = '★ ' + modelOptionLabel(meta.id); ogf.appendChild(o); }
      el.appendChild(ogf);
    }
    for (const groupName of groups) {
      const items = grouped[groupName];
      if (!items || !items.length) continue;
      const og = document.createElement('optgroup');
      og.label = groupName;
      for (const meta of items.sort((a, b) => a.coef - b.coef || a.label.localeCompare(b.label))) {
        const o = document.createElement('option');
        o.value = meta.id; o.textContent = modelOptionLabel(meta.id);
        og.appendChild(o);
      }
      el.appendChild(og);
    }
    if (!models.length) {
      const o = document.createElement('option');
      o.value = S().model; o.textContent = modelOptionLabel(S().model || 'default');
      el.appendChild(o);
    }
  };
  fill(sel); fill(setSel);
  if (S().model) { sel.value = S().model; setSel.value = S().model; }
  updateModelPicker();
  updateReasoningBtn();
  renderModelBrowser();
  updateKeyBadge();
}

function updateKeyBadge() {
  const badge = $('#key-badge'), txt = $('#key-badge-text');
  if (S().apiKey) { badge.classList.add('ok'); txt.textContent = t('keyActive'); badge.title = S().apiKey.slice(0, 12) + '…'; }
  else { badge.classList.remove('ok'); txt.textContent = t('noKey'); badge.title = ''; }
}

function normalizeBalancePayload(raw) {
  const parseMaybe = (v) => {
    if (typeof v !== 'string') return v;
    const s = v.trim();
    if (!s) return v;
    try { return JSON.parse(s); } catch (e) { return v; }
  };
  const root = parseMaybe(raw);
  const candidates = [root, root && root.data, root && root.result, root && root.balance, root && root.payload, root && root.body, root && root.response].map(parseMaybe).filter((v) => v && typeof v === 'object');
  for (const r of candidates) {
    const unlimited = typeof r.unlimited === 'boolean' ? r.unlimited : (r.balance === null && r.tokens == null ? true : undefined);
    const tokens = r.tokens ?? r.balance ?? r.remaining ?? r.available ?? r.balance_tokens ?? r.available_tokens ?? r.remainingTokens;
    const keyObj = typeof r.key === 'object' ? r.key : {};
    const keyInfo = typeof r.keyInfo === 'object' ? r.keyInfo : {};
    const keyLimit = r.keyLimit ?? r.key_limit ?? keyObj.limitTokens ?? keyObj.limit ?? keyInfo.limitTokens ?? keyInfo.limit;
    const keyRemaining = r.keyRemaining ?? r.key_remaining ?? keyObj.remainingTokens ?? keyObj.remaining ?? keyInfo.remainingTokens ?? keyInfo.remaining;
    if (r.object === 'balance' || r.ok === true || typeof unlimited === 'boolean' || tokens != null || keyLimit != null || keyRemaining != null) {
      return { unlimited: !!unlimited, tokens: tokens == null ? null : Number(tokens) || 0, keyLimit: Number(keyLimit) || 0, keyRemaining: keyRemaining == null ? null : (Number(keyRemaining) || 0), raw: r };
    }
  }
  return null;
}
async function fetchJsonWithKey(url) {
  const key = String(S().apiKey || '').trim();
  const res = await fetch(url, {
    method: 'GET',
    mode: 'cors',
    cache: 'no-store',
    headers: { Authorization: 'Bearer ' + key, 'x-api-key': key, 'api-key': key, Accept: 'application/json' }
  });
  const text = await res.text();
  let data = text;
  try { data = JSON.parse(text); } catch (e) {}
  if (!res.ok) throw new Error((data && typeof data === 'object' && (data.error || data.message)) || ('HTTP ' + res.status));
  return data;
}
async function fetchBalanceDirect() {
  const base = String(S().baseUrl || 'https://riskradarai.ru/v1').replace(/\/+$/, '');
  try {
    return await fetchJsonWithKey(base + '/balance?ts=' + Date.now());
  } catch (e) {
    return await fetchJsonWithKey(base + '?ts=' + Date.now());
  }
}
function applyBalanceUi(info, errText) {
  const el = $('#key-balance-val'), badge = $('#key-balance');
  if (!el || !badge) return;
  if (!info) {
    el.textContent = '—';
    badge.classList.add('err');
    badge.title = errText ? `${t('balanceTitle')}\n${errText}` : t('balanceTitle');
    return;
  }
  badge.classList.remove('err');
  const shown = info.unlimited ? '∞' : (info.tokens != null ? fmtTokens(info.tokens) : (info.keyRemaining != null ? fmtTokens(info.keyRemaining) : '0'));
  el.textContent = shown;
  const parts = [t('balanceTitle') + ': ' + (info.unlimited ? '∞' : ((info.tokens != null ? Number(info.tokens || 0).toLocaleString('ru-RU') : Number(info.keyRemaining || 0).toLocaleString('ru-RU')) + ' ' + t('balanceTokens')))];
  if (info.keyRemaining != null) parts.push((info.keyLimit > 0 ? 'лимит ключа: ' : 'остаток ключа: ') + fmtTokens(info.keyRemaining));
  parts.push('Нажмите, чтобы открыть пополнение / промокод');
  badge.title = parts.join('\n');
}
async function updateBalance() {
  const el = $('#key-balance-val'), badge = $('#key-balance');
  if (!el || !badge) return;
  if (!S().apiKey) { applyBalanceUi(null); return; }
  let errText = '';
  try {
    const viaHttp = await fetchBalanceDirect();
    const normalized = normalizeBalancePayload(viaHttp);
    if (normalized) return applyBalanceUi(normalized);
    console.warn('[RR] balance http unexpected payload', viaHttp);
  } catch (e) {
    errText = e && e.message ? e.message : String(e || '');
    console.warn('[RR] balance http failed', e);
  }
  try {
    const viaBridge = await rr.invoke('gw:balance', { baseUrl: S().baseUrl, apiKey: S().apiKey });
    const normalized = normalizeBalancePayload(viaBridge);
    if (normalized) return applyBalanceUi(normalized);
    console.warn('[RR] balance bridge unexpected payload', viaBridge);
  } catch (e) {
    errText = errText || (e && e.message ? e.message : String(e || ''));
    console.warn('[RR] balance bridge failed', e);
  }
  applyBalanceUi(null, errText);
}
async function fetchSiteJson(url, init, options) {
  const opts = typeof options === 'boolean' ? { withCredentials: options } : (options || {});
  const key = String(S().apiKey || '').trim();
  const baseHeaders = { Accept: 'application/json' };
  if (opts.useApiKey && key) {
    baseHeaders.Authorization = 'Bearer ' + key;
    baseHeaders['x-api-key'] = key;
    baseHeaders['api-key'] = key;
  }
  const extraHeaders = Object.assign({}, baseHeaders, (init && init.headers) || {});
  const res = await fetch(url, Object.assign({ method: 'GET', mode: 'cors', cache: 'no-store', headers: extraHeaders }, init || {}, opts.withCredentials ? { credentials: 'include' } : {}, { headers: extraHeaders }));
  const text = await res.text();
  let data = text;
  try { data = JSON.parse(text); } catch (e) {}
  if (!res.ok) throw new Error((data && typeof data === 'object' && (data.error || data.message)) || ('HTTP ' + res.status));
  return data;
}
function normalizeTopupError(err) {
  const msg = String(err && err.message ? err.message : err || '').trim();
  if (/auth|required|войдите|login/i.test(msg)) return t('topupAuthRequired');
  return msg || 'Payment error';
}
function topupEstimateFromRub(rub) {
  const P = topupState || {};
  const min = P.min || {};
  const me = P.me || {};
  const pub = P.pub || {};
  const rate = Number(min.rubPerUsd || me.usdRate || pub.usdRate || 0);
  const bonus = Number(min.yooBonusPct != null ? min.yooBonusPct : (pub.bonusPct != null ? pub.bonusPct : (me.bonusPct || 0))) || 0;
  const rubPerM = Number(pub.pricePerMRub || me.pricePerMRub || me.vcPricePerMRub || 0);
  if (rubPerM > 0) PRICE_PER_M_RUB = rubPerM;   // V-IMGCOST: уточняем тариф для цены картинки
  const base = rubPerM > 0 && rub > 0 ? Math.floor(rub / rubPerM * 1000000) : 0;
  const total = base > 0 ? Math.round(base * (1 + bonus / 100)) : 0;
  return { rate, bonus, rubPerM, base, total, usd: rate > 0 ? rub / rate : 0 };
}
function topupEstimateFromUsd(usd) {
  const rate = Number((topupState.min || {}).rubPerUsd || (topupState.me || {}).usdRate || 0);
  return topupEstimateFromRub(Math.round((Number(usd || 0) || 0) * rate));
}
function startTopupPolling() {
  stopTopupPolling();
  topupPollTimer = setInterval(() => updateBalance().catch(console.warn), 12000);
}
function stopTopupPolling() {
  if (topupPollTimer) clearInterval(topupPollTimer);
  topupPollTimer = null;
}
async function ensureTopupData() {
  const P = topupState;
  if (!P.min) {
    try { P.min = await fetchSiteJson('https://riskradarai.ru/api/pay/yoa/min'); } catch (e) { P.error = normalizeTopupError(e); }
  }
  if (!P.dirs) {
    try {
      const j = await fetchSiteJson('https://riskradarai.ru/api/pay/directions');
      P.dirs = Array.isArray(j.directions) ? j.directions : [];
      if (!P.network && P.dirs[0]) P.network = P.dirs[0].network_code || '';
    } catch (e) { P.error = P.error || normalizeTopupError(e); }
  }
  if (!P.pub) {
    // Публичный прайс сайта: вход в аккаунт не нужен.
    try { P.pub = await fetchSiteJson('https://riskradarai.ru/api/vc/public?t=' + Date.now()); }
    catch (e) { P.pub = null; }
  }
  if (!P.meChecked) {
    P.meChecked = true;
    // Информационный запрос: если ключ не VibeCoder — просто не показываем баланс, оплата работает.
    try { P.me = await fetchSiteJson('https://riskradarai.ru/api/vc/me', {}, { useApiKey: true }); }
    catch (e) { P.me = null; }
    P.authHint = '';
  }
}
function renderTopupModal() {
  const body = $('#topup-body');
  if (!body) return;
  const P = topupState;
  const min = P.min || {};
  const dirs = Array.isArray(P.dirs) ? P.dirs : [];
  const tab = P.tab || 'sbp';
  const minRub = Number(min.minRUB) || 250;
  const minUsd = Number(min.minUSD) || 3;
  const rub = Math.max(minRub, Number(P.rub || minRub));
  const usd = Math.max(minUsd, Number(P.usd || 10));
  const sbpEst = topupEstimateFromRub(rub);
  const cryptoEst = topupEstimateFromUsd(usd);
  const payTitle = P.me && P.me.tokens != null ? `<div class="topup-lead">Сейчас на счёте: <b>${fmtTokens(P.me.tokens)}</b> токенов.</div>` : '<div class="topup-lead">Пополнение и зачисление как на сайте RiskRadar.</div>';
  const authNote = P.authHint ? `<div class="topup-note warn">${esc(P.authHint)}</div>` : '';
  const err = P.error ? `<div class="topup-note err">${esc(P.error)}</div>` : '';
  const sbpResult = P.sbp ? `<div class="topup-result"><div class="topup-row"><span>Сумма</span><code>${fmtMoneyRub(P.sbp.amount_rub || rub)} · ${fmtMoneyUsd(P.sbp.amount_usd || sbpEst.usd || 0)}</code></div>${sbpEst.total > 0 ? `<div class="topup-row"><span>Зачисление</span><code>${fmtTokens(sbpEst.total)} токенов</code></div>` : ''}<button class="btn-accent w100" id="topup-sbp-open">${esc(t('topupOpenPay'))}</button></div>` : '';
  const cryptoResult = P.crypto ? `<div class="topup-result"><div class="topup-row"><span>Сумма</span><code>${esc(String(P.crypto.payer_amount || usd))} USDT · ${esc(P.crypto.network || P.network || '')}</code></div>${cryptoEst.total > 0 ? `<div class="topup-row"><span>Зачисление</span><code>${fmtTokens(cryptoEst.total)} токенов</code></div>` : ''}<div class="topup-row"><span>Адрес</span><code class="break">${esc(P.crypto.address || '')}</code><button class="btn-ghost sm" data-copy="${esc(P.crypto.address || '')}">${esc(t('topupCopy'))}</button></div>${P.crypto.qr ? `<div class="topup-qr-wrap"><img class="topup-qr" src="${esc(P.crypto.qr)}" alt="QR"></div>` : ''}</div>` : '';
  body.innerHTML = `${payTitle}
    <div class="topup-tabs">
      <button class="${tab === 'sbp' ? 'active' : ''}" data-topup-tab="sbp">${esc(t('topupSbp'))}</button>
      <button class="${tab === 'crypto' ? 'active' : ''}" data-topup-tab="crypto">${esc(t('topupCrypto'))}</button>
    </div>
    ${authNote}
    ${err}
    ${tab === 'sbp' ? `
      <section class="topup-pane">
        <div class="topup-presets">${[minRub, 500, 1000, 2000, 5000].filter((v, i, a) => a.indexOf(v) === i).map((v) => `<button class="${rub === v ? 'active' : ''}" data-topup-rub="${v}">${fmtMoneyRub(v)}</button>`).join('')}</div>
        <div class="topup-input-row"><input id="topup-rub-input" type="number" min="${minRub}" step="50" value="${rub}"><button class="btn-accent" id="topup-sbp-create">${esc(P.busy ? t('topupCreating') : t('topupPay'))}</button></div>
        <div class="topup-note">Минимум: ${fmtMoneyRub(minRub)}${sbpEst.rate > 0 ? ` · курс ${sbpEst.rate.toFixed(2)} ₽/$` : ''}</div>
        ${sbpEst.total > 0 ? `<div class="topup-note">Будет зачислено <b>${fmtTokens(sbpEst.total)}</b> токенов · ${fmtTokens(sbpEst.base)} + бонус ${sbpEst.bonus}%</div>` : ''}
        ${sbpResult}
      </section>` : `
      <section class="topup-pane">
        <div class="topup-presets">${dirs.length ? dirs.map((x) => `<button class="${(P.network || '') === x.network_code ? 'active' : ''}" data-topup-net="${esc(x.network_code || '')}">${esc(x.name || x.network_code || '')}</button>`).join('') : '<div class="topup-note">Загружаем сети…</div>'}</div>
        <div class="topup-input-row"><input id="topup-usd-input" type="number" min="${minUsd}" step="1" value="${usd}"><button class="btn-accent" id="topup-crypto-create">${esc(P.busy ? t('topupCreatingInvoice') : t('topupGetAddress'))}</button></div>
        <div class="topup-note">Минимум: ${fmtMoneyUsd(minUsd)}${cryptoEst.rate > 0 ? ` · ≈ ${fmtMoneyRub(Math.round(usd * cryptoEst.rate))}` : ''}</div>
        ${cryptoEst.total > 0 ? `<div class="topup-note">Будет зачислено <b>${fmtTokens(cryptoEst.total)}</b> токенов · ${fmtTokens(cryptoEst.base)} + бонус ${cryptoEst.bonus}%</div>` : ''}
        ${cryptoResult}
      </section>`}`;
  const openSiteBtn = $('#topup-open-site');
  if (openSiteBtn) openSiteBtn.onclick = () => openExternalUrl(TOPUP_SITE_URL);
  body.querySelectorAll('[data-topup-tab]').forEach((b) => b.onclick = () => { P.tab = b.dataset.topupTab; P.error = ''; renderTopupModal(); });
  body.querySelectorAll('[data-topup-rub]').forEach((b) => b.onclick = () => { P.rub = Number(b.dataset.topupRub) || minRub; renderTopupModal(); });
  body.querySelectorAll('[data-topup-net]').forEach((b) => b.onclick = () => { P.network = b.dataset.topupNet || ''; renderTopupModal(); });
  const rubInput = $('#topup-rub-input');
  if (rubInput) {
    rubInput.oninput = () => { P.rub = Number(rubInput.value) || 0; };
    rubInput.onchange = () => { P.rub = Number(rubInput.value) || 0; renderTopupModal(); };
  }
  const usdInput = $('#topup-usd-input');
  if (usdInput) {
    usdInput.oninput = () => { P.usd = Number(usdInput.value) || 0; };
    usdInput.onchange = () => { P.usd = Number(usdInput.value) || 0; renderTopupModal(); };
  }
  const sbpOpen = $('#topup-sbp-open'); if (sbpOpen) sbpOpen.onclick = () => openExternalUrl((P.sbp && P.sbp.confirmation_url) || TOPUP_SITE_URL);
  body.querySelectorAll('[data-copy]').forEach((b) => b.onclick = async () => { if (await copyText(b.dataset.copy || '')) { b.textContent = t('topupCopied'); toast(t('copied')); } });
  const sbpCreate = $('#topup-sbp-create');
  if (sbpCreate) sbpCreate.onclick = async () => {
    const amount = Math.floor(Number(($('#topup-rub-input') || {}).value || P.rub || 0));
    P.rub = amount; P.error = ''; P.sbp = null;
    if (amount < minRub) { P.error = 'Минимальная сумма пополнения по СБП — ' + fmtMoneyRub(minRub); renderTopupModal(); return; }
    P.busy = true; renderTopupModal();
    try {
      P.sbp = await fetchSiteJson('https://riskradarai.ru/api/pay/yoa/create', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ kind: 'balance', amount_rub: amount }) }, { useApiKey: true });
      startTopupPolling();
      if (P.sbp && P.sbp.confirmation_url) openExternalUrl(P.sbp.confirmation_url);
    } catch (e) {
      P.error = normalizeTopupError(e);
    }
    P.busy = false; renderTopupModal();
  };
  const cryptoCreate = $('#topup-crypto-create');
  if (cryptoCreate) cryptoCreate.onclick = async () => {
    const amount = Math.round((Number(($('#topup-usd-input') || {}).value || P.usd || 0) || 0) * 100) / 100;
    P.usd = amount; P.error = ''; P.crypto = null;
    if (amount < minUsd) { P.error = 'Минимальная сумма для крипты — ' + fmtMoneyUsd(minUsd); renderTopupModal(); return; }
    if (!dirs.length) { P.error = 'Список сетей ещё не загрузился'; renderTopupModal(); return; }
    P.busy = true; renderTopupModal();
    try {
      P.crypto = await fetchSiteJson('https://riskradarai.ru/api/pay/create', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ kind: 'balance', amount, network: P.network || ((dirs[0] || {}).network_code || '') }) }, { useApiKey: true });
      startTopupPolling();
    } catch (e) {
      P.error = normalizeTopupError(e);
    }
    P.busy = false; renderTopupModal();
  };
}
function openTopupPage() {
  topupState.error = '';
  renderTopupModal();
  openModal('#topup-modal');
  ensureTopupData().then(renderTopupModal).catch((e) => { topupState.error = normalizeTopupError(e); renderTopupModal(); });
}
/* V-IMGWARN: модель генерации картинок не читает чат и его историю — предупреждаем явно. */
const IMG_WARN = () => (LANG === 'en'
  ? 'Image-generation model: it makes a picture from your prompt and reference photos, but it does not follow the text dialogue or its history. For a normal conversation pick a text model.'
  : 'Это модель генерации изображений: она создаёт картинку по вашему описанию и фото-референсам, но не ведёт текстовый диалог и не читает историю сообщений. Для обычного чата выберите текстовую модель.');
/* V-REASON: модели, умеющие менять уровень мышления (reasoning_effort),
   и логика переключения low -> medium -> high. */
const REASONING_LEVELS = ['low', 'medium', 'high'];
const REASONING_CHOICES = ['default', 'off', 'low', 'medium', 'high'];
const REASONING_LABELS = {
  ru: { low: 'быстро', medium: 'баланс', high: 'глубоко' },
  en: { low: 'low', medium: 'medium', high: 'high' }
};
function modelSupportsReasoning(modelId) {
  const m = String(modelId || '').toLowerCase();
  if (!m) return false;
  // картинки, озвучка и эмбеддинги уровня мышления не имеют
  if (/image|imagen|tts|whisper|embed|moderation|music|audio/.test(m)) return false;
  if (/^(o1|o3|o4|gpt-5|gpt-6|codex)/.test(m)) return true;   // OpenAI: o-серия и GPT-5/6
  if (/^claude-/.test(m)) return true;                       // Anthropic: расширенное мышление
  if (/^gemini-/.test(m)) return true;                       // Google: Gemini 2.5+
  if (/^grok-4/.test(m)) return true;                        // xAI: Grok 4+
  if (/reasoner|deepseek-(r|v4)/.test(m)) return true;       // DeepSeek reasoning
  if (/claude|opus|sonnet|haiku/i.test(m)) return true;         // V-REASONUI: Anthropic extended thinking
  if (/^qwen3|qwq/.test(m)) return true;                     // Alibaba: Qwen3 thinking
  if (/^glm-5/.test(m)) return true;                         // Zhipu: GLM-5
  if (/^kimi-k[23]/.test(m)) return true;                    // Moonshot: Kimi K2/K3
  if (/^minimax-m[23]/.test(m)) return true;                 // MiniMax: M2/M3
  if (/^hy4|^mimo-v/.test(m)) return true;                   // Tencent Hunyuan 4, Xiaomi MiMo
  return false;
}
function currentReasoningEffort() {
  const v = String(S().reasoningEffort || 'medium').toLowerCase();
  return REASONING_LEVELS.includes(v) ? v : 'medium';
}
function reasoningChoice() { const v = String(S().reasoningEffort || 'default').toLowerCase(); return REASONING_CHOICES.includes(v) ? v : 'default'; }
function closeReasoningPop() { const p = $('#reasoning-pop'); if (p) p.classList.add('hidden'); }
function openReasoningPop() { const p = $('#reasoning-pop'); if (!p) return;
  // 1.2.75: попап позиционируется над кнопкой (кнопка теперь в нижней строке карточки)
  if (p.classList.contains('hidden')) {
    const btn = $('#btn-reasoning'), wrap = $('#composer-wrap');
    if (btn && wrap) {
      const w = wrap.clientWidth || 600;
      p.style.left = Math.max(4, Math.min(btn.offsetLeft, w - 200)) + 'px';
      p.style.bottom = (wrap.clientHeight - (btn.offsetTop + btn.offsetHeight) + 10) + 'px';
    }
  }
  p.classList.toggle('hidden'); }
function selectReasoningChoice(v) { if (!REASONING_CHOICES.includes(v)) return; S().reasoningEffort = v; saveDb(); updateReasoningBtn(); closeReasoningPop(); }
function cycleReasoningEffort() {
  const cur = currentReasoningEffort();
  const next = REASONING_LEVELS[(REASONING_LEVELS.indexOf(cur) + 1) % REASONING_LEVELS.length];
  S().reasoningEffort = next;
  saveDb();
  updateReasoningBtn();
  const lbl = (REASONING_LABELS[LANG] || REASONING_LABELS.ru)[next];
  toast('🧠 ' + (LANG === 'en' ? 'Reasoning effort: ' : 'Уровень мышления: ') + next + ' (' + lbl + ')');
}
function updateReasoningBtn() {
  const btn = $('#btn-reasoning');
  const lbl = $('#reasoning-label');
  if (!btn || !lbl) return;
  const model = S().model || models[0] || '';
  const supported = modelSupportsReasoning(model);
  if (!supported) {
    btn.classList.add('hidden');
    return;
  }
  btn.classList.remove('hidden');
  const cur = reasoningChoice();
  btn.classList.remove('effort-low', 'effort-medium', 'effort-high');
  btn.classList.add('effort-' + cur);
  const localized = (REASONING_LABELS[LANG] || REASONING_LABELS.ru)[cur] || cur;
  lbl.textContent = localized;
  btn.title = (LANG === 'en'
    ? 'Reasoning effort: ' + cur + ' (' + localized + ')\nClick to change: low → medium → high'
    : 'Уровень мышления модели: ' + cur + ' (' + localized + ')\nКлик — переключить: low (быстро) → medium (баланс) → high (глубоко)');
}

function updateModelPicker() {
  const btn = $('#model-picker-btn');
  const av = $('#model-picker-avatar');
  const txt = $('#model-picker-text');
  if (!btn || !av || !txt) return;
  if (!models.length) {
    txt.innerHTML = `<span>⚠ Модели недоступны</span><small>${esc(modelsLastError || 'загрузка…')} · авто-повтор включён</small>`;
    btn.title = 'Модели недоступны: ' + (modelsLastError || 'загрузка') + '\nКликните, чтобы повторить';
    return;
  }
  const id = S().model || models[0] || '';
  const meta = getModelMeta(id || 'default');
  av.innerHTML = '';
  const warn = meta.isImageGen ? (LANG === 'en' ? ' · 🎨 image generation' : ' · 🎨 генерация картинок') : '';
  txt.innerHTML = `<span>${esc(meta.label || id || 'Model')}</span><small>${esc(meta.provider || meta.group || '')} · ${esc(id || '')} · ${esc(modelCostText(meta))}${esc(warn)}</small>`;
  btn.title = `${meta.label || id} · ${meta.provider || meta.group || ''} · ${id} · ${modelCostTitle(meta)}${warn ? ' — ' + IMG_WARN() : ''}`;
  btn.classList.toggle('imgeng-warn', !!meta.isImageGen);
}
function selectModel(modelId) {
  if (!modelId) return;
  S().model = modelId;
  saveDb();
  const picked = getModelMeta(modelId);
  if (picked && picked.isImageGen) {
    try { toast(IMG_WARN(), 'warn', null, null); } catch (e) { console.warn('[RR] img warn', e); }
  }
  if ($('#model-select')) $('#model-select').value = modelId;
  if ($('#set-model')) $('#set-model').value = modelId;
  updateModelPicker();
  updateReasoningBtn();
  renderModelBrowser();
}
function closeModelPicker() {
  const pop = $('#model-picker-pop');
  if (pop) pop.classList.add('hidden');
}
/* V-MSEARCH: поиск по списку моделей — по человеческому названию, id и группе. */
let modelSearchQuery = '';
function modelMatches(meta, q) {
  if (!q) return true;
  const hay = (meta.label + ' ' + meta.id + ' ' + (meta.group || '') + ' ' + (meta.provider || '')).toLowerCase();
  return q.split(/\s+/).filter(Boolean).every((w) => hay.includes(w));
}
function initModelSearch() {
  const sels = ['#model-search', '#model-picker-search'];
  sels.forEach((sel) => {
    const el = $(sel);
    if (!el || el.dataset.wired) return;
    el.dataset.wired = '1';
    el.value = modelSearchQuery;
    el.addEventListener('input', () => {
      modelSearchQuery = el.value || '';
      sels.forEach((s2) => { const e2 = $(s2); if (e2 && e2 !== el) e2.value = modelSearchQuery; });
      renderModelBrowser();
    });
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { e.stopPropagation(); modelSearchQuery = ''; el.value = ''; renderModelBrowser(); }
      if (e.key === 'Enter') { const first = document.querySelector('.model-line'); if (first) first.click(); }
    });
  });
}
function renderModelBrowser() {
  initModelSearch();
  const targets = ['#model-browser-list', '#model-picker-pop-list'].map((id) => $(id)).filter(Boolean);
  if (!targets.length) return;
  targets.forEach((box) => box.innerHTML = '');
  if (!models.length) {
    for (const box of targets) {
      const d = document.createElement('div');
      d.style.cssText = 'padding:20px 14px;text-align:center;color:var(--muted);font-size:13px';
      d.innerHTML = `⚠ <b>Список моделей пуст</b><br><span style="opacity:.85">${esc(modelsLastError || 'загрузка…')}</span><br><button class="btn primary mb-retry" style="margin-top:10px;padding:6px 16px;font-size:12px">Повторить</button>`;
      box.appendChild(d);
    }
    targets.forEach((box) => box.querySelectorAll('.mb-retry').forEach((bb) => { bb.onclick = () => { modelsRetryCount = 0; loadModels(false); }; }));
    return;
  }

  const q = modelSearchQuery.trim().toLowerCase();
  const grouped = {};
  let matched = 0;
  for (const id of models) {
    const meta = getModelMeta(id);
    if (!modelMatches(meta, q)) continue;
    matched++;
    (grouped[meta.group] ||= []).push(meta);
  }
  const groups = MODEL_GROUP_ORDER.concat(Object.keys(grouped).filter((g) => !MODEL_GROUP_ORDER.includes(g)));
  // 1.2.80: избранное — отдельной группой вверху (быстрый доступ)
  const favArr2 = Array.isArray(S().favorites) ? S().favorites : [];
  const gmap2 = {}; for (const gk2 in grouped) for (const mm2 of grouped[gk2]) gmap2[mm2.id] = mm2;
  const favMetas = favArr2.map((id2) => gmap2[id2] || null).filter(Boolean);
  const groups2 = (favMetas.length ? ['__FAV__'] : []).concat(groups);
  const buildFavWrap = () => {
    const wrap = document.createElement('section');
    wrap.className = 'model-group plain model-group-fav';
    wrap.style.setProperty('--gcolor', '#f5b83d');
    wrap.innerHTML = `<h3><span class="mg-dot"></span>⭐ ${LANG === 'en' ? 'Favorites' : 'Избранное'} <em>${favMetas.length}</em></h3><div class="model-grid plain"></div>`;
    const g = wrap.querySelector('.model-grid');
    for (const meta of favMetas) g.appendChild(buildRow(meta));
    return wrap;
  };
  const MODAL_LABEL = { text: 'Текст', image: 'Изображение', audio: 'Аудио', imagegen: 'Генерация' };
  const MODAL_ICON = { text: '📝', image: '🖼️', audio: '🎧', imagegen: '🎨' };
  const buildRow = (meta) => {
    const btn = document.createElement('button');
    btn.className = 'model-line' + (S().model === meta.id ? ' active' : '');
    btn.dataset.modelId = meta.id;
    const mods = (meta.modalities || ['text']).map((x) => MODAL_ICON[x] || x).join(' ');
    btn.title = `${meta.label || meta.id} · ${meta.provider || meta.group} · ${meta.id} · ${modelCostTitle(meta)}` + (meta.isImageGen ? ' — ' + IMG_WARN() : '');
    // V-NAME: показываем и человеческое имя, и полный технический id модели
    const favArr = Array.isArray(S().favorites) ? S().favorites : [];
    const isFav = favArr.indexOf(meta.id) >= 0;
    const featHint = meta.isImageGen ? 'Умеет: генерация картинок' : 'Умеет: слайды/DOCX/XLSX (rr-doc) · веб-поиск · файлы · команды' + ((meta.modalities || []).includes('image') ? ' · чтение картинок' : '');
    btn.innerHTML = `<span class="ml-logo">${modelLogoSvg(meta, 20)}</span><span class="model-line-main"><b>${esc(meta.label)}</b><i class="ml-id">${esc(meta.id)}</i></span><span class="model-line-mods" title="${mods}">${mods}</span><span class="model-line-side" title="${esc(modelCostTitle(meta))} · ${esc(featHint)}">${esc(modelCostText(meta))}</span><span class="ml-star${isFav ? ' on' : ''}" title="${isFav ? (LANG === 'en' ? 'Remove from favorites' : 'Убрать из избранного') : (LANG === 'en' ? 'Add to favorites (quick access)' : 'В избранное — быстрый доступ')}">★</span>` + (meta.isImageGen ? `<span class="ml-warn">${LANG === 'en' ? 'image generation' : 'генерация картинок'}</span>` : '');
    btn.onclick = () => { selectModel(meta.id); closeModelPicker(); closeModals(); };
    // 1.2.81: star-клик подключается ПОСЛЕ cloneNode (cloneNode теряет .onclick) — см. post-wire ниже
    return btn;
  };
  // 1.2.81: избранное — единый обработчик (после клонирования ноды)
  window.__rrToggleFavorite = function(id) {
    const arr = Array.isArray(S().favorites) ? S().favorites.slice() : [];
    const i = arr.indexOf(id);
    if (i >= 0) arr.splice(i, 1); else arr.unshift(id);
    S().favorites = arr;
    saveDb();
    const meta2 = getModelMeta(id);
    try { toast((i < 0 ? '⭐ ' : '☆ ') + ((meta2 && meta2.label) || id)); } catch (e2) {}
    renderModelBrowser();
  };
  const buildWrap = (groupName) => {
    const items = grouped[groupName];
    if (!items || !items.length) return null;
    const gcolor = (MODEL_GROUP_COLORS && MODEL_GROUP_COLORS[groupName]) || 'var(--accent)';
    const wrap = document.createElement('section');
    wrap.className = 'model-group plain';
    wrap.style.setProperty('--gcolor', gcolor);
    // V-IMGGEN: группу генерации картинок показываем плоским списком (без подгрупп текст/изображение/аудио)
    if (groupName === IMG_GEN_GROUP) {
      wrap.innerHTML = `<h3><span class="mg-dot"></span>🎨 ${esc(groupName)} <em>${items.length}</em></h3><div class="model-grid plain"></div>`;
      const g = wrap.querySelector('.model-grid');
      for (const meta of items.sort((a, b) => a.label.localeCompare(b.label))) g.appendChild(buildRow(meta));
      return wrap;
    }
    // V-MODAL: внутри вендора делим на текст / изображение / аудио
    const byModal = { text: [], image: [], audio: [] };
    for (const m of items) (byModal[m.modality] || byModal.text).push(m);
    let inner = `<h3><span class="mg-dot"></span>${esc(groupName)} <em>${items.length}</em></h3>`;
    for (const mk of ['text', 'image', 'audio']) {
      const list = byModal[mk];
      if (!list || !list.length) continue;
      inner += `<div class="modal-sub"><div class="modal-sub-h">${MODAL_ICON[mk]} ${MODAL_LABEL[mk]} <em>${list.length}</em></div><div class="model-grid plain"></div></div>`;
    }
    wrap.innerHTML = inner;
    const subs = wrap.querySelectorAll('.modal-sub');
    let si = 0;
    for (const mk of ['text', 'image', 'audio']) {
      const list = byModal[mk];
      if (!list || !list.length) continue;
      const grid = subs[si++].querySelector('.model-grid');
      for (const meta of list.sort((a, b) => a.coef - b.coef || a.label.localeCompare(b.label))) grid.appendChild(buildRow(meta));
    }
    return wrap;
  };
  for (const groupName of groups2) {
    const wrap = groupName === '__FAV__' ? buildFavWrap() : buildWrap(groupName);
    if (!wrap) continue;
    targets.forEach((box) => box.appendChild(wrap.cloneNode(true)));
  }
  targets.forEach((box) => {
    if (!matched) {
      const empty = document.createElement('div');
      empty.className = 'model-empty';
      empty.textContent = LANG === 'en' ? 'Nothing found for “' + modelSearchQuery.trim() + '”' : 'Ничего не найдено по запросу «' + modelSearchQuery.trim() + '»';
      box.appendChild(empty);
    }
    box.querySelectorAll('.model-line').forEach((btn) => {
      const id = btn.dataset.modelId || '';
      btn.onclick = () => { selectModel(id); closeModelPicker(); closeModals(); };
      // 1.2.81: cloneNode(true) не копирует .onclick — звёздочку переподключаем здесь
      const star = btn.querySelector('.ml-star');
      if (star) star.onclick = (e) => { e.stopPropagation(); window.__rrToggleFavorite(id); };
    });
  });
}

/* ------------------------------ рабочий каталог ------------------------------ */

async function ensureWorkDir() {
  if (!homeDirCache) homeDirCache = await rr.invoke('fs:home');
  if (!S().workDir) { S().workDir = homeDirCache; if (typeof S().workDirPinned !== 'boolean') S().workDirPinned = false; saveDb(); }
  if (typeof S().workDirPinned !== 'boolean') S().workDirPinned = false;
  return S().workDir;
}

/* V-PROJMAP (1.2.98): при выборе/прикреплении каталога терминал САМ составляет карту-граф
 * проекта (стек, модули, точки входа, типы файлов) и кладёт её в каждую будущую отправку
 * как системный контекст — модель начинает работу со структурой в голове, а не с нуля. */
function renderCatalogMap(dir, idx, treeText) {
  try {
    const L = ['root: ' + dir];
    if (idx) {
      if (idx.projectTypes && idx.projectTypes.length) L.push('stack: ' + idx.projectTypes.slice(0, 8).join(', '));
      L.push('files: ' + (idx.files || []).length + ', dirs: ' + (idx.directories || []).length);
      const ep = (idx.entrypoints || []).slice(0, 10);
      if (ep.length) L.push('entrypoints: ' + ep.join(', '));
      const dirs = (idx.directories || []).slice(0, 80).map((d) => String(d).replace(/\\/g, '/'));
      const top = {};
      for (const d of dirs) { const seg = d.split('/').filter(Boolean); const k = seg[0] || '/'; (top[k] = top[k] || []).push(seg.slice(1).join('/')); }
      const g = Object.keys(top).slice(0, 14).map((k) => k + '/ (' + (top[k].filter(Boolean).length ? top[k].filter(Boolean).slice(0, 6).join(', ') + (top[k].filter(Boolean).length > 6 ? ' …' : '') : '—') + ')');
      if (g.length) L.push('modules:\n  ' + g.join('\n  '));
      const byExt = {};
      for (const f of (idx.files || []).slice(0, 4000)) { const m = String((f && f.name) || f).match(/\.([a-z0-9]+)$/i); const e = m ? m[1].toLowerCase() : ''; byExt[e] = (byExt[e] || 0) + 1; }
      const be = Object.keys(byExt).map((e) => [e, byExt[e]]).sort((a, b) => b[1] - a[1]).slice(0, 10).map((x) => x[0] + ':' + x[1]).join(' · ');
      if (be) L.push('by type: ' + be);
    }
    if (treeText) L.push('tree excerpt:\n' + String(treeText).slice(0, 1400));
    const txt = L.join('\n');
    return txt.length > 3200 ? txt.slice(0, 3200) + '\n…(карта усечена)' : txt;
  } catch (e) { return ''; }
}
async function refreshCatalogMap(dir, idx) {
  try {
    dir = String(dir || '').replace(/[\\/]+$/, '');
    if (!dir) return;
    let tree = '';
    if (!idx) { try { const t = await buildProjectTree(dir); tree = t && t.text; } catch (e) {} }
    const map = renderCatalogMap(dir, idx, tree);
    if (!map) return;
    S().projMap = { dir: dir, at: Date.now(), text: map };
    saveDb();
  } catch (e) {}
}
async function indexCurrentProject(root) {
  const dir = String(root || S().workDir || '').trim();
  if (!dir) return null;
  try {
    const r = await rr.invoke('project:index', { root: dir, options: { maxFiles: 20000, maxFileBytes: 2 * 1024 * 1024 } });
    if (!r || !r.ok) throw new Error((r && r.error) || 'Project index failed');
    const idx = r.index || {};
    window.__RR_PROJECT_INDEX__ = idx;
    try { refreshCatalogMap(dir, idx); } catch (e) {}
    const summary = 'Project types: ' + (idx.projectTypes || []).join(', ') + '; files: ' + (idx.files || []).length + '; directories: ' + (idx.directories || []).length + '; entrypoints: ' + (idx.entrypoints || []).slice(0, 12).join(', ');
    await saveActiveTaskPatch({ projectPath: dir, phase: 'analysis', findings: [summary], nextStep: 'Read entrypoints and build analysis plan' });
    try { toast('Project index: ' + (idx.files || []).length + ' files'); } catch (e) {}
    return idx;
  } catch (e) {
    try { toast('Project index: ' + (e.message || e), 'warn'); } catch (_) {}
    return null;
  }
}
function updateWorkdirChip() {
  const wd = S().workDir || '';
  const pinned = isWorkDirPinned();
  const nameEl = $('#workdir-name'), chip = $('#workdir-chip');
  if (!nameEl || !chip) return;
  nameEl.textContent = wd ? (wd.split(/[\\/]/).filter(Boolean).pop() || wd) : t('workdirHome');
  chip.classList.toggle('pinned', pinned);
  chip.title = pinned
    ? '📌 Каталог закреплён: ИИ пишет только сюда — ' + wd + '\nПКМ — снять закрепление (доступ ко всему ПК)'
    : '🖥 Доступ ко всему ПК. ЛКМ — выбрать папку проекта, ПКМ — закрепить текущий каталог';
}

/* ------------------------------ onboarding ------------------------------ */

function updateWelcomeVisibility() {
  const chooser = $('#lang-chooser'), main = $('#welcome-main');
  const wk = $('#welcome-key');
  if (wk && S().apiKey && !wk.value) wk.value = S().apiKey;
  if (!S().lang) { chooser.classList.remove('hidden'); main.classList.add('hidden'); }
  else { chooser.classList.add('hidden'); main.classList.remove('hidden'); }
}

function chooseLang(lang) {
  S().lang = lang; LANG = lang;
  saveDb(); applyI18n(); updateWelcomeVisibility(); renderChatList();
  toast(lang === 'ru' ? 'Язык: Русский' : 'Language: English');
}

async function welcomeConnect() {
  const key = ($('#welcome-key').value.trim() || S().apiKey || '').trim();
  if (!key) { toast(t('enterKey'), 'warn'); return; }
  const btn = $('#welcome-connect');
  btn.disabled = true; btn.textContent = '…';
  S().apiKey = key;
  const r = await rr.invoke('gw:check', { baseUrl: S().baseUrl, apiKey: key });
  btn.disabled = false; btn.textContent = t('connect');
  if (r.error) { toast(t('sshErr') + r.error, 'err'); return; }
  if (r.ok) {
    toast(t('keyOk') + (r.defaultModel ? ' · ' + r.defaultModel : ''));
    saveDb(); updateKeyBadge(); updateBalance(); loadModels(true);
    if (!db.chats.length) newChat(true); else renderMessages();
  } else {
    toast(t('keyBad'), 'err');
  }
}

/* ------------------------------ модалки ------------------------------ */

/* V-CTX: панель контекста и токенов у кнопки отправки */
let autoCompress = false;
/* V-PATHFIX: путь может содержать пробелы и кириллицу, поэтому раньше он обрезался до первого пробела.
   Теперь берём максимум символов и отдельно отсекаем текст фразы после пути. */
/* V-PATHFIX: путь может содержать пробелы и кириллицу, поэтому раньше он обрезался по первому пробелу.
   Теперь берём максимум символов и отсекаем текст фразы, отдавая предпочтение варианту,
   который оканчивается расширением файла: имя вида «файл с пробелами.docx» не режется. */
function trimPathCandidate(s) {
  const seps = ['. ', ', ', '; ', ' — ', ' – ', ' | ', '\t', ' и ', ' в ', ' на ', ' с ', ' или ', ' для ', ' из ', ' по ', ' не ', ' уже ', ' всё ', ' что ', ' это ', ' затем ', ' далее ', ' потом ', ' после '];
  const cands = [s];
  for (const sep of seps) { const idx = s.indexOf(sep); if (idx > 3) cands.push(s.slice(0, idx)); }
  const hasExt = (v) => /\.[A-Za-z0-9]{1,6}$/.test(v);
  const withExt = cands.filter(hasExt);
  if (withExt.length) return withExt.reduce((a, b) => (b.length > a.length ? b : a));
  return cands.reduce((a, b) => (b.length < a.length ? b : a));
}
function extractFilePaths(text) {
  const out = [];
    const push = (v) => {
    let p = String(v || '').trim().replace(/^[\s"'`(\[]+/g, '');
    // V-FILEONCE2: правый якорь диска/сети — режем мусор слева от «C:/»
    const are = /[A-Za-z]:[\\/]/g; let st = -1, mt;
    while ((mt = are.exec(p))) st = mt.index;
    if (st > 0) p = p.slice(st);
    p = p.trim().replace(/[\s"'`)\]}.,;:]+$/g, '');
    p = trimPathCandidate(p).trim().replace(/[\s"'`)\]}.,;:]+$/g, '');
    // режем хвост по пробелам, пока последний сегмент не станет файлом с расширением
    for (let guard = 0; guard < 8; guard++) {
      const leaf = p.split(/[\\/]/).pop() || '';
      if (/\.[A-Za-z0-9]{1,10}$/.test(leaf)) break;
      const cut = p.replace(/\s+\S+$/, '');
      if (!cut || cut.length < 5) { p = ''; break; }
      p = cut;
    }
    if (!p || p.length < 5 || p.length > 300) return;
    if (!/^([A-Za-z]:[\\/]|\\\\|\/)/.test(p)) return;
    if (out.includes(p)) return;
    out.push(p);
  };
  const src = String(text || '');
  for (const m of src.matchAll(/`([^`\n]{5,300})`/g)) push(m[1]);
  const re = /(?:[A-Za-z]:[\\/]|\\\\|\/)[^"'`<>|?*\r\n]{4,300}/g;
  let m2;
  while ((m2 = re.exec(src))) {
    if ((src[m2.index - 1] || '') === ':') continue;
    push(m2[0]);
  }
  return out.slice(0, 6);
}
/* V-FILEONCE: копим пути файлов за весь ответ ассистента, кнопки рисуем один раз
   на финальном сообщении ("Готово"), а не возле каждого файлового блока. */
function collectTurnFilePaths(paths) {
  for (const p of paths || []) {
    let v = String(p || '').trim();
    if (!v) continue;
    // V-DOCPATH: «file.doc» и «file.doc.docx» — один и тот же файл: оставляем длинный реальный путь
    for (let i = turnFilePaths.length - 1; i >= 0; i--) {
      const e = turnFilePaths[i];
      if (v.length > e.length && v.startsWith(e) && /^\.[A-Za-z0-9]{1,8}$/.test(v.slice(e.length))) turnFilePaths.splice(i, 1);
      else if (e.length > v.length && e.startsWith(v) && /^\.[A-Za-z0-9]{1,8}$/.test(e.slice(v.length))) { v = e; }
    }
    if (!turnFilePaths.includes(v)) turnFilePaths.push(v);
    if (turnFilePaths.length >= 24) break;
  }
}
function takeTurnFilePaths() {
  const out = turnFilePaths.slice(0, 12);
  turnFilePaths = [];
  return out;
}
function attachLeftoverFileActions(chat) {
  if (!turnFilePaths.length) return;
  if (!chat || !Array.isArray(chat.messages)) { turnFilePaths = []; return; }
  for (let i = chat.messages.length - 1; i >= 0; i--) {
    const m = chat.messages[i];
    if (m && m.role === 'assistant' && !m.error && !m.streaming) {
      if (!m.fileActions || !m.fileActions.length) m.fileActions = takeTurnFilePaths();
      else turnFilePaths = [];
      saveDb(); renderMessages();
      return;
    }
  }
  turnFilePaths = [];
}
function fileActionCards(paths) {
  const box = document.createElement('div');
  box.className = 'file-actions';
  box.innerHTML = paths.map((p, i) =>
    `<div class="file-action-card"><span class="file-action-path" title="${esc(p)}">📄 ${esc(p)}</span>` +
    `<button data-file-act="open" data-file-index="${i}">${esc(t('faOpen'))}</button>` +
    `<button data-file-act="folder" data-file-index="${i}">${esc(t('faFolder'))}</button>` +
    `<button data-file-act="attach" data-file-index="${i}">${esc(t('faAttach'))}</button></div>`).join('');
  box.onclick = (e) => {
    const b = e.target.closest('[data-file-act]');
    if (!b) return;
    const p = paths[Number(b.dataset.fileIndex)];
    if (!p) return;
    runFileAction(b.dataset.fileAct, p, b);
  };
  return box;
}

/* V-FILEACT2: кнопки найденного файла вызывали IPC без await и не показывали ошибку, поэтому
   обрезанный путь молча открывал несуществующий файл. Теперь путь берётся из ответа ядра,
   результат проверяется, кнопка блокируется, а причина ошибки показывается пользователю. */
async function runFileAction(act, path, btn) {
  const target = String(path || '').trim();
  if (!target) { toast(t('faBadPath'), 'err'); return; }
  if (btn) btn.disabled = true;
  try {
    if (act === 'attach') { await attachPath(target); return; }
    const channel = act === 'folder' ? 'fs:showInFolder' : 'fs:openPath';
    const r = await rr.invoke(channel, { filePath: target });
    if (!r || r.ok === false || r.error) {
      const seen = (r && (r.path || r.filePath)) || target;
      const why = r && (r.error || r.message);
      toast(why ? String(why) + '\n' + seen : t('faBadPath') + '\n' + seen, 'err');
    }
  } catch (err) {
    toast(String((err && err.message) || err), 'err');
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* V-FILEACT3: папку тоже можно прикрепить — раньше fs:readText отвечал NOT_A_FILE, и пользователь видел ошибку. */
async function attachDirPath(dir, silent) {
  const r = await rr.invoke('fs:list', { dir });
  if (!r || r.ok === false || r.error) { toast((r && (r.error || r.message)) || t('faBadPath'), 'err'); return; }
  const entries = Array.isArray(r.entries) ? r.entries : [];
  const lines = entries.map((e) => (typeof e === 'string' ? e : (e && (e.name || e.path)) || '')).filter(Boolean);
  const content = ('Содержимое папки: ' + (r.path || dir) + '\n\n' + (lines.length ? lines.join('\n') : '(пусто)')).slice(0, attachCharLimit());
  const name = String(r.path || dir).split(/[\\/]/).filter(Boolean).pop() || 'folder';
  pendingAttachments.push({ name: name + '/', size: content.length, path: r.path || dir, kind: 'text', content });
  renderAttachments();
  if (!silent) toast(t('fileAttached') + ': «' + name + '/»');
  try { refreshCatalogMap(r.path || dir).then(() => { try { if (!silent) toast('Каталог картирован — структура проекта теперь в контексте каждого запроса'); } catch (e) {} }); } catch (e) {}
}

function ctxLimitValue() { return chatWeightLimit(); }
/* V-CTXMAX (1.2.97): потолок размера текстового файла был жёсткие «200000 символов» — клиенты
 * жаловались («почему лимит 200000»). Теперь потолок = контекстное окно ТОЙ модели, с которой
 * идёт работа: estimateTokens = симв/4, берём весь бюджет отправки (chatWeightLimit, в нём уже
 * учтён запас 12K под системный промпт и доработку) × 4 символа. Файл такого размера заполнит
 * контекст, но история не «взорвётся» — V-SHRINKHIST сожмёт старое. Мелкие файлы — как раньше. */
function attachCharLimit() {
  try { return Math.max(200000, Math.round(chatWeightLimit() * 4)) }
  catch (e) { return 200000 }
}
function updateCtxPanel() {
  const chat = currentChat();
  const input = $('#composer-input') ? $('#composer-input').value : '';
  const used = chatWeight(chat);
  const limit = ctxLimitValue();
  const cur = estimateTokens(input);
  const msgs = chat ? (chat.messages || []).length : 0;
  const hist = Math.max(4, Number(S().maxHistory) || 20);
  const modelLimit = Number((modelMeta[S().model || ''] || {}).context_length || 0);
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  set('#ctx-input', cur.toLocaleString('ru-RU'));
  set('#ctx-context', used.toLocaleString('ru-RU'));
  set('#ctx-messages', Math.min(msgs, hist) + ' / ' + msgs);
  set('#ctx-total', (used + cur).toLocaleString('ru-RU'));
  set('#ctx-limit', modelLimit ? (Math.round(modelLimit / 1000) + 'K') : limit.toLocaleString('ru-RU'));
  const fill = $('#ctx-bar-fill');
  if (fill) {
    const pct = Math.max(0, Math.min(100, Math.round((used / Math.max(1, modelLimit || limit)) * 100)));
    fill.style.width = pct + '%';
    fill.classList.toggle('warn', pct >= 75);
    fill.classList.toggle('crit', pct >= 92);
  }
  const note = $('#ctx-note');
  if (note) {
    note.textContent = modelLimit
        ? t('ctxNoteModel') + ' ' + modelLimit.toLocaleString('ru-RU') + ' · ' + t('ctxNoteSend') + ' ' + limit.toLocaleString('ru-RU')
      : t('ctxNoteSetting') + ' ' + limit.toLocaleString('ru-RU');
  }
  const ac = $('#ctx-autocompress');
  if (ac) ac.checked = autoCompress;
}
function compressCurrentChat(silent) {
  const chat = currentChat();
  if (!chat || (chat.messages || []).length < 4) { if (!silent) toast(t('ctxTooShort'), 'warn'); return 0; }
  const keep = Math.max(4, Number(S().maxHistory) || 20);
  const before = chat.messages.length;
  if (before <= keep) { if (!silent) toast(t('ctxNothing')); return 0; }
  chat.messages = chat.messages.slice(-keep);
  saveDb(); renderMessages(); updateCtxPanel();
  if (!silent) toast(t('ctxDone') + ' ' + before + ' → ' + chat.messages.length);
  return before - chat.messages.length;
}
async function loadGithubSkills() {
  const r = await rr.invoke('skills:catalog').catch(() => null);
  const list = (r && r.ok && r.skills) || [];
  githubSkills = list.map((s) => ({ n: s.name, s: 'GitHub', d: s.description || '', g: s.body || s.description || '', dir: s.dir }));
  renderSkillsList(list);
}
function renderSkillsList(list) {
  const box = $('#skills-list');
  if (!box) return;
  if (!list.length) { box.innerHTML = '<span class="f-note">' + esc(t('skillsNone')) + '</span>'; return; }
  box.innerHTML = list.map((s) =>
    `<div class="skill-row"><span><b>${esc(s.name)}</b><small>${esc(String(s.description || '').slice(0, 160))}</small></span>` +
    `<button class="btn-ghost sm" data-skill-remove="${esc(s.dir)}" title="${esc(t('skillRemove'))}">✕</button></div>`).join('');
  box.querySelectorAll('[data-skill-remove]').forEach((b) => {
    b.onclick = async () => {
      await rr.invoke('skills:remove', { dir: b.dataset.skillRemove });
      await loadGithubSkills();
    };
  });
}

function openModal(id) { $('#modal-backdrop').classList.remove('hidden'); $(id).classList.remove('hidden'); }
function closeModals() {
  $('#modal-backdrop').classList.add('hidden');
  $$('.modal').forEach((m) => m.classList.add('hidden'));
  stopTopupPolling();
  closeModelPicker();
}

function openSettings() {
  const s = S();
  const setVal = (id, value) => { const el = $(id); if (el) el.value = value; };
  const setText = (id, value) => { const el = $(id); if (el) el.textContent = value; };
  const setChecked = (id, value) => { const el = $(id); if (el) el.checked = !!value; };
  setVal('#set-baseurl', 'https://riskradarai.ru/v1');
  setVal('#set-key', s.apiKey || '');
  setVal('#set-sysprompt', s.systemPrompt || '');
  setVal('#set-temp', s.temperature);
  setText('#set-temp-val', s.temperature);
  setVal('#set-hist', s.maxHistory);
  setText('#set-hist-val', s.maxHistory);
  setVal('#set-rounds', Number(s.maxRounds) || 25);
  setText('#set-rounds-val', Number(s.maxRounds) || 25);
  setVal('#set-maxtok', Number(s.maxTokens) || 0);
  setText('#set-maxtok-val', Number(s.maxTokens) || 0);
  setChecked('#set-images', !!s.sendImages);
  setChecked('#set-token-shield', s.tokenShield !== false);
  const tddEl0 = $('#set-tdd'); if (tddEl0) tddEl0.checked = !!s.tddMode; // 1.2.83
  setChecked('#set-websearch', s.webSearch !== false);
  setChecked('#set-allow-shell', s.allowLocalShell !== false);
  setChecked('#set-shell-auto', s.shellAutoApprove === true);
  setVal('#set-theme', s.theme === 'light' ? 'light' : 'dark');
  setVal('#set-lang', LANG);
  setText('#set-key-status', '');
  loadModels(true).then(() => { const sm = $('#set-model'); if (sm) sm.value = s.model || ''; }).catch(console.warn);
  rr.invoke('app:info').then((i) => {
    const about = $('#about-line');
    if (about) about.textContent = `v${i.version} · UI ${i.uiVersion} · Electron ${i.electron}`;
    const dp = $('#set-dbpath');
    if (dp && i.dbPath) dp.value = i.dbPath;
  }).catch(console.warn);
  if (!$('#settings-modal')) throw new Error('settings modal not found');
  openModal('#settings-modal');
}

async function saveSettings() {
  const s = S();
  s.baseUrl = 'https://riskradarai.ru/v1';
  const keyEl = $('#set-key'); if (keyEl) s.apiKey = keyEl.value.trim();
  const spEl = $('#set-sysprompt'); if (spEl) s.systemPrompt = spEl.value;
  const tempEl = $('#set-temp'); if (tempEl) s.temperature = Number(tempEl.value);
  const histEl = $('#set-hist'); if (histEl) s.maxHistory = Number(histEl.value);
  const rEl = $('#set-rounds'); if (rEl) s.maxRounds = Math.min(60, Math.max(1, Number(rEl.value) || 25));
  const mtEl = $('#set-maxtok'); if (mtEl) s.maxTokens = Math.max(0, Number(mtEl.value) || 0);
  const imgEl = $('#set-images'); if (imgEl) s.sendImages = imgEl.checked;
  const tsEl = $('#set-token-shield'); if (tsEl) s.tokenShield = tsEl.checked;
  const tddEl = $('#set-tdd'); if (tddEl) s.tddMode = tddEl.checked; // 1.2.83
  const wsEl = $('#set-websearch'); if (wsEl) s.webSearch = wsEl.checked;
  const asEl = $('#set-allow-shell'); if (asEl) s.allowLocalShell = asEl.checked;
  const saEl = $('#set-shell-auto'); if (saEl) s.shellAutoApprove = saEl.checked;
  const themeEl = $('#set-theme'); if (themeEl) s.theme = themeEl.value;
  const modelEl = $('#set-model'); if (modelEl && modelEl.value) s.model = modelEl.value;
  const langEl = $('#set-lang');
  const newLang = langEl ? langEl.value : LANG;
  if (newLang && newLang !== LANG) { LANG = newLang; s.lang = newLang; applyI18n(); }
  saveDb(); applyTheme(); updateKeyBadge(); updateBalance().catch(console.warn); updateWorkdirChip();
  const sel = $('#model-select'); if (sel && s.model) sel.value = s.model;
  closeModals();
  toast(t('settingsSaved'));
  renderMessages();
}

function openAbout() {
  rr.invoke('app:info').then((i) => {
    $('#about-body').innerHTML = `
      <div style="text-align:center;padding:8px 0">
        <div style="font-size:40px">⬡</div>
        <div style="font-size:17px;font-weight:800;margin:8px 0 2px">RiskRadar Terminal</div>
        <div style="color:var(--text-dim)">${LANG === 'en' ? 'AI terminal for RiskRadar clients' : 'AI-терминал для клиентов RiskRadar'}</div>
      </div>
      <div class="f-sep"></div>
      <div style="font-size:13px;color:var(--text-dim);line-height:1.8">
        ${LANG === 'en' ? 'App version' : 'Версия приложения'}: <b>${esc(i.version)}</b><br>
        UI (HOT-UI): <b>${esc(i.uiVersion)}</b><br>
        Electron: ${esc(i.electron)} · Node: ${esc(i.node)} · ${esc(i.platform)}<br>
        ${LANG === 'en' ? 'Gateway' : 'Шлюз'}: <b>${esc(S().baseUrl)}</b>
      </div>`;
    openModal('#about-modal');
  });
}

/* ------------------------------ панель ------------------------------ */

function openPanel(page) {
  $('#panel').classList.remove('hidden');
  $('#btn-panel-close').classList.remove('hidden');
  ['files', 'ssh', 'sftp'].forEach((p) => $('#panel-' + p).classList.add('hidden'));
  $('#panel-' + page).classList.remove('hidden');
  if (page === 'files') filesGo(filesState.dir || S().workDir || null);
  if (page === 'ssh') setTimeout(() => sshSession && sshSession.fit && sshSession.fit.fit(), 60);
}
function closePanel() {
  $('#panel').classList.add('hidden');
  $('#btn-panel-close').classList.add('hidden');
}

/* ------------------------------ файлы (локальные) ------------------------------ */

const filesState = { dir: null, entries: [] };

function fileIcon(e) {
  if (e.dir) return '📁';
  const x = e.ext || extOf(e.name);
  if (IMG_EXT.has(x)) return '🖼';
  if (x === 'pdf') return '📕';
  if (['zip','rar','7z','gz','tar'].includes(x)) return '🗜';
  if (['exe','msi'].includes(x)) return '⚙';
  return '📄';
}

async function filesGo(dir) {
  if (!dir) dir = S().workDir || await rr.invoke('fs:home');
  const r = await rr.invoke('fs:list', { dir });
  if (r.error) { toast(r.error, 'err'); return; }
  filesState.dir = r.path; filesState.entries = r.entries;
  renderFiles();
}

function renderFiles() {
  const crumbs = $('#files-crumbs');
  crumbs.innerHTML = '';
  const parts = filesState.dir.split(/[\\/]/);
  let acc = '';
  const root = parts[0] || '/';
  const rootLabel = /^([a-z]:)$/i.test(root) ? root + '\\' : (root === '/' ? '/' : root);
  const mk = (label, path, cur) => {
    const sp = document.createElement('span');
    sp.textContent = label; if (cur) sp.className = 'cur';
    sp.onclick = () => filesGo(path);
    crumbs.appendChild(sp);
  };
  mk(rootLabel || '/', root || '/', parts.length <= 1);
  acc = root;
  for (let i = 1; i < parts.length; i++) {
    if (!parts[i]) continue;
    acc = acc.endsWith('/') || acc.endsWith('\\') ? acc + parts[i] : acc + '/' + parts[i];
    mk(parts[i], acc, i === parts.length - 1);
  }
  crumbs.querySelectorAll('span:not(:last-child)').forEach((s) => s.insertAdjacentHTML('afterend', '<span style="cursor:default">›</span>'));

  const list = $('#files-list');
  list.innerHTML = '';
  if (!filesState.entries.length) list.innerHTML = '<div class="empty-note">' + esc(t('emptyFolder')) + '</div>';
  for (const e of filesState.entries) {
    const row = document.createElement('div');
    row.className = 'frow' + (e.dir ? ' dir' : '');
    row.innerHTML = `<span class="f-ico">${fileIcon(e)}</span>
      <span class="f-name" title="${esc(e.path)}">${esc(e.name)}</span>
      <span class="f-size">${e.dir ? '' : fmtSize(e.size)}</span>
      <button class="f-act" title="${esc(t('attachToChat'))}">＋</button>`;
    row.querySelector('.f-act').onclick = async (ev) => {
      ev.stopPropagation();
      if (e.dir) return;
      await attachPath(e.path);
    };
    row.onclick = () => { e.dir ? filesGo(e.path) : previewFile(e); };
    row.ondblclick = () => { if (!e.dir) rr.invoke('fs:openPath', { filePath: e.path }); };
    list.appendChild(row);
  }
}

async function previewFile(e) {
  currentPreviewFile = Object.assign({ target: 'local' }, e);
  $('#preview-title').textContent = e.name + ' · ' + fmtSize(e.size);
  const ext = e.ext || extOf(e.name);
  const body = $('#preview-body');
  const editBtn = $('#preview-edit');
  body.classList.remove('match-view');
  if (IMG_EXT.has(ext)) {
    if (editBtn) editBtn.classList.add('hidden');
    const r = await rr.invoke('fs:readImage', { filePath: e.path });
    body.innerHTML = r.ok ? `<img src="${r.dataUrl}" style="max-width:100%;border-radius:8px">` : esc(r.error || '—');
  } else {
    if (editBtn) editBtn.classList.toggle('hidden', !TEXT_EXT.has(ext));
    const r = await rr.invoke('fs:readText', { filePath: e.path });
    currentPreviewFile.text = r.ok ? r.content : '';
    body.textContent = r.ok ? r.content.slice(0, 50000) : (r.error || '—');
  }
  openModal('#preview-modal');
}

async function exportChat() {
  const c = currentChat();
  if (!c || !c.messages.length) { toast(t('chatEmpty'), 'warn'); return; }
  const lines = [`# ${c.title || 'RiskRadar'}`, '', `_Export: ${new Date().toLocaleString('ru-RU')} · Model: ${$('#model-select').value || S().model}_`, ''];
  for (const m of c.messages) {
    if (m.role === 'tool') { lines.push('> 🔧 ' + m.label); lines.push('```\n' + (m.content || '') + '\n```'); continue; }
    lines.push(m.role === 'user' ? '## 👤' : '## ⬡ ' + (m.modelName || ''));
    lines.push('');
    lines.push(m.error ? '> ⚠ ' + m.content : m.content || '');
    lines.push('');
  }
  const r = await rr.invoke('fs:saveDialog', { suggestedName: (c.title || 'chat').replace(/[^\\w -]/g, '').slice(0, 40) + '.md', content: lines.join('\\n') });
  if (r && r.ok) toast(t('exportDone') + ': ' + r.path);
  else if (r && r.error) toast(r.error, 'err');
}

function previewChatSnippet(hit) {
  currentPreviewFile = null;
  const text = normalizeNewlines(hit.text || '');
  const lines = text.split('\n');
  const line = Number(hit.line) || 1;
  const start = Math.max(1, line - 8);
  const end = Math.min(lines.length, line + 10);
  const snippetLines = [];
  for (let i = start; i <= end; i++) snippetLines.push({ no: i, text: lines[i - 1], hit: i === line });
  $('#preview-title').textContent = `${hit.label} · line ${line}`;
  const body = $('#preview-body');
  const editBtn = $('#preview-edit'); if (editBtn) editBtn.classList.add('hidden');
  body.classList.add('match-view');
  body.innerHTML = snippetLines.map((row) => `<div class="preview-line${row.hit ? ' hit' : ''}"><span class="ln">${row.no}</span><span class="lc">${highlightSnippet(row.text, hit.query)}</span></div>`).join('');
  openModal('#preview-modal');
}
function currentRemoteCfg(args) {
  if (!args || (!args.profile && !args.host && !args.user)) {
    if (sshSession && sshSession.cfg) return sshSession.cfg;
    if (aiSshSession && aiSshSession.cfg) return aiSshSession.cfg;
  }
  const cfg = resolveSshCfg(args || {});
  return cfg && cfg.error ? null : cfg;
}
async function remoteReadTextFile(path, args) {
  const cfg = currentRemoteCfg(args);
  if (!cfg) return { ok: false, error: t('remoteNeedsSsh') };
  const cmd = `if [ ! -f ${shellQuote(path)} ]; then echo __RR_NOFILE__; exit 14; fi; base64 -w0 < ${shellQuote(path)} 2>/dev/null || base64 < ${shellQuote(path)} | tr -d '\\n'`;
  const r = await sshExecWithRetry(cfg, cmd);
  if (!r.ok) return { ok: false, error: r.output || r.error || 'Remote read failed' };
  const raw = String(r.output || '').trim();
  if (!raw || raw.includes('__RR_NOFILE__')) return { ok: false, error: 'Remote file not found' };
  try { return { ok: true, content: decodeBase64Utf8(raw) }; }
  catch (e) { return { ok: false, error: 'Remote file is not valid UTF-8 text' }; }
}
async function remoteWriteTextFile(path, content, args) {
  const cfg = currentRemoteCfg(args);
  if (!cfg) return { ok: false, error: t('remoteNeedsSsh') };
  const dir = String(path || '').replace(/\/[^/]*$/, '') || '.';
  const b64 = encodeBase64Utf8(content);
  const tag = pickHereDocTag(b64);
  const cmd = `mkdir -p ${shellQuote(dir)} && (base64 -d <<'${tag}' > ${shellQuote(path)} 2>/dev/null || base64 --decode <<'${tag}' > ${shellQuote(path)})\n${b64}\n${tag}`;
  const r = await sshExecWithRetry(cfg, cmd);
  return r && r.ok ? { ok: true, path } : { ok: false, error: (r && (r.output || r.error)) || 'Remote save failed' };
}
function openCodeEditor(hit) {
  codeEditState = Object.assign({ target: 'local' }, hit || {});
  const textEl = $('#code-edit-text');
  const pathEl = $('#code-edit-path');
  const statusEl = $('#code-edit-status');
  if (textEl) textEl.value = (codeEditState && codeEditState.text) || '';
  if (pathEl) pathEl.value = (codeEditState && (codeEditState.file || codeEditState.suggestedPath || codeEditState.path)) || '';
  if (statusEl) {
    statusEl.textContent = codeEditState.target === 'remote'
      ? ('Remote: ' + ((codeEditState.file || codeEditState.path || '').trim() || '—'))
      : (codeEditState.file ? ('Файл: ' + codeEditState.file) : 'Сохраните как новый файл или укажите путь в рабочей папке.');
  }
  openModal('#code-edit-modal');
  setTimeout(() => textEl && textEl.focus(), 40);
}
async function saveCodeEditor(forceDialog) {
  const textEl = $('#code-edit-text');
  const pathEl = $('#code-edit-path');
  const statusEl = $('#code-edit-status');
  if (!textEl) return;
  const content = textEl.value;
  const rawPath = (pathEl && pathEl.value || '').trim();
  if (codeEditState && codeEditState.target === 'remote') {
    if (forceDialog || !rawPath) return toast('Для удалённого файла нужен путь на сервере', 'warn');
    const res = await remoteWriteTextFile(rawPath, content, codeEditState.sshArgs || null);
    if (res && res.ok) {
      if (statusEl) statusEl.textContent = t('remoteSaved') + rawPath;
      toast(t('remoteSaved') + rawPath);
      if (!$('#panel-sftp').classList.contains('hidden')) sftpGo(sftpState.path).catch(console.warn);
    } else {
      const err = (res && res.error) || 'Remote save failed';
      if (statusEl) statusEl.textContent = err;
      toast(err, 'err');
    }
    return;
  }
  if (forceDialog || !rawPath) {
    const suggested = (codeEditState && (codeEditState.file || codeEditState.name)) ? String(codeEditState.file || codeEditState.name).split(/[\\/]/).pop() : 'snippet.txt';
    const r = await rr.invoke('fs:saveDialog', { suggestedName: suggested, content });
    if (r && r.ok) {
      if (statusEl) statusEl.textContent = t('codeSaved') + r.path;
      toast(t('codeSaved') + r.path);
      if (filesState.dir) filesGo(filesState.dir).catch(console.warn);
    }
    return;
  }
  const wd = S().workDir || homeDirCache || await rr.invoke('fs:home');
  const execTarget = resolveScopedLocalTarget(rawPath, wd);
  if (!execTarget.ok) {
    if (statusEl) statusEl.textContent = execTarget.error;
    toast(execTarget.error, 'warn');
    return;
  }
  if (!execTarget.path) {
    const suggestedName = rawPath.replace(/\\/g, '/').split('/').pop() || 'snippet.txt';
    const r = await rr.invoke('fs:saveDialog', { suggestedName, content });
    if (r && r.ok) {
      if (statusEl) statusEl.textContent = t('codeSaved') + r.path;
      toast(t('codeSaved') + r.path);
      if (filesState.dir) filesGo(filesState.dir).catch(console.warn);
    }
    return;
  }
  const res = await localExecWithFallback('write', execTarget, content);
  if (res && res.ok) {
    if (statusEl) statusEl.textContent = t('codeSaved') + (res.path || execTarget.absolute || execTarget.path);
    toast(t('codeSaved') + (res.path || execTarget.absolute || execTarget.path));
    if (filesState.dir) filesGo(filesState.dir).catch(console.warn);
  } else {
    const err = (res && (res.error || res.output)) || 'Save failed';
    if (statusEl) statusEl.textContent = err;
    toast(err, 'err');
  }
}
function recentChatCode(limit) {
  const chat = currentChat();
  if (!chat) return [];
  const out = [];
  const codeRe = /```(?:[\w.+-]+)?\n([\s\S]*?)```/g;
  for (let mi = chat.messages.length - 1; mi >= 0 && out.length < (limit || 6); mi--) {
    const m = chat.messages[mi];
    if (!m || !m.content || m.role === 'tool') continue;
    const blocks = [];
    let match;
    while ((match = codeRe.exec(m.content))) blocks.push(match[1]);
    const candidates = blocks.length ? blocks : [/\n/.test(m.content) ? m.content : ''];
    for (const text of candidates) {
      const norm = normalizeNewlines(text || '').trim();
      if (!norm || norm.length < 20) continue;
      out.push({ source: 'chat', role: m.role, label: `Чат · ${m.role === 'assistant' ? (m.modelName || 'RiskRadar') : (LANG === 'en' ? 'You' : 'Вы')}`, line: 1, query: '', snippet: norm.split('\n').slice(0, 8).map((ln, i) => `${i + 1}: ${ln}`).join('\n'), text: norm });
      if (out.length >= (limit || 6)) break;
    }
  }
  return out;
}
function searchChatCode(query) {
  const q = String(query || '').trim().toLowerCase();
  const chat = currentChat();
  if (!q || !chat) return [];
  const hits = [];
  const codeRe = /```(?:[\w.+-]+)?\n([\s\S]*?)```/g;
  for (let mi = chat.messages.length - 1; mi >= 0; mi--) {
    const m = chat.messages[mi];
    if (!m || !m.content || m.role === 'tool') continue;
    const blocks = [];
    let match;
    while ((match = codeRe.exec(m.content))) blocks.push(match[1]);
    const candidates = blocks.length ? blocks : [m.content];
    for (const text of candidates) {
      const norm = normalizeNewlines(text);
      const lower = norm.toLowerCase();
      let idx = 0;
      let perMsg = 0;
      while ((idx = lower.indexOf(q, idx)) >= 0 && hits.length < 30) {
        const line = norm.slice(0, idx).split('\n').length;
        const lines = norm.split('\n');
        const start = Math.max(1, line - 2);
        const end = Math.min(lines.length, line + 2);
        const snippet = lines.slice(start - 1, end).map((ln, i) => `${start + i}: ${ln}`).join('\n');
        hits.push({ source: 'chat', role: m.role, label: `Чат · ${m.role === 'assistant' ? (m.modelName || 'RiskRadar') : (LANG === 'en' ? 'You' : 'Вы')}`, line, query, snippet, text: norm });
        idx += q.length || 1;
        perMsg += 1;
        if (perMsg >= 4) break;
      }
      if (hits.length >= 30) break;
    }
    if (hits.length >= 30) break;
  }
  return hits;
}
async function runCodeSearch() {
  const q = ($('#code-search-query').value || '').trim();
  const status = $('#code-search-status');
  const box = $('#code-search-results');
  if (!status || !box) return;
  box.innerHTML = '';
  if (!q) {
    const recent = recentChatCode(6);
    status.textContent = recent.length ? 'Последний код из текущего чата' : t('codeSearchNone');
    recent.forEach((hit) => {
      const el = document.createElement('div');
      el.className = 'search-hit';
      el.innerHTML = `<div class="search-hit-head"><span class="search-hit-file">${esc(hit.label)}</span><span class="search-hit-line">latest</span></div><div class="search-hit-snippet">${renderSearchSnippetHtml(hit.snippet, '')}</div><div class="search-hit-actions"></div>`;
      const actions = el.querySelector('.search-hit-actions');
      const b1 = document.createElement('button'); b1.className = 'btn-ghost sm'; b1.textContent = t('codeOpenSnippet'); b1.onclick = () => previewChatSnippet(hit);
      const b2 = document.createElement('button'); b2.className = 'btn-ghost sm'; b2.textContent = t('codeEditAction'); b2.onclick = () => openCodeEditor(hit);
      const b3 = document.createElement('button'); b3.className = 'btn-ghost sm'; b3.textContent = t('mCopy'); b3.onclick = () => navigator.clipboard.writeText(hit.text || '');
      actions.appendChild(b1); actions.appendChild(b2); actions.appendChild(b3);
      box.appendChild(el);
    });
    return;
  }
  status.textContent = '…';
  const chatHits = searchChatCode(q);
  let fileHits = [];
  try {
    const baseDir = S().workDir || homeDirCache || await rr.invoke('fs:home');
    fileHits = await searchLocalCode(q, baseDir);
  } catch (e) { console.warn('[RR] code search files failed', e); }
  window.__RR_LAST_SEARCH__ = { chatHits, fileHits };
  const total = chatHits.length + fileHits.length;
  if (!total) {
    status.textContent = t('codeSearchNone');
    return;
  }
  status.textContent = `${t('codeSearchFound')}${total} · чат ${chatHits.length} · файлы ${fileHits.length}`;
  const renderHit = (hit, mode) => {
    const el = document.createElement('div');
    el.className = 'search-hit';
    const lineLabel = mode === 'chat' ? `chat line ${hit.line}` : `line ${hit.line}`;
    el.innerHTML = `<div class="search-hit-head"><span class="search-hit-file">${esc(hit.label || hit.file)}</span><span class="search-hit-line">${esc(lineLabel)}</span></div><div class="search-hit-snippet">${renderSearchSnippetHtml(hit.snippet, q)}</div><div class="search-hit-actions"></div>`;
    const actions = el.querySelector('.search-hit-actions');
    if (mode === 'chat') {
      const b1 = document.createElement('button'); b1.className = 'btn-ghost sm'; b1.textContent = t('codeOpenSnippet'); b1.onclick = () => previewChatSnippet(hit);
      const b2 = document.createElement('button'); b2.className = 'btn-ghost sm'; b2.textContent = t('codeEditAction'); b2.onclick = () => openCodeEditor(hit);
      const b3 = document.createElement('button'); b3.className = 'btn-ghost sm'; b3.textContent = t('mCopy'); b3.onclick = () => navigator.clipboard.writeText(hit.text || '');
      actions.appendChild(b1); actions.appendChild(b2); actions.appendChild(b3);
    } else {
      const b1 = document.createElement('button'); b1.className = 'btn-ghost sm'; b1.textContent = t('codeOpenSnippet'); b1.onclick = () => openSnippetAt(hit.file, q, hit.line);
      const b2 = document.createElement('button'); b2.className = 'btn-ghost sm'; b2.textContent = t('codeEditAction'); b2.onclick = async () => {
        const r = await rr.invoke('fs:readText', { filePath: hit.file });
        if (r && r.ok) openCodeEditor({ text: r.content, file: hit.file, suggestedPath: hit.file, name: hit.name || hit.file.split(/[\\/]/).pop() });
        else toast((r && r.error) || 'Open failed', 'err');
      };
      const b3 = document.createElement('button'); b3.className = 'btn-ghost sm'; b3.textContent = t('codeOpenFile'); b3.onclick = () => rr.invoke('fs:openPath', { filePath: hit.file });
      const b4 = document.createElement('button'); b4.className = 'btn-accent sm'; b4.textContent = t('attachToChat'); b4.onclick = async () => { await attachPath(hit.file, true); toast(t('fileAttached')); };
      actions.appendChild(b1); actions.appendChild(b2); actions.appendChild(b3); actions.appendChild(b4);
    }
    box.appendChild(el);
  };
  chatHits.forEach((hit) => renderHit(hit, 'chat'));
  fileHits.forEach((hit) => renderHit(hit, 'file'));
}
function openCodeSearch() {
  const q = $('#code-search-query');
  const status = $('#code-search-status');
  const res = $('#code-search-results');
  if (q) q.value = '';
  if (status) status.textContent = '';
  if (res) res.innerHTML = '';
  openModal('#code-search-modal');
  setTimeout(() => { if (q) q.focus(); runCodeSearch().catch(console.warn); }, 40);
}
/* V-BROWSER: встроенный браузер — терминал умеет открывать и просматривать ссылки,
 * как обычный браузер, а не только тянуть текст через fetch. */
let browserNavReady = false;
function browserEl() { return $('#br-view'); }
function browserAvailable() {
  const v = browserEl();
  return !!(v && typeof v.loadURL === 'function');
}
function normalizeBrowserUrl(raw) {
  let u = String(raw || '').trim();
  if (!u) return '';
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(u)) return u;
  if (/^[a-z][a-z0-9+.-]*:/i.test(u)) return u;      // mailto:, tel: и т.п.
  return 'https://' + u;
}
function setBrowserStatus(text) { const el = $('#br-status'); if (el) el.textContent = String(text || '—'); }
function syncBrowserNav() {
  const v = browserEl();
  if (!v) return;
  try {
    const back = $('#br-back'), fwd = $('#br-fwd');
    if (back) back.disabled = !v.canGoBack();
    if (fwd) fwd.disabled = !v.canGoForward();
  } catch (e) {}
}
function browserWired() {
  const v = browserEl();
  if (!v || browserNavReady) return;
  browserNavReady = true;
  const urlInput = $('#br-url');
  const onNav = (e) => {
    const u = (e && e.url) || '';
    if (u && urlInput && document.activeElement !== urlInput) urlInput.value = u;
    setBrowserStatus(u || '—');
    syncBrowserNav();
  };
  try {
    v.addEventListener('did-navigate', onNav);
    v.addEventListener('did-navigate-in-page', onNav);
    v.addEventListener('did-start-loading', () => setBrowserStatus('загрузка…'));
    v.addEventListener('did-stop-loading', () => { setBrowserStatus((v.getURL && v.getURL()) || '—'); syncBrowserNav(); });
    v.addEventListener('page-title-updated', (e) => { const t = (e && e.title) || ''; setBrowserStatus(t ? (t + ' — ' + ((v.getURL && v.getURL()) || '')) : '—'); });
    v.addEventListener('did-fail-load', (e) => { if (e && e.errorCode !== -3) setBrowserStatus('Не удалось загрузить: ' + ((e && e.errorDescription) || e.errorCode)); });
    v.addEventListener('new-window', (e) => { if (e && e.url) { if (e.preventDefault) e.preventDefault(); openBrowser(e.url); } });
  } catch (e) { console.warn('[RR] browser events', e); }
}
function openBrowser(rawUrl) {
  const url = normalizeBrowserUrl(rawUrl);
  const panel = $('#browser-panel');
  if (!panel) return { ok: false, error: 'нет панели браузера' };
  if (!/^https?:\/\//i.test(url)) return { ok: false, error: 'нужен адрес http/https' };
  if (!browserAvailable()) {           // <webview> недоступен — открываем отдельным окном
    rr.invoke('browser:openWindow', { url: url }).catch(() => openExternalUrl(url));
    return { ok: true, url: url, via: 'window' };
  }
  panel.classList.remove('hidden');
  browserWired();
  const input = $('#br-url');
  if (input) input.value = url;
  setBrowserStatus('загрузка…');
  try {
    browserEl().loadURL(url).catch((e) => setBrowserStatus('Ошибка: ' + ((e && e.message) ? e.message : e)));
  } catch (e) {
    rr.invoke('browser:openWindow', { url: url }).catch(() => openExternalUrl(url));
    return { ok: true, url: url, via: 'window' };
  }
  setTimeout(syncBrowserNav, 500);
  return { ok: true, url: url, via: 'panel' };
}
function closeBrowser() {
  const panel = $('#browser-panel');
  if (panel) panel.classList.add('hidden');
  try { const v = browserEl(); if (v && v.stop) v.stop(); } catch (e) {}
}
function openBrowserResult(url) {
  const r = openBrowser(url);
  if (r.ok) return { ok: true, output: 'Страница открыта во встроенном браузере: ' + r.url + (r.via === 'window' ? ' (отдельным окном)' : '') };
  return { ok: false, output: 'Не удалось открыть ' + url + ': ' + (r.error || 'неизвестная ошибка') };
}
function initBrowserUi() {
  browserWired();
  const urlInput = $('#br-url');
  const go = () => { const u = normalizeBrowserUrl(urlInput && urlInput.value); if (u) openBrowser(u); };
  if (urlInput) {
    urlInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); go(); }
      if (e.key === 'Escape') { e.preventDefault(); closeBrowser(); }
    });
  }
  const back = $('#br-back'); if (back) back.onclick = () => { try { browserEl().goBack(); } catch (e) {} };
  const fwd = $('#br-fwd'); if (fwd) fwd.onclick = () => { try { browserEl().goForward(); } catch (e) {} };
  const rel = $('#br-reload'); if (rel) rel.onclick = () => { try { browserEl().reload(); } catch (e) {} };
  const goBtn = $('#br-go'); if (goBtn) goBtn.onclick = go;
  const ext = $('#br-external');
  if (ext) ext.onclick = () => { const v = browserEl(); const u = (v && v.getURL && v.getURL()) || (urlInput && urlInput.value); if (u) openExternalUrl(u); };
  const closeBtn = $('#br-close'); if (closeBtn) closeBtn.onclick = closeBrowser;
}
function openModelBrowser() {
  renderModelBrowser();
  const pop = $('#model-picker-pop');
  if (pop) {
    // 1.2.75: попап над чипом модели (чип — в нижней строке карточки)
    if (pop.classList.contains('hidden')) {
      const btn = $('#model-picker-btn'), wrap = $('#composer-wrap');
      if (btn && wrap) {
        const w = wrap.clientWidth || 600;
        pop.style.left = Math.max(14, Math.min(btn.offsetLeft, w - 300)) + 'px';
        pop.style.bottom = (wrap.clientHeight - (btn.offsetTop + btn.offsetHeight) + 12) + 'px';
      }
    }
    pop.classList.toggle('hidden');
  }
  const searching = !!(pop && !pop.classList.contains('hidden'));
  const field = searching ? $('#model-picker-search') : $('#model-search');
  if (field) setTimeout(() => field.focus(), 40);
}

/* ------------------------------ SSH ------------------------------ */

function renderSshProfiles() {
  const box = $('#ssh-profiles');
  box.innerHTML = '';
  if (!db.sshProfiles.length) return;
  for (const p of db.sshProfiles) {
    const row = document.createElement('div');
    row.className = 'profile-row';
    row.innerHTML = `<div><div class="p-name">${esc(p.name || p.host)}</div><div class="p-host">${esc(p.user || '')}@${esc(p.host)}:${esc(p.port || 22)}</div></div>
      <span class="spacer"></span><button title="${esc(t('mDel'))}">🗑</button>`;
    row.querySelector('button').onclick = (e) => {
      e.stopPropagation();
      db.sshProfiles = db.sshProfiles.filter((x) => x !== p);
      saveDb(); renderSshProfiles();
    };
    row.onclick = () => {
      $('#ssh-name').value = p.name || '';
      $('#ssh-host').value = p.host || '';
      $('#ssh-port').value = p.port || 22;
      $('#ssh-user').value = p.user || '';
      $('#ssh-authtype').value = p.privateKeyPath ? 'key' : 'password';
      $('#ssh-keypath').value = p.privateKeyPath || '';
      $('#ssh-pass').value = ''; $('#ssh-passphrase').value = '';
      sshAuthTypeToggle();
      doSshConnect(readSshForm(p));
    };
    box.appendChild(row);
  }
}

function readSshForm(pre) {
  return {
    name: $('#ssh-name').value.trim() || $('#ssh-host').value.trim(),
    host: ($('#ssh-host').value || (pre && pre.host) || '').trim(),
    port: Number($('#ssh-port').value) || 22,
    username: ($('#ssh-user').value || (pre && pre.user) || '').trim(),
    password: $('#ssh-pass').value || (pre && pre.password) || '',
    privateKeyPath: $('#ssh-keypath').value.trim() || (pre && pre.privateKeyPath) || '',
    passphrase: $('#ssh-passphrase').value || '',
    save: $('#ssh-save').checked,
    _pre: pre
  };
}

function sshAuthTypeToggle() {
  const tp = $('#ssh-authtype').value;
  $('#ssh-pass-row').classList.toggle('hidden', tp !== 'password');
  $('#ssh-key-row').classList.toggle('hidden', tp !== 'key');
  $('#ssh-passphrase-row').classList.toggle('hidden', tp !== 'key');
}

async function doSshConnect(cfg) {
  if (!cfg.host || !cfg.username) { toast('Host / Login?', 'warn'); return; }
  const btn = $('#ssh-connect-btn');
  btn.disabled = true; btn.textContent = '…';
  try {
    const r = await rr.invoke('ssh:connect', { host: cfg.host, port: cfg.port, username: cfg.username, password: cfg.password, privateKeyPath: cfg.privateKeyPath, passphrase: cfg.passphrase, cols: 100, rows: 30 });
    if (!r.ok) throw new Error(r.error || 'no conn');
    if (cfg.save) {
      const prof = { name: cfg.name, host: cfg.host, port: cfg.port, user: cfg.username, privateKeyPath: cfg.privateKeyPath };
      db.sshProfiles = db.sshProfiles.filter((p) => !(p.host === prof.host && p.user === prof.user));
      db.sshProfiles.unshift(prof); saveDb(); renderSshProfiles();
    }
    startTerm(r.id, cfg);
    toast('SSH: ' + cfg.host + ' ✓');
  } catch (e) {
    toast('SSH: ' + (e.message || e), 'err');
  } finally {
    btn.disabled = false; btn.textContent = t('connect2');
  }
}

// V-PASTEKEY (1.2.89): наблюдатель НАТИВНОЙ вставки. Ставится на старте (capture), а не
// только при открытии SSH — иначе флаг __rrNativePasteAt никогда не выставлялся, ручной
// фолбэк вставлял второй раз и \\x16 лезло в PTY. nativePasteFor(el,t0) — была ли нативная
// вставка по этому элементу (или его родителю/потомку) после t0.
window.__rrPasteSeen = { t: 0, el: null };
document.addEventListener('paste', (e) => { try { window.__rrPasteSeen = { t: Date.now(), el: e.target || null }; } catch (x) {} }, true);
window.__rrNativePasteAt = () => (window.__rrPasteSeen && window.__rrPasteSeen.t) || 0;
window.nativePasteFor = (el, t0) => {
  try {
    const pv = window.__rrPasteSeen;
    if (!pv || !pv.el || !el) return false;
    if (pv.t < (t0 || 0) - 60) return false;
    return pv.el === el || (el.contains && el.contains(pv.el)) || (pv.el.contains && pv.el.contains(el));
  } catch (e) { return false; }
};

function startTerm(id, cfg) {
  sshSession = { id, term: null, fit: null, cfg };
  $('#ssh-idle').classList.add('hidden');
  $('#ssh-live').classList.remove('hidden');
  $('#ssh-conn-label').textContent = (cfg.username || cfg.user || 'user') + '@' + cfg.host;

  const term = new Terminal({
    fontFamily: '"Cascadia Mono", Consolas, "SF Mono", Menlo, monospace',
    fontSize: 12.5, cursorBlink: true, theme: {
      background: '#090c10', foreground: '#dbe4ee',
      cursor: '#34d399', selectionBackground: '#10b98155'
    }
  });
  const fit = new FitAddon.FitAddon();
  term.loadAddon(fit);
  term.open($('#ssh-term'));
  fit.fit();
  term.focus();
  sshSession.term = term; sshSession.fit = fit;

  term.onData((d) => rr.invoke('ssh:write', { id, data: btoa(unescape(encodeURIComponent(d))) }));
  window.addEventListener('resize', () => { try { fit.fit(); rr.invoke('ssh:resize', { id, cols: term.cols, rows: term.rows }); } catch (e) {} });
  const obs = new ResizeObserver(() => { try { fit.fit(); rr.invoke('ssh:resize', { id, cols: term.cols, rows: term.rows }); } catch (e) {} });
  obs.observe($('#ssh-term'));
  sshSession._obs = obs;
  rr.invoke('ssh:resize', { id, cols: term.cols, rows: term.rows });

  // 1.2.87 V-SSHPASTE2: вставка в SSH-консоль с клавиатуры (Cmd+V/Ctrl+V) — с защитой
  // от двойной вставки: если нативный paste отработал (Windows/Linux), ручной фолбэк
  // пропускается. Многострочный текст → \r (по одной команде за раз).
  const sshTermEl = $('#ssh-term');
  if (sshTermEl) {
    sshTermEl.addEventListener('click', () => {
      try { if (!window.getSelection || !String(window.getSelection()).length) term.focus(); } catch (e) {}
    });
  }
  if (!window.__rrSshPasteWired) {
    window.__rrSshPasteWired = true;
    document.addEventListener('keydown', (e) => {
      try {
        if (!((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v')) return;
        if (!sshSession || !sshSession.term) return;
        const live = $('#ssh-live');
        if (!live || live.classList.contains('hidden')) return;
        const ae = document.activeElement;
        if (ae && ae.id === 'composer-input') return; // в чате — вставка в чат
        const inTerm = !!(ae && ae.closest && ae.closest('.xterm'));
        if (!inTerm && !(live.contains(ae) || ae === document.body || ae === document.documentElement)) return;
        const t0 = Date.now();
        (async () => {
          await new Promise(r => setTimeout(r, 140)); // ждём нативный paste-ит
          if (inTerm && window.nativePasteFor(ae, t0)) return; // xterm сам вставил (нативный paste по textarea) — не дублируем
          let t2 = '';
          try { t2 = await navigator.clipboard.readText(); } catch (e2) {}
          if (!t2) {
            try {
              const r = await rr.invoke('sys:exec', { cmd: IS_WIN ? 'powershell -NoProfile -Command Get-Clipboard' : 'pbpaste', cwd: '', timeoutMs: 6000 });
              if (r && r.ok) t2 = r.stdout || '';
            } catch (e3) {}
          }
          if (t2 && t2.length) { try { sshSession.term.paste(t2.replace(/\r\n?/g, '\r')); } catch (e4) {} }
        })();
      } catch (e2) {}
    });
  }
  try { setTimeout(() => { try { term.focus(); } catch (e) {} }, 60); } catch (e) {}

}


// 1.2.87 V-MACPASTE1: в macOS без Edit-меню в нативном процессе Cmd+V не доходит до
// полей (не вставить ключ/текст в чат). Фолбэк: по ⌘V читаем буфер (clipboard.readText,
// затем pbpaste через sys:exec) и вставляем в активное поле сами — если нативная вставка
// НЕ сработала в течение 140 мс. Работает для input/textarea/contenteditable, кроме .xterm
// (терминал обрабатывает сам) и composer-input (у него свой путь с файлами).
(function () {
  try {
    if (window.__rrMacPasteWired) return;
    window.__rrMacPasteWired = true;
    const isMacUi = () => IS_DARWIN || /Mac|iPhone|iPad|iPod/i.test(String(navigator.platform || '')) || /Mac OS X/i.test(String(navigator.userAgent || ''));
    document.addEventListener('keydown', (e) => {
      try {
        if (!isMacUi()) return;
        if (!e.metaKey || e.ctrlKey || e.altKey) return;
        if (String(e.key || '').toLowerCase() !== 'v') return;
        const ae = document.activeElement;
        if (!ae) return;
        if (ae.closest && ae.closest('.xterm')) return; // SSH-консоль: свой обработчик
        const tag = String(ae.tagName || '').toLowerCase();
        const editable = tag === 'textarea' || tag === 'select'
          || (tag === 'input' && !/^(checkbox|radio|button|submit|file|range|color)$/i.test(String(ae.type || '')))
          || ae.isContentEditable;
        if (!editable) return;
        if (ae.id === 'composer-input') return; // для чата есть paste-слушатель с файлами
        const t0 = Date.now();
        setTimeout(async () => {
          try {
            if (window.nativePasteFor(ae, t0)) return; // нативная вставка по этому полю уже сработала
            let txt = '';
            try { txt = await navigator.clipboard.readText(); } catch (e1) {}
            if (!txt) {
              try { const r = await rr.invoke('sys:exec', { cmd: 'pbpaste', cwd: '', timeoutMs: 6000 }); if (r && r.ok) txt = r.stdout || ''; } catch (e2) {}
            }
            if (!txt) return;
            try { ae.focus(); } catch (e3) {}
            let done = false;
            try { done = document.execCommand('insertText', false, txt); } catch (e4) {}
            if (!done && typeof ae.setSelectionRange === 'function') {
              const s0 = ae.selectionStart, e0 = ae.selectionEnd;
              ae.value = String(ae.value || '').slice(0, s0) + txt + String(ae.value || '').slice(e0);
              try { ae.setSelectionRange(s0 + txt.length, s0 + txt.length); } catch (e5) {}
              ae.dispatchEvent(new Event('input', { bubbles: true }));
            } else if (!done && ae.isContentEditable) {
              const sel = window.getSelection();
              if (sel && sel.rangeCount) { const rg = sel.getRangeAt(0); rg.deleteContents(); rg.insertNode(document.createTextNode(txt)); }
            }
          } catch (e6) {}
        }, 140);
      } catch (e7) {}
    });
    // composer-input: текст в чат — отдельная дорожка (вставка без потери картинок)
    document.addEventListener('keydown', (e) => {
      try {
        if (!isMacUi()) return;
        if (!e.metaKey || e.ctrlKey || e.altKey) return;
        if (String(e.key || '').toLowerCase() !== 'v') return;
        const ae = document.activeElement;
        if (!ae || ae.id !== 'composer-input') return;
        const t0 = Date.now();
        setTimeout(async () => {
          try {
            if (window.nativePasteFor(ae, t0)) return; // нативный paste по composer уже вставил
            let txt = '';
            try { txt = await navigator.clipboard.readText(); } catch (e1) {}
            if (!txt) {
              try { const r = await rr.invoke('sys:exec', { cmd: 'pbpaste', cwd: '', timeoutMs: 6000 }); if (r && r.ok) txt = r.stdout || ''; } catch (e2) {}
            }
            if (!txt) return;
            const s0 = ae.selectionStart, e0 = ae.selectionEnd;
            ae.value = String(ae.value || '').slice(0, s0) + txt + String(ae.value || '').slice(e0);
            try { ae.setSelectionRange(s0 + txt.length, s0 + txt.length); } catch (e3) {}
            ae.dispatchEvent(new Event('input', { bubbles: true }));
          } catch (e4) {}
        }, 140);
      } catch (e5) {}
    });
  } catch (e) {}
})();

function sshWriteToTerm(b64) {
  if (!sshSession || !sshSession.term) return;
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  sshSession.term.write(bytes);
}

function sshTeardown(err) {
  if (!sshSession) return;
  try { sshSession._obs.disconnect(); } catch (e) {}
  try { sshSession.term.dispose(); } catch (e) {}
  $('#ssh-term').innerHTML = '';
  sshSession = null;
  $('#ssh-live').classList.add('hidden');
  $('#ssh-idle').classList.remove('hidden');
  $('#panel-sftp').classList.add('hidden');
  $('#panel-ssh').classList.remove('hidden');
  if (err) toast('SSH: ' + err, 'err');
}

/* SFTP */
const sftpState = { path: '/' };

async function openRemoteEditorEntry(e) {
  const r = await remoteReadTextFile(e.path, null);
  if (!r.ok) return toast(r.error || 'Remote read failed', 'err');
  openCodeEditor({ text: r.content, file: e.path, path: e.path, name: e.name, target: 'remote', sshArgs: null });
}

async function sftpGo(dir) {
  if (!sshSession) return;
  const r = await rr.invoke('ssh:sftpList', { id: sshSession.id, dir: dir || sftpState.path });
  if (r.error) { toast('SFTP: ' + r.error, 'err'); return; }
  sftpState.path = r.path || dir;
  $('#sftp-path').value = sftpState.path;
  const list = $('#sftp-list');
  list.innerHTML = '';
  if (!r.entries.length) list.innerHTML = '<div class="empty-note">' + esc(t('emptyDir')) + '</div>';
  for (const e of r.entries) {
    const row = document.createElement('div');
    row.className = 'frow' + (e.dir ? ' dir' : '');
    const canEdit = !e.dir && TEXT_EXT.has(e.ext || extOf(e.name));
    row.innerHTML = `<span class="f-ico">${e.dir ? '📁' : '📄'}</span>
      <span class="f-name" title="${esc(e.path)}">${esc(e.name)}</span>
      <span class="f-size">${e.dir ? '' : fmtSize(e.size)}</span>
      ${canEdit ? '<button class="f-act f-edit" title="✏">✏</button>' : ''}
      ${!e.dir ? '<button class="f-act f-dl" title="⬇">⬇</button>' : ''}`;
    const dlBtn = row.querySelector('.f-dl');
    if (dlBtn) dlBtn.onclick = async (ev) => {
      ev.stopPropagation();
      const name = e.name.split('/').pop();
      const s = await rr.invoke('fs:saveDialog', { suggestedName: name, content: '' });
      if (!s || s.canceled || s.error) return;
      const d = await rr.invoke('ssh:sftpDownload', { id: sshSession.id, remote: e.path, local: s.path });
      toast(d.ok ? '✓ ' + s.path : ('SFTP: ' + d.error), d.ok ? '' : 'err');
    };
    const editBtn = row.querySelector('.f-edit');
    if (editBtn) editBtn.onclick = async (ev) => { ev.stopPropagation(); await openRemoteEditorEntry(e); };
    row.onclick = () => { if (e.dir) sftpGo(e.path); else if (canEdit) openRemoteEditorEntry(e); };
    list.appendChild(row);
  }
}

/* ------------------------------ тосты/события ------------------------------ */

let _agentConfirmCurrent = null;
function showAgentConfirm(d) {
  try {
    _agentConfirmCurrent = { id: d.id, hash: d.hash };
    const pre = document.querySelector('#agent-confirm-preview');
    if (pre) pre.textContent = JSON.stringify(d.preview || d, null, 2);
    const ok = document.querySelector('#agent-confirm-ok');
    if (ok) ok.onclick = () => {
      const cur = _agentConfirmCurrent;
      closeModals();
      if (!cur) return;
      rr.invoke('agent:confirm', cur).then((r) => {
        toast(r && r.ok ? 'Операция выполнена' : ('Ошибка: ' + ((r && r.error) || 'unknown')));
      }).catch((e) => toast('Ошибка: ' + e));
    };
    const deny = document.querySelector('#agent-confirm-deny');
    if (deny) deny.onclick = () => closeModals();
    openModal('#agent-confirm-modal');
  } catch (e) { console.error(e); }
}

function toast(text, kind, action, actionFn) {
  const el = document.createElement('div');
  el.className = 'toast ' + (kind || '');
  el.innerHTML = `<span style="flex:1">${esc(text)}</span>`;
  if (action) {
    const b = document.createElement('button');
    b.textContent = action;
    b.onclick = () => { el.remove(); actionFn && actionFn(); };
    el.appendChild(b);
  }
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; setTimeout(() => el.remove(), 400); }, action ? 20000 : 4200);
  return el;
}

function setupUpdaterEvents() {
  let progToast = null;
  rr.on('upd:event', (e) => {
    if (e.type === 'available') toast('v' + (e.version || '?') + ' ⬇');
    else if (e.type === 'progress') {
      if (!progToast) progToast = toast((e.percent || 0) + '%');
      else progToast.querySelector('span').textContent = (e.percent || 0) + '%';
    } else if (e.type === 'downloaded') {
      toast('✓ v' + (e.version || ''), '', '↻', () => rr.invoke('app:installUpdate').catch(console.error));
    } else if (e.type === 'error') { console.warn('upd:', e.message); }
  });
  rr.on('ui:updated', (d) => toast('UI → ' + d.version));
}

function setupSshEvents() {
  rr.on('ssh:event', (ev) => {
    if (ev.event === 'data') {
      if (sshSession && ev.id === sshSession.id) sshWriteToTerm(ev.data);
      if (aiSshPending && ev.id === aiSshPending.id) {
        try {
          aiSshPending.buffer += stripAnsi(decodeBase64Utf8(ev.data || ''));
          const re = new RegExp(`${aiSshPending.marker} BEGIN\\n([\\s\\S]*?)\\n${aiSshPending.marker} EXIT (\\d+)`);
          const m = aiSshPending.buffer.match(re);
          if (m) {
            const code = Number(m[2] || 0);
            const output = String(m[1] || '').trim();
            if (code === 0) aiSshPending.resolve({ ok: true, output, code });
            else aiSshPending.reject(new Error(output || ('Remote command failed, exit=' + code)));
          }
        } catch (e) {}
      }
    }
    if (ev.event === 'closed') {
      if (sshSession && ev.id === sshSession.id) sshTeardown(ev.error);
      if (aiSshSession && ev.id === aiSshSession.id) aiSshSession = null;
      if (aiSshPending && ev.id === aiSshPending.id) {
        aiSshPending.reject(new Error(ev.error || 'SSH session closed'));
      }
    }
  });
}

/* ------------------------------ композер UI ------------------------------ */

function autosize() {
  const ta = $('#composer-input');
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 220) + 'px';
}

/* ------------------------------ init ------------------------------ */

async function boot() {
  try {
    db = await rr.invoke('db:get');
  } catch (e) {
    console.warn('[RR] db:get failed', e);
    db = { settings: {}, chats: [], sshProfiles: [] };
  }
  if (!db || typeof db !== 'object') db = { settings: {}, chats: [], sshProfiles: [] };
  if (!db.settings) db.settings = {};
  if (!db.chats) db.chats = [];
  if (!db.sshProfiles) db.sshProfiles = [];
  // 1.2.85 V-STATS-PERSIST: восстанавливаем дневную статистику (не сбрасывается после рестарта)
  try {
    const k0 = new Date(); const k0s = k0.getFullYear() + '-' + String(k0.getMonth() + 1).padStart(2, '0') + '-' + String(k0.getDate()).padStart(2, '0');
    if (db.stats && db.stats.day === k0s) {
      sessionStats.reqs = Number(db.stats.reqs) || 0;
      sessionStats.inTok = Number(db.stats.inTok) || 0;
      sessionStats.outTok = Number(db.stats.outTok) || 0;
      sessionStats.tsSaved = Number(db.stats.tsSaved) || 0;
      sessionRequests = Number(db.stats.reqCounter) || sessionStats.reqs;
    } else { db.stats = null; }
  } catch (e) {}
  // миграция и дефолты
  let migrated = false;
  if (Number(S().temperature) === 0.7 || S().temperature == null || Number.isNaN(Number(S().temperature))) { S().temperature = 0; migrated = true; }
  if (!Number(S().maxHistory)) { S().maxHistory = 24; migrated = true; } // V-CTXBIG: прежний навязанный 8 резал задачи «частями» — поднимаем до 24
  else if (Number(S().maxHistory) === 8) { S().maxHistory = 24; migrated = true; }
  if (Number(S().chatWeightLimit) === 32000) { S().chatWeightLimit = 0; migrated = true; } // V-CTXBIG: отпускаем старый фикс. 32K — бюджет считается от окна модели
  if (!Number(S().maxRounds)) { S().maxRounds = 25; migrated = true; }   // V-MEMFIX: раундов агентного цикла
  if (S().maxTokens == null || Number.isNaN(Number(S().maxTokens))) { S().maxTokens = 0; migrated = true; }  // V-MEMFIX: 0 = авто
  if (typeof S().webSearch !== 'boolean') { S().webSearch = true; migrated = true; }  // V-WS-UI: веб-поиск включён
  if (typeof S().allowLocalShell !== 'boolean') { S().allowLocalShell = true; migrated = true; }   // V-LOCALSHELL: локальные команды включены
  if (typeof S().shellAutoApprove !== 'boolean') { S().shellAutoApprove = false; migrated = true; } // подтверждение по умолчанию
  if (!S().theme) { S().theme = 'dark'; migrated = true; }
  if (!S().baseUrl) { S().baseUrl = 'https://riskradarai.ru/v1'; migrated = true; }
  // 1.2.86 V-IMG-ALWAYS: прикреплённые картинки ОБЯЗАТЕЛЬНО доходят до модели.
  // Старые версии могли сохранить sendImages=false — принудительно включаем;
  // переключатель в настройках остаётся для осознанного выключения.
  if (S().sendImages !== true) { S().sendImages = true; migrated = true; }
  if (typeof S().tddMode !== 'boolean') { S().tddMode = false; migrated = true; } // 1.2.83: TDD-режим (сначала тесты)
  if (typeof S().tokenShield !== 'boolean') { S().tokenShield = true; migrated = true; }
  if (migrated) saveDb();

  LANG = (S().lang === 'en') ? 'en' : (S().lang === 'ru' ? 'ru' : '');
  applyTheme();
  applyI18n();
  updateKeyBadge();
  renderChatList();
  renderSshProfiles();
  try { await ensureWorkDir(); } catch (e) { console.warn('[RR] fs:home failed', e); }
  updateWorkdirChip();
  try { await updateBalance(); } catch (e) { console.warn('[RR] balance init failed', e); }
  if (!balanceRefreshTimer) balanceRefreshTimer = setInterval(() => updateBalance().catch(console.warn), 60000);
  setTimeout(() => updateBalance().catch(console.warn), 1500);
  setTimeout(() => updateBalance().catch(console.warn), 6000);

  loadModels(true).catch((e) => console.warn('[RR] models init failed', e));

  if (S().apiKey && db.chats.length) {
    currentChatId = db.chats.sort((a, b) => b.updatedAt - a.updatedAt)[0].id;
    renderMessages(); updateChatTitle();
  } else if (S().apiKey) {
    newChat(true);
  } else {
    renderMessages();
  }
  updateWelcomeVisibility();

  initBrowserUi();
  /* V-MULTICHAT: кнопка «стоп» относится ТОЛЬКО к активному стриму ТЕКУЩЕГО чата,
     иначе второй чат не мог стартовать, пока работал первый. */
  $('#btn-send').onclick = () => ((currentChatId && (streamsByChat.has(currentChatId) || (streaming && streaming.chatId === currentChatId))) ? stopStream() : sendMessage());
  const tcBtn = $('#task-continue'); if (tcBtn) tcBtn.onclick = () => continueTask().catch((e) => console.warn('[RR] continue task', e));
  $('#composer-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendMessage(); }
  });
  $('#composer-input').addEventListener('input', () => { autosize(); if (!$('#ctx-modal').classList.contains('hidden')) updateCtxPanel(); });
  document.addEventListener('paste', async (e) => {
    if (e.target !== $('#composer-input')) return;
    const cd = e.clipboardData;
    if (!cd) return;
    // V-PASTE1: сначала файлы с реальным путём (фото/доки), затем — скриншоты и картинки из буфера,
    // у которых пути нет (rr.pathForFile вернёт '').
    const files = Array.from(cd.files || []);
    let handled = 0;
    for (const f of files.slice(0, 5)) {
      const p = rr.pathForFile(f);
      if (p) { await attachPath(p, true); handled++; }
      else if (await attachImageBlob(f, true)) { handled++; }
    }
    if (!handled) {
      const items = Array.from(cd.items || []).filter((it) => it.kind === 'file' && /^image\//i.test(it.type));
      for (const it of items.slice(0, 5)) {
        const f = it.getAsFile();
        if (f && await attachImageBlob(f, true)) handled++;
      }
    }
    if (handled) { toast(t('fileAttached')); return; }
    // 1.2.84 V-PASTE-MAC: ручная вставка текста — на macOS нативная вставка в <textarea>
    // иногда «глотается» (богатый буфер RTF/HTML, IME). Берём text/plain и вставляем сами.
    if (typeof cd.getData === 'function') {
      const ptxt = cd.getData('text/plain') || cd.getData('text');
      if (ptxt && ptxt.length) {
        e.preventDefault();
        const ta = e.target;
        const s = typeof ta.selectionStart === 'number' ? ta.selectionStart : ta.value.length;
        const en2 = typeof ta.selectionEnd === 'number' ? ta.selectionEnd : ta.value.length;
        ta.value = ta.value.slice(0, s) + ptxt + ta.value.slice(en2);
        const pos = s + ptxt.length;
        try { ta.setSelectionRange(pos, pos); } catch (e2) {}
        ta.focus(); autosize();
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
  });

  const chatView = $('#chat-view');
  chatView.addEventListener('dragover', (e) => { e.preventDefault(); chatView.style.outline = '2px dashed var(--accent)'; chatView.style.outlineOffset = '-6px'; });
  chatView.addEventListener('dragleave', () => { chatView.style.outline = 'none'; });
  chatView.addEventListener('drop', async (e) => {
    e.preventDefault(); chatView.style.outline = 'none';
    const files = Array.from(e.dataTransfer.files || []).slice(0, 8);
    for (const f of files) {
      const p = rr.pathForFile(f);
      if (p) await attachPath(p, true);
    }
    if (files.length) toast(files.length === 1 ? t('fileAttached') : t('filesAttached') + ': ' + files.length);
  });

$('#btn-attach').onclick = async () => {
    // V-MAC: принимаем paths/filePaths/filePath — на macOS форма ответа может отличаться
    const r = await rr.invoke('fs:openDialog', { multi: true, filters: IS_DARWIN ? undefined : ATTACH_FILTERS });
    if (!r || r.canceled) return;
    const paths = r.paths || r.filePaths || (r.filePath ? [r.filePath] : []);
    if (!paths.length) return;
    for (const p of paths) await attachPath(String(p), true);
    if (paths.length) toast(paths.length === 1 ? t('fileAttached') : t('filesAttached') + ': ' + paths.length);
  };

  /* V-CTX: панель контекста и токенов */
  const ctxBtn = $('#btn-ctx');
  if (ctxBtn) ctxBtn.onclick = () => { updateCtxPanel(); openModal('#ctx-modal'); };
  const ctxCompress = $('#ctx-compress');
  if (ctxCompress) ctxCompress.onclick = () => compressCurrentChat(false);
  const ctxAuto = $('#ctx-autocompress');
  if (ctxAuto) ctxAuto.onchange = () => {
    autoCompress = ctxAuto.checked;
    S().autoCompress = autoCompress;
    saveDb();
    toast(autoCompress ? t('ctxAutoOn') : t('ctxAutoOff'));
  };
  autoCompress = !!S().autoCompress;

  /* V-GHSKILLS: установка навыков с GitHub */
  const skillInstall = $('#skill-install');
  if (skillInstall) skillInstall.onclick = async () => {
    const urlEl = $('#skill-github-url');
    const url = urlEl ? urlEl.value.trim() : '';
    const status = $('#skill-status');
    if (!url) { if (status) status.textContent = t('skillNeedUrl'); return; }
    skillInstall.disabled = true;
    if (status) status.textContent = t('skillLoading');
    const res = await rr.invoke('skills:installGithub', { url });
    skillInstall.disabled = false;
    if (res && res.ok) {
      const list = res.skills || [];
    if (status) status.textContent = t('skillInstalled') + ' ' + list.length + ': ' + list.map((s) => s.name).join(', ');
      if (urlEl) urlEl.value = '';
      await loadGithubSkills();
    } else if (status) {
      status.textContent = t('skillError') + ' ' + ((res && res.error) || '');
    }
  };
  loadGithubSkills();

  $('#btn-new-chat').onclick = () => newChat();
  $('#chat-search').addEventListener('input', renderChatList);
  $('#btn-settings').onclick = () => { try { openSettings(); } catch (e) { console.error(e); toast('Settings: ' + (e.message || e), 'err'); } };
  $('#btn-export').onclick = exportChat;
  $('#btn-code-search').onclick = openCodeSearch;
  const supportBtn = $('#btn-support');
  // V-SUPPORT1: единственный обработчик. Нативный <a target=_blank> убран в index.html,
  // capture-слушатель и $$('[data-ext]') исключают #btn-support, чтобы клик не открывал несколько вкладок.
  if (supportBtn) supportBtn.onclick = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    openExternalUrl(supportBtn.dataset.ext || 'https://t.me/Beniclo');
  };
  $('#btn-theme').onclick = () => { S().theme = S().theme === 'light' ? 'dark' : 'light'; saveDb(); applyTheme(); };
  $('#key-balance').onclick = openTopupPage;
  injectStatsCss();                                    // V-TOKENSTATS: стили поповера
  showVersionBadge();                                  // V-VERBADGE: версия справа внизу
  const _reqCtr = $('#req-counter'); if (_reqCtr) _reqCtr.onclick = (e) => { e.stopPropagation(); toggleStatsPanel(); };
  const modelBrowserBtn = $('#model-browser-btn'); if (modelBrowserBtn) modelBrowserBtn.onclick = (e) => { e.stopPropagation(); openModelBrowser(); };
  const modelPickerBtn = $('#model-picker-btn'); if (modelPickerBtn) modelPickerBtn.onclick = (e) => { e.stopPropagation(); openModelBrowser(); };
  const reasoningBtn = $('#btn-reasoning'); if (reasoningBtn) reasoningBtn.onclick = (e) => { e.stopPropagation(); openReasoningPop(); };
  // 1.2.85 V-DEBATE: кнопка «⚖ Дебаты» рядом с моделями — вторая модель ревьюит код перед записью
  const debateBtn = $('#btn-debate');
  if (debateBtn) {
    const paintD = () => { debateBtn.classList.toggle('on', !!S().debateMode); debateBtn.title = (S().debateMode ? '⚖ ДЕБАТЫ: вкл. — ' : '⚖ Дебаты: выкл. — ') + 'критик: ' + (pickCriticModel() || '—') + ' (вторая модель ревьюит каждую запись кода на диск)'; };
    paintD();
    debateBtn.onclick = (e) => {
      e.stopPropagation();
      S().debateMode = !S().debateMode; saveDb(); paintD();
      try { toast(S().debateMode ? '⚖ Дебаты ВКЛ: ' + (pickCriticModel() || 'критик') + ' будет ревьюить код перед записью' : '⚖ Дебаты выкл.'); } catch (e2) {}
    };
  }
  const reasoningPop = $('#reasoning-pop'); if (reasoningPop) reasoningPop.onclick = (e) => { const b = e.target.closest('[data-reasoning]'); if (b) selectReasoningChoice(b.dataset.reasoning); };
  document.addEventListener('click', (e) => {
    const link = e.target && e.target.closest ? e.target.closest('#btn-support,[data-ext]') : null;
    if (!link) return;
    // V-SUPPORT1: поддержка обрабатывается своим onclick выше; здесь пропускаем её, иначе двойное открытие
    if (link.id === 'btn-support') return;
    e.preventDefault();
    openExternalUrl(link.dataset.ext || link.getAttribute('href') || 'https://t.me/Beniclo');
  }, true);
  document.addEventListener('click', (e) => {
    const pop = $('#model-picker-pop');
    if (!pop || pop.classList.contains('hidden')) return;
    if (pop.contains(e.target) || (modelPickerBtn && modelPickerBtn.contains(e.target))) return;
    closeModelPicker();
  });
  $('#btn-files').onclick = () => {
    const open = !$('#panel').classList.contains('hidden') && !$('#panel-files').classList.contains('hidden');
    open ? closePanel() : openPanel('files');
  };
  $('#btn-ssh').onclick = () => {
    const open = !$('#panel').classList.contains('hidden') && !$('#panel-ssh').classList.contains('hidden');
    open ? closePanel() : openPanel('ssh');
  };
  $('#btn-panel-close').onclick = closePanel;
  $('#chat-title').addEventListener('dblclick', enableChatTitleEditing);
  $('#chat-title').addEventListener('keydown', (e) => {
    if (!$('#chat-title').classList.contains('editing')) return;
    if (e.key === 'Enter') { e.preventDefault(); disableChatTitleEditing(true); }
    if (e.key === 'Escape') { e.preventDefault(); disableChatTitleEditing(false); }
  });
  $('#chat-title').addEventListener('blur', () => disableChatTitleEditing(true));

  /* рабочий каталог */
  $('#workdir-chip').onclick = async () => {
    const r = await rr.invoke('fs:dirDialog');
    if (r && r.ok) {
      S().workDir = r.path; S().workDirPinned = true; saveDb(); updateWorkdirChip();
      await indexCurrentProject(r.path);
      toast('📂 Закреплён каталог: ' + r.path);
      if (!$('#panel-files').classList.contains('hidden')) filesGo(r.path);
    }
  };
  // V-FSACCESS: ПКМ по чипу каталога — переключить режим «только папка» ↔ «весь ПК».
  $('#workdir-chip').oncontextmenu = (e) => {
    e.preventDefault();
    const next = !isWorkDirPinned();
    S().workDirPinned = next;
    if (next && !S().workDir) { S().workDir = homeDirCache || ''; }
    saveDb(); updateWorkdirChip();
    toast(next ? '📌 Ограничено папкой: ' + (S().workDir || '~') : '🖥 Доступ ко всему ПК включён');
  };

  /* файлы */
  $('#files-up').onclick = () => {
    const parts = filesState.dir.replace(/[\\/]+$/, '').split(/[\\/]/);
    parts.pop();
    const up = parts.join('/') || '/';
    filesGo(/^([a-z]:)$/i.test(up) ? up + '\\' : up);
  };
  $('#files-home').onclick = () => filesGo(S().workDir || null);
  $('#files-refresh').onclick = () => filesGo(filesState.dir);
  $('#files-pick-dir').onclick = async () => {
    const r = await rr.invoke('fs:dirDialog');
    if (r && r.ok) { S().workDir = r.path; S().workDirPinned = true; saveDb(); updateWorkdirChip(); await indexCurrentProject(r.path); filesGo(r.path); }
  };

  /* ssh */
  $('#ssh-authtype').onchange = sshAuthTypeToggle;
  $('#ssh-keypick').onclick = async () => {
    const r = await rr.invoke('fs:openDialog', { multi: false });
    if (r && r.ok) $('#ssh-keypath').value = r.paths[0];
  };
  $('#ssh-form').onsubmit = (e) => { e.preventDefault(); doSshConnect(readSshForm(null)); };
  $('#ssh-disconnect').onclick = async () => {
    if (sshSession) await rr.invoke('ssh:close', { id: sshSession.id });
    sshTeardown();
  };
  $('#sftp-open').onclick = () => {
    $('#panel-ssh').classList.add('hidden');
    $('#panel-sftp').classList.remove('hidden');
    sftpGo(sftpState.path === '/' ? '/root' : sftpState.path);
  };
  $('#sftp-back').onclick = () => { $('#panel-sftp').classList.add('hidden'); $('#panel-ssh').classList.remove('hidden'); };
  $('#sftp-go').onclick = () => sftpGo($('#sftp-path').value.trim() || '/');
  $('#sftp-path').addEventListener('keydown', (e) => { if (e.key === 'Enter') sftpGo($('#sftp-path').value.trim()); });
  $('#sftp-up').onclick = () => {
    const parts = sftpState.path.replace(/\/+$/, '').split('/');
    parts.pop();
    sftpGo(parts.join('/') || '/');
  };
  $('#sftp-refresh').onclick = () => sftpGo(sftpState.path);
  $('#sftp-upload').onclick = async () => {
    if (!sshSession) return;
    const r = await rr.invoke('fs:openDialog', { multi: false });
    if (!r || r.canceled || !r.paths) return;
    const local = r.paths[0];
    const name = local.split(/[\\/]/).pop();
    const remote = (sftpState.path === '/' ? '' : sftpState.path) + '/' + name;
    const u = await rr.invoke('ssh:sftpUpload', { id: sshSession.id, local, remote });
    toast(u.ok ? '✓ ' + remote : ('SFTP: ' + u.error), u.ok ? '' : 'err');
    sftpGo(sftpState.path);
  };

  /* модалки */
  $$('.modal-close').forEach((b) => (b.onclick = closeModals));
  $('#modal-backdrop').onclick = closeModals;
  $('.modal-save') && ($('.modal-save').onclick = saveSettings);
  $('#set-key-show').onclick = () => {
    const k = $('#set-key'); k.type = k.type === 'password' ? 'text' : 'password';
  };
  $('#set-key-check').onclick = async () => {
    const st = $('#set-key-status');
    st.textContent = '…';
    const r = await rr.invoke('gw:check', { baseUrl: 'https://riskradarai.ru/v1', apiKey: $('#set-key').value.trim() });
    st.textContent = r.error ? ('✗ ' + r.error) : (r.ok ? '✓ ' + (r.defaultModel || '') : '✗');
  };
  $('#set-models-refresh').onclick = () => loadModels(false);
  $('#set-temp').oninput = (e) => ($('#set-temp-val').textContent = e.target.value);
  $('#set-hist').oninput = (e) => ($('#set-hist-val').textContent = e.target.value);
  const roundsInput = $('#set-rounds');
  if (roundsInput) roundsInput.oninput = (e) => ($('#set-rounds-val').textContent = e.target.value);
  const maxtokInput = $('#set-maxtok');
  if (maxtokInput) maxtokInput.oninput = (e) => ($('#set-maxtok-val').textContent = e.target.value);
  const openDbBtn = $('#set-open-db');
  if (openDbBtn) openDbBtn.onclick = () => {
    const dp = $('#set-dbpath');
    const p = (dp && dp.value || '').trim();
    if (!p) return toast('Путь к базе не определён', 'warn');
    rr.invoke('fs:showInFolder', { filePath: p }).catch((e) => toast(String(e && e.message || e), 'err'));
  };
  $('#code-search-run').onclick = runCodeSearch;
  $('#code-search-query').addEventListener('keydown', (e) => { if (e.key === 'Enter') runCodeSearch(); });
  $('#code-edit-save').onclick = () => saveCodeEditor(false);
  $('#code-edit-saveas').onclick = () => saveCodeEditor(true);
  $('#set-upd-check').onclick = async () => {
    const st = $('#set-upd-status');
    st.textContent = '…';
    try {
      const info = await rr.invoke('app:info');
      try {
        const uiRes = await fetch('https://riskradarai.ru/app/version.json?ts=' + Date.now(), { cache: 'no-store' });
        const ui = await uiRes.json();
        if (ui && compareVersions(ui.uiVersion, info.uiVersion) > 0) {
          st.textContent = `${t('updatesUiRestart')} (${info.uiVersion} → ${ui.uiVersion})`;
          return;
        }
      } catch (e) {
        console.warn('[RR] ui update check failed', e);
      }
      let r = null, feedErr = '';
      try { r = await rr.invoke('app:checkUpdates'); }
      catch (eCcu) {
        // V-UPDFL: в win-сборке без resources\app-update.yml electron-updater падает
        // (ENOENT) — проверяем фид latest.json напрямую и предлагаем установщик.
        feedErr = String((eCcu && eCcu.message) || eCcu);
      }
      const latest = (r && (r.version || r.latestVersion || (r.info && r.info.version))) || '';
      let appAvailable = (r && (r.available === true || r.updateAvailable === true)) || (latest && compareVersions(latest, info.version) > 0);
      if (feedErr && /ENOENT|app-update\.yml/i.test(feedErr)) {
        try {
          const fr = await fetch('https://riskradarai.ru/app/releases/latest.json?ts=' + Date.now(), { cache: 'no-store' });
          const fj = await fr.json();
          const fv = String((fj && fj.version) || '');
          const furl = fj && fj.files && fj.files[0] && fj.files[0].url;
          if (fv && compareVersions(fv, info.version) > 0) {
            st.innerHTML = 'Доступна v' + esc(fv) + ' — <a href="#" id="upd-dl" style="text-decoration:underline">скачать установщик</a>';
            const dl = $('#upd-dl');
            if (dl) dl.onclick = (ev) => { ev.preventDefault(); openExternalUrl('https://riskradarai.ru/app/releases/' + (furl || '')); };
            return;
          }
          st.textContent = t('updatesNone');
          return;
        } catch (eFd) { st.textContent = t('updatesNone'); return; }
      }
      st.textContent = appAvailable ? (t('updatesAppAvail') + latest) : t('updatesNone');
    } catch (e) {
      st.textContent = (e && e.message) ? e.message : '—';
    }
  };

  /* предпросмотр файла */
  $('#preview-attach').onclick = async () => { if (currentPreviewFile && currentPreviewFile.target !== 'remote') { closeModals(); await attachPath(currentPreviewFile.path); } };
  $('#preview-open').onclick = () => { if (currentPreviewFile && currentPreviewFile.target !== 'remote') rr.invoke('fs:openPath', { filePath: currentPreviewFile.path }); };
  $('#preview-folder').onclick = () => { if (currentPreviewFile && currentPreviewFile.target !== 'remote') rr.invoke('fs:showInFolder', { filePath: currentPreviewFile.path }); };
  $('#preview-edit').onclick = async () => {
    if (!currentPreviewFile || currentPreviewFile.target === 'remote') return;
    const r = await rr.invoke('fs:readText', { filePath: currentPreviewFile.path });
    if (r && r.ok) openCodeEditor({ text: r.content, file: currentPreviewFile.path, suggestedPath: currentPreviewFile.path, name: currentPreviewFile.name, target: 'local' });
    else toast((r && r.error) || 'Open failed', 'err');
  };

  /* язык и приветствие */
  $('#lang-ru').onclick = () => chooseLang('ru');
  $('#lang-en').onclick = () => chooseLang('en');
  $('#welcome-connect').onclick = welcomeConnect;
  $('#welcome-key').addEventListener('keydown', (e) => { if (e.key === 'Enter') welcomeConnect(); });
  $$('[data-ext]').forEach((el) => { if (el.id === 'btn-support') return; el.onclick = (e) => { e.preventDefault(); openExternalUrl(el.dataset.ext); }; });

  /* меню приложения */
  rr.on('menu:new-chat', () => newChat());
  rr.on('agent:confirm', (d) => showAgentConfirm(d));
  rr.on('menu:settings', openSettings);
  rr.on('menu:files', () => openPanel('files'));
  rr.on('menu:ssh', () => openPanel('ssh'));
  rr.on('menu:theme', () => { S().theme = S().theme === 'light' ? 'dark' : 'light'; saveDb(); applyTheme(); });
  rr.on('menu:about', openAbout);
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openCodeSearch(); }
    if ((e.ctrlKey || e.metaKey) && e.key === ',') { e.preventDefault(); openSettings(); }
  });

  setupUpdaterEvents();
  setupSshEvents();

  autosize();
  // хелпер для агентного smoke-теста
  window.__RR_SMOKE__ = {
    chat: () => currentChat(),
    streaming: () => !!streaming,
    send: (text) => { $('#composer-input').value = text; sendMessage(); }
  };
  try { await rr.invoke('smoke:ready'); } catch (e) {}
  console.log('[RR] UI готов');
}

document.addEventListener('DOMContentLoaded', boot);
window.addEventListener('error', (e) => console.error('[RR-ERR]', e.message));
window.addEventListener('unhandledrejection', (e) => console.error('[RR-REJECT]', e.reason && e.reason.message ? e.reason.message : e.reason));
window.addEventListener('focus', () => updateBalance().catch(console.warn));





