/* RiskRadar Terminal — V-DOC: генерация документов docx / xlsx / pptx / rtf.
 * ZIP собирается вручную (метод store), поэтому внешние библиотеки не нужны.
 * Файлы пишутся через IPC-канал fs:writeBinary (добавлен в main.js).
 */
'use strict';

const DOC_CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? ((c >>> 1) ^ 0xEDB88320) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();

function docCrc32(u8) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < u8.length; i++) c = DOC_CRC_TABLE[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

/* ZIP без сжатия — валиден для OOXML (Word/Excel/PowerPoint). */
function zipStore(entries) {
  const enc = new TextEncoder();
  const parts = [];
  const central = [];
  let offset = 0;
  for (const e of entries) {
    const nameBuf = enc.encode(e.name);
    const data = (typeof e.data === 'string') ? enc.encode(e.data) : e.data;
    const crc = docCrc32(data);
    const lh = new Uint8Array(30 + nameBuf.length);
    const lv = new DataView(lh.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0x0800, true);
    lv.setUint16(8, 0, true);
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0x21, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, data.length, true);
    lv.setUint32(22, data.length, true);
    lv.setUint16(26, nameBuf.length, true);
    lv.setUint16(28, 0, true);
    lh.set(nameBuf, 30);
    parts.push(lh, data);

    const ch = new Uint8Array(46 + nameBuf.length);
    const cv = new DataView(ch.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0x21, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, data.length, true);
    cv.setUint32(24, data.length, true);
    cv.setUint16(28, nameBuf.length, true);
    cv.setUint32(42, offset, true);
    ch.set(nameBuf, 46);
    central.push(ch);
    offset += lh.length + data.length;
  }
  const cdSize = central.reduce((a, b) => a + b.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, cdSize, true);
  ev.setUint32(16, offset, true);
  const all = parts.concat(central, [eocd]);
  const out = new Uint8Array(all.reduce((a, b) => a + b.length, 0));
  let p = 0;
  for (const c of all) { out.set(c, p); p += c.length; }
  return out;
}

function u8ToBase64(u8) {
  let s = '';
  const CH = 0x8000;
  for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
  return btoa(s);
}

function xmlEsc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

function colName(n) {
  let s = '';
  n++;
  while (n > 0) { const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = (n - r - 1) / 26; }
  return s;
}

const XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';

/* ------------------------------- DOCX ------------------------------- */
function docxBytes(title, body) {
  let ps = '';
  if (title) {
    ps += '<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="32"/></w:rPr>'
      + '<w:t xml:space="preserve">' + xmlEsc(title) + '</w:t></w:r></w:p>';
  }
  for (const line of String(body || '').split(/\r?\n/)) {
    ps += line.trim() === ''
      ? '<w:p/>'
      : '<w:p><w:r><w:t xml:space="preserve">' + xmlEsc(line) + '</w:t></w:r></w:p>';
  }
  return zipStore([
    { name: '[Content_Types].xml', data: XML_HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>' },
    { name: '_rels/.rels', data: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>' },
    { name: 'word/document.xml', data: XML_HEAD + '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + ps + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="850" w:bottom="1134" w:left="1701"/></w:sectPr></w:body></w:document>' }
  ]);
}

/* ------------------------------- XLSX ------------------------------- */
function xlsxBytes(rows) {
  const body = rows.map((r, ri) => {
    const cells = (Array.isArray(r) ? r : [r]).map((c, ci) => {
      const ref = colName(ci) + (ri + 1);
      const raw = c == null ? '' : String(c);
      const trimmed = raw.trim();
      const isNum = trimmed !== '' && /^-?\d+([.,]\d+)?$/.test(trimmed);
      if (isNum) return '<c r="' + ref + '"><v>' + trimmed.replace(',', '.') + '</v></c>';
      return '<c r="' + ref + '" t="inlineStr"><is><t xml:space="preserve">' + xmlEsc(raw) + '</t></is></c>';
    }).join('');
    return '<row r="' + (ri + 1) + '">' + cells + '</row>';
  }).join('');
  return zipStore([
    { name: '[Content_Types].xml', data: XML_HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>' },
    { name: '_rels/.rels', data: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
    { name: 'xl/workbook.xml', data: XML_HEAD + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>' },
    { name: 'xl/_rels/workbook.xml.rels', data: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>' },
    { name: 'xl/worksheets/sheet1.xml', data: XML_HEAD + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>' + body + '</sheetData></worksheet>' }
  ]);
}

/* ------------------------------- PPTX ------------------------------- */
const PPTX_THEME = XML_HEAD + '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office"><a:themeElements><a:clrScheme name="Office"><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="44546A"/></a:dk2><a:lt2><a:srgbClr val="E7E6E6"/></a:lt2><a:accent1><a:srgbClr val="4472C4"/></a:accent1><a:accent2><a:srgbClr val="ED7D31"/></a:accent2><a:accent3><a:srgbClr val="A5A5A5"/></a:accent3><a:accent4><a:srgbClr val="FFC000"/></a:accent4><a:accent5><a:srgbClr val="5B9BD5"/></a:accent5><a:accent6><a:srgbClr val="70AD47"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme><a:fontScheme name="Office"><a:majorFont><a:latin typeface="Calibri Light"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="Office"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>';

const PPTX_LAYOUT = XML_HEAD + '<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank" preserve="1"><p:cSld name="Blank"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>';

const PPTX_MASTER = XML_HEAD + '<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst></p:sldMaster>';

function pptxTextBox(id, name, text, size, bold, y, cx, cy) {
  return '<p:sp><p:nvSpPr><p:cNvPr id="' + id + '" name="' + name + '"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
    + '<p:spPr><a:xfrm><a:off x="685800" y="' + y + '"/><a:ext cx="' + cx + '" cy="' + cy + '"/></a:xfrm>'
    + '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>'
    + '<p:txBody><a:bodyPr wrap="square"><a:normAutofit/></a:bodyPr><a:lstStyle/>'
    + '<a:p><a:r><a:rPr lang="ru-RU" sz="' + size + '"' + (bold ? ' b="1"' : '') + ' dirty="0">'
    + '<a:solidFill><a:srgbClr val="' + (bold ? '1F2937' : '374151') + '"/></a:solidFill>'
    + '<a:latin typeface="Calibri"/></a:rPr><a:t>' + xmlEsc(text) + '</a:t></a:r></a:p></p:txBody></p:sp>';
}

function pptxSlideXml(title, bullets) {
  const items = (bullets || []).slice(0, 12);
  const bodyParas = items.map((b) =>
    '<a:p><a:pPr marL="285750" indent="-285750"><a:buChar char="\u2022"/></a:pPr>'
    + '<a:r><a:rPr lang="ru-RU" sz="1800" dirty="0"><a:latin typeface="Calibri"/></a:rPr>'
    + '<a:t>' + xmlEsc(b) + '</a:t></a:r></a:p>'
  ).join('');
  const bodySp = '<p:sp><p:nvSpPr><p:cNvPr id="3" name="Body"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
    + '<p:spPr><a:xfrm><a:off x="685800" y="1600200"/><a:ext cx="7772400" cy="4343400"/></a:xfrm>'
    + '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>'
    + '<p:txBody><a:bodyPr wrap="square"><a:normAutofit/></a:bodyPr><a:lstStyle/>'
    + (bodyParas || '<a:p/>') + '</p:txBody></p:sp>';
  return XML_HEAD
    + '<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
    + '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
    + '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
    + pptxTextBox(2, 'Title', title || 'Slide', 3200, true, 685800, 7772400, 914400)
    + bodySp
    + '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
}

function pptxBytes(slides) {
  const list = (slides && slides.length) ? slides : [{ title: 'Слайд 1', bullets: [] }];
  const rels = (i) => XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/></Relationships>';
  const entries = [
    { name: '[Content_Types].xml', data: XML_HEAD + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>' + list.map((s, i) => '<Override PartName="/ppt/slides/slide' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>').join('') + '</Types>' },
    { name: '_rels/.rels', data: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/></Relationships>' },
    { name: 'ppt/presentation.xml', data: XML_HEAD + '<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>' + list.map((s, i) => '<p:sldId id="' + (256 + i) + '" r:id="rId' + (i + 2) + '"/>').join('') + '</p:sldIdLst><p:sldSz cx="9144000" cy="6858000"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>' },
    { name: 'ppt/_rels/presentation.xml.rels', data: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>' + list.map((s, i) => '<Relationship Id="rId' + (i + 2) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide' + (i + 1) + '.xml"/>').join('') + '</Relationships>' },
    { name: 'ppt/theme/theme1.xml', data: PPTX_THEME },
    { name: 'ppt/slideMasters/slideMaster1.xml', data: PPTX_MASTER },
    { name: 'ppt/slideMasters/_rels/slideMaster1.xml.rels', data: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/></Relationships>' },
    { name: 'ppt/slideLayouts/slideLayout1.xml', data: PPTX_LAYOUT },
    { name: 'ppt/slideLayouts/_rels/slideLayout1.xml.rels', data: XML_HEAD + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>' }
  ];
  list.forEach((s, i) => {
    entries.push({ name: 'ppt/slides/slide' + (i + 1) + '.xml', data: pptxSlideXml(s.title, s.bullets) });
    entries.push({ name: 'ppt/slides/_rels/slide' + (i + 1) + '.xml.rels', data: rels(i) });
  });
  return zipStore(entries);
}

/* -------------------------------- RTF -------------------------------- */
function rtfEscape(s) {
  return String(s == null ? '' : s).split('').map((ch) => {
    const c = ch.charCodeAt(0);
    if (ch === '\\') return '\\\\';
    if (ch === '{') return '\\{';
    if (ch === '}') return '\\}';
    if (c > 127) return '\\u' + c + '?';
    return ch;
  }).join('');
}
function rtfText(title, body) {
  let out = '{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Calibri;}}{\\colortbl;\\red31\\green41\\blue55;}';
  if (title) out += '\\pard\\qc\\b\\fs32\\cf1 ' + rtfEscape(title) + '\\b0\\fs22\\par\\par';
  for (const line of String(body || '').split(/\r?\n/)) out += '\\pard\\ql\\fs22 ' + rtfEscape(line) + '\\par';
  return out + '}';
}

/* ---------------------------- диспетчер ---------------------------- */
/* rows -> [[...]], slides -> [{title, bullets:[]}] */
/* V-MOJI: автопочинка «UTF-8, прочитанный как cp1251» — модели иногда возвращают
   текст таким «мусором»; чиним до сборки документа (только если починка убедительна). */
let __CP1251_INV = null;
function __cp1251Inv() {
  if (__CP1251_INV) return __CP1251_INV;
  const m = new Map();
  try {
    const td = new TextDecoder('windows-1251');
    const b = new Uint8Array(1);
    for (let x = 0x20; x <= 0xff; x++) {
      b[0] = x;
      const ch = td.decode(b);
      if (ch.length === 1 && ch.charCodeAt(0) !== 0xfffd) m.set(ch.charCodeAt(0), x);
    }
  } catch (e) { __CP1251_INV = null; return null; }
  __CP1251_INV = m;
  return m;
}
function repairMojibake(str) {
  const v = String(str == null ? '' : str);
  if (!v || v.indexOf('\u0080') < 0 && !/[\u00c0-\u00ff\u0400-\u045f]/.test(v)) return v;
  const inv = __cp1251Inv();
  if (!inv) return v;
  let out = '';
  let i = 0;
  while (i < v.length) {
    const b1 = inv.get(v.charCodeAt(i));
    let seqLen = 0;
    if (b1 !== undefined) {
      if (b1 >= 0xc2 && b1 <= 0xdf) seqLen = 2;
      else if (b1 >= 0xe0 && b1 <= 0xef) seqLen = 3;
      else if (b1 >= 0xf0 && b1 <= 0xf4) seqLen = 4;
    }
    let done = false;
    if (seqLen > 1 && i + seqLen <= v.length) {
      const bs = new Uint8Array(seqLen);
      bs[0] = b1;
      let ok = true;
      for (let k = 1; k < seqLen; k++) {
        const bk = inv.get(v.charCodeAt(i + k));
        if (bk === undefined || (bk & 0xc0) !== 0x80) { ok = false; break; }
        bs[k] = bk;
      }
      if (ok) {
        try {
          const dec = new TextDecoder('utf-8', { fatal: true }).decode(bs);
          if (dec.length === 1 && dec.charCodeAt(0) >= 0x80) { out += dec; i += seqLen; done = true; }
        } catch (e) {}
      }
    }
    if (!done) { out += v[i]; i++; }
  }
  return out;
}
function deepRepair(x, depth) {
  if (depth > 3) return x;
  if (typeof x === 'string') return repairMojibake(x);
  if (Array.isArray(x)) return x.map((it) => deepRepair(it, depth + 1));
  if (x && typeof x === 'object') { const o = {}; for (const k of Object.keys(x)) o[k] = deepRepair(x[k], depth + 1); return o; }
  return x;
}
function buildDocument(args) {
  { const raw = args || {};
    args = Object.assign({}, raw);
    if (typeof args.title === 'string') args.title = repairMojibake(args.title);
    if (typeof args.content === 'string') args.content = repairMojibake(args.content);
    if (Array.isArray(args.rows)) args.rows = deepRepair(args.rows, 1);
    if (Array.isArray(args.slides)) args.slides = deepRepair(args.slides, 1);
    if (Array.isArray(args.paragraphs)) args.paragraphs = deepRepair(args.paragraphs, 1);
  }
  const a = args || {};
  const fmt = String(a.format || '').toLowerCase().replace(/^\./, '');
  const title = a.title || '';
  if (fmt === 'docx' || fmt === 'word') return { kind: 'bin', ext: 'docx', bytes: docxBytes(title, a.content || '') };
  if (fmt === 'xlsx' || fmt === 'excel' || fmt === 'xls') {
    let rows = a.rows;
    if (!Array.isArray(rows)) {
      const delim = a.delimiter ? a.delimiter : /\t|;|,/;
      rows = String(a.content || '').split(/\r?\n/).filter((l) => l.trim() !== '').map((l) => l.split(delim).map((c) => c.trim()));
    }
    return { kind: 'bin', ext: 'xlsx', bytes: xlsxBytes(rows) };
  }
  if (fmt === 'pptx' || fmt === 'powerpoint' || fmt === 'ppt') {
    let slides = a.slides;
    if (!Array.isArray(slides)) {
      slides = String(a.content || '').split(/\n(?=#{1,2}\s)/).filter((s) => s.trim() !== '').map((chunk) => {
        const ls = chunk.split(/\r?\n/);
        return {
          title: ls[0].replace(/^#{1,2}\s*/, '').trim(),
          bullets: ls.slice(1).map((x) => x.replace(/^\s*[-*\u2022]\s*/, '').trim()).filter(Boolean)
        };
      });
      if (!slides.length) slides = [{ title: title || 'Слайд 1', bullets: [] }];
    }
    return { kind: 'bin', ext: 'pptx', bytes: pptxBytes(slides) };
  }
  if (fmt === 'rtf') return { kind: 'text', ext: 'rtf', text: rtfText(title, a.content || '') };
  return { kind: 'error', error: 'Неизвестный формат: ' + fmt + ' (docx | xlsx | pptx | rtf)' };
}

if (typeof module !== 'undefined' && module.exports) module.exports = { buildDocument, zipStore, docCrc32, docxBytes, xlsxBytes, pptxBytes, rtfText };
