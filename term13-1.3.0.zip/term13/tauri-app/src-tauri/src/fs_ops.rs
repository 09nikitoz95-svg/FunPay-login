use base64::Engine;
use serde_json::{json, Value};
use std::collections::HashSet;
use std::fs;
use std::path::Path;

const MAX_TEXT_BYTES: u64 = 2 * 1024 * 1024;
const MAX_IMG_BYTES: u64 = 8 * 1024 * 1024;

fn get_text_exts() -> HashSet<&'static str> {
    [
        "txt", "md", "markdown", "json", "jsonc", "js", "mjs", "cjs", "ts", "jsx", "tsx", "py",
        "rb", "go", "rs", "java", "kt", "kts", "c", "h", "cpp", "hpp", "cs", "php", "sh", "bash",
        "zsh", "bat", "cmd", "ps1", "psm1", "yml", "yaml", "toml", "ini", "cfg", "conf", "env",
        "log", "csv", "tsv", "html", "htm", "css", "scss", "sass", "less", "xml", "svg", "sql",
        "r", "lua", "pl", "swift", "dart", "vue", "svelte", "gradle", "properties", "dockerfile",
        "makefile", "gitignore", "npmrc", "lock",
    ]
    .into_iter()
    .collect()
}

fn get_img_exts() -> HashSet<&'static str> {
    ["png", "jpg", "jpeg", "gif", "webp", "bmp"]
        .into_iter()
        .collect()
}

fn ext_of(p: &Path) -> String {
    p.extension()
        .and_then(|e| e.to_str())
        .map(|s| s.to_lowercase())
        .unwrap_or_default()
}

pub fn fs_home() -> String {
    dirs::home_dir()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_else(|| ".".into())
}

pub fn fs_list(dir: &str) -> Value {
    let p = Path::new(dir);
    let read_res = match fs::read_dir(p) {
        Ok(r) => r,
        Err(e) => return json!({ "error": format!("Нет доступа: {}", e) }),
    };

    let mut entries = Vec::new();
    for entry in read_res.flatten() {
        let name = entry.file_name().to_string_lossy().to_string();
        if name.starts_with('.') && !entry.path().is_dir() {
            continue;
        }
        let full_path = entry.path().to_string_lossy().to_string();
        let is_dir = entry.path().is_dir();
        let metadata = entry.metadata().ok();
        let size = metadata.as_ref().map(|m| m.len()).unwrap_or(0);
        let mtime = metadata
            .and_then(|m| m.modified().ok())
            .and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
            .map(|d| d.as_millis() as u64)
            .unwrap_or(0);
        let ext = if is_dir { "".into() } else { ext_of(&entry.path()) };

        entries.push(json!({
            "name": name,
            "path": full_path,
            "dir": is_dir,
            "size": size,
            "mtime": mtime,
            "ext": ext
        }));
    }

    // Sort: directories first, then alphabetical
    entries.sort_by(|a, b| {
        let a_dir = a.get("dir").and_then(|d| d.as_bool()).unwrap_or(false);
        let b_dir = b.get("dir").and_then(|d| d.as_bool()).unwrap_or(false);
        if a_dir != b_dir {
            return b_dir.cmp(&a_dir);
        }
        let a_name = a.get("name").and_then(|n| n.as_str()).unwrap_or("");
        let b_name = b.get("name").and_then(|n| n.as_str()).unwrap_or("");
        a_name.to_lowercase().cmp(&b_name.to_lowercase())
    });

    let abs_path = fs::canonicalize(p)
        .map(|c| c.to_string_lossy().to_string())
        .unwrap_or_else(|_| dir.to_string());

    json!({ "ok": true, "path": abs_path, "entries": entries })
}

pub fn fs_read_text(file_path: &str) -> Value {
    let p = Path::new(file_path);
    let md = match fs::metadata(p) {
        Ok(m) => m,
        Err(e) => return json!({ "error": e.to_string() }),
    };

    if md.len() > MAX_TEXT_BYTES {
        return json!({ "error": "Файл больше 2 МБ — прикрепите его вручную или откройте часть" });
    }

    match fs::read_to_string(p) {
        Ok(content) => {
            let name = p.file_name().and_then(|n| n.to_str()).unwrap_or("");
            json!({
                "ok": true,
                "name": name,
                "size": md.len(),
                "ext": ext_of(p),
                "content": content
            })
        }
        Err(e) => json!({ "error": e.to_string() }),
    }
}

pub fn fs_read_image(file_path: &str) -> Value {
    let p = Path::new(file_path);
    let ext = ext_of(p);
    if !get_img_exts().contains(ext.as_str()) {
        return json!({ "error": "Не изображение" });
    }

    let md = match fs::metadata(p) {
        Ok(m) => m,
        Err(e) => return json!({ "error": e.to_string() }),
    };

    if md.len() > MAX_IMG_BYTES {
        return json!({ "error": "Изображение больше 8 МБ" });
    }

    match fs::read(p) {
        Ok(bytes) => {
            let mime = match ext.as_str() {
                "jpg" | "jpeg" => "image/jpeg",
                "png" => "image/png",
                "gif" => "image/gif",
                "webp" => "image/webp",
                "bmp" => "image/bmp",
                _ => "image/png",
            };
            let b64 = base64::engine::general_purpose::STANDARD.encode(&bytes);
            let name = p.file_name().and_then(|n| n.to_str()).unwrap_or("");
            json!({
                "ok": true,
                "name": name,
                "size": md.len(),
                "dataUrl": format!("data:{};base64,{}", mime, b64)
            })
        }
        Err(e) => json!({ "error": e.to_string() }),
    }
}

pub fn fs_write_text(file_path: &str, content: &str) -> Value {
    let p = Path::new(file_path);
    if let Some(parent) = p.parent() {
        let _ = fs::create_dir_all(parent);
    }
    match fs::write(p, content) {
        Ok(_) => json!({ "ok": true, "path": file_path }),
        Err(e) => json!({ "error": e.to_string() }),
    }
}

pub fn fs_write_binary(
    file_path: Option<&str>,
    base64_data: &str,
    ask_path: bool,
    suggested_name: Option<&str>,
) -> Value {
    let bytes = match base64::engine::general_purpose::STANDARD.decode(base64_data.trim()) {
        Ok(b) => b,
        Err(e) => return json!({ "error": format!("Base64 decode error: {}", e) }),
    };

    let target_path = if ask_path || file_path.is_none() {
        let mut dlg = rfd::FileDialog::new();
        if let Some(name) = suggested_name {
            dlg = dlg.set_file_name(name);
        }
        match dlg.save_file() {
            Some(p) => p.to_string_lossy().to_string(),
            None => return json!({ "canceled": true }),
        }
    } else {
        file_path.unwrap().to_string()
    };

    let p = Path::new(&target_path);
    if let Some(parent) = p.parent() {
        let _ = fs::create_dir_all(parent);
    }

    match fs::write(p, &bytes) {
        Ok(_) => json!({ "ok": true, "path": target_path, "bytes": bytes.len() }),
        Err(e) => json!({ "error": e.to_string() }),
    }
}

pub fn fs_mkdir(dir: &str) -> Value {
    match fs::create_dir_all(dir) {
        Ok(_) => json!({ "ok": true, "path": dir }),
        Err(e) => json!({ "error": e.to_string() }),
    }
}

pub fn fs_remove(target: &str) -> Value {
    let p = Path::new(target);
    let res = if p.is_dir() {
        fs::remove_dir_all(p)
    } else {
        fs::remove_file(p)
    };
    match res {
        Ok(_) => json!({ "ok": true, "path": target, "deleted": true }),
        Err(e) => json!({ "error": e.to_string() }),
    }
}

pub fn fs_open_path(path: &str) -> Value {
    match open::that(path) {
        Ok(_) => json!({ "ok": true }),
        Err(e) => json!({ "error": e.to_string() }),
    }
}

pub fn fs_show_in_folder(path: &str) -> Value {
    #[cfg(target_os = "windows")]
    {
        let _ = std::process::Command::new("explorer.exe")
            .arg("/select,")
            .arg(path)
            .spawn();
        return json!({ "ok": true });
    }
    #[cfg(not(target_os = "windows"))]
    {
        let p = Path::new(path);
        let folder = if p.is_dir() { p } else { p.parent().unwrap_or(p) };
        let _ = open::that(folder);
        return json!({ "ok": true });
    }
}

pub fn fs_ext_info(path: &str) -> Value {
    let p = Path::new(path);
    let ext = ext_of(p);
    let is_text = get_text_exts().contains(ext.as_str());
    let is_image = get_img_exts().contains(ext.as_str());
    json!({ "ext": ext, "isText": is_text, "isImage": is_image })
}

pub fn fs_open_dialog(multi: bool) -> Value {
    let dlg = rfd::FileDialog::new();
    if multi {
        match dlg.pick_files() {
            Some(files) => {
                let paths: Vec<String> = files.into_iter().map(|f| f.to_string_lossy().to_string()).collect();
                json!({ "ok": true, "paths": paths })
            }
            None => json!({ "canceled": true }),
        }
    } else {
        match dlg.pick_file() {
            Some(file) => {
                json!({ "ok": true, "paths": [file.to_string_lossy().to_string()] })
            }
            None => json!({ "canceled": true }),
        }
    }
}

pub fn fs_dir_dialog() -> Value {
    match rfd::FileDialog::new().pick_folder() {
        Some(folder) => json!({ "ok": true, "path": folder.to_string_lossy().to_string() }),
        None => json!({ "canceled": true }),
    }
}

pub fn fs_save_dialog(suggested_name: Option<&str>, content: Option<&str>) -> Value {
    let mut dlg = rfd::FileDialog::new();
    if let Some(n) = suggested_name {
        dlg = dlg.set_file_name(n);
    }
    match dlg.save_file() {
        Some(file) => {
            let p_str = file.to_string_lossy().to_string();
            if let Some(c) = content {
                let _ = fs::write(&file, c);
            }
            json!({ "ok": true, "path": p_str })
        }
        None => json!({ "canceled": true }),
    }
}
