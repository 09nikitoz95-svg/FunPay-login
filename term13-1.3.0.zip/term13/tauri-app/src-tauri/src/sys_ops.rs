use serde_json::{json, Value};
use std::process::Stdio;
use std::time::Duration;
use tokio::io::AsyncReadExt;
use tokio::process::Command;

pub fn sys_info() -> Value {
    let platform = if cfg!(target_os = "windows") {
        "win32"
    } else if cfg!(target_os = "macos") {
        "darwin"
    } else {
        "linux"
    };

    let home = dirs::home_dir()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_else(|| ".".into());

    let shell = if cfg!(target_os = "windows") {
        "cmd.exe"
    } else {
        "/bin/bash"
    };

    json!({
        "ok": true,
        "platform": platform,
        "arch": "x64",
        "home": home,
        "cwd": home,
        "shell": shell,
        "path": std::env::var("PATH").unwrap_or_default()
    })
}

pub async fn sys_exec(payload: &Value) -> Value {
    let cmd = match payload.get("cmd").and_then(|c| c.as_str()) {
        Some(c) if !c.trim().is_empty() => c.trim(),
        _ => return json!({ "ok": false, "error": "empty command" }),
    };

    let cwd = payload
        .get("cwd")
        .and_then(|c| c.as_str())
        .map(|s| s.to_string())
        .unwrap_or_else(|| dirs::home_dir().map(|p| p.to_string_lossy().to_string()).unwrap_or_else(|| ".".into()));

    let timeout_ms = payload
        .get("timeoutMs")
        .and_then(|t| t.as_u64())
        .unwrap_or(180000)
        .clamp(1000, 600000);

    let is_win = cfg!(target_os = "windows");
    let mut cmd_builder = if is_win {
        let mut c = Command::new("cmd.exe");
        c.args(["/d", "/s", "/c", cmd]);
        c
    } else {
        let mut c = Command::new("sh");
        c.args(["-c", cmd]);
        c
    };

    cmd_builder
        .current_dir(cwd)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());

    let mut child = match cmd_builder.spawn() {
        Ok(c) => c,
        Err(e) => return json!({ "ok": false, "error": format!("spawn failed: {}", e) }),
    };

    let mut stdout = child.stdout.take();
    let mut stderr = child.stderr.take();

    let mut out_str = String::new();
    let mut err_str = String::new();
    let cap = 1_000_000;

    let res = tokio::select! {
        res = child.wait() => res,
        _ = tokio::time::sleep(Duration::from_millis(timeout_ms)) => {
            let _ = child.kill().await;
            return json!({ "ok": false, "timedOut": true, "error": "Execution timed out" });
        }
    };

    if let Some(mut stream) = stdout.take() {
        let mut buf = Vec::new();
        if let Ok(_) = stream.read_to_end(&mut buf).await {
            out_str = String::from_utf8_lossy(&buf).to_string();
            if out_str.len() > cap {
                out_str.truncate(cap);
            }
        }
    }

    if let Some(mut stream) = stderr.take() {
        let mut buf = Vec::new();
        if let Ok(_) = stream.read_to_end(&mut buf).await {
            err_str = String::from_utf8_lossy(&buf).to_string();
            if err_str.len() > cap {
                err_str.truncate(cap);
            }
        }
    }

    match res {
        Ok(status) => json!({
            "ok": status.success(),
            "exitCode": status.code().unwrap_or(-1),
            "timedOut": false,
            "stdout": out_str,
            "stderr": err_str
        }),
        Err(e) => json!({
            "ok": false,
            "error": e.to_string(),
            "stdout": out_str,
            "stderr": err_str
        }),
    }
}
