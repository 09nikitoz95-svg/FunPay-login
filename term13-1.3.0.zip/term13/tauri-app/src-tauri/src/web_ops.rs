use reqwest::header::HeaderMap;
use serde_json::{json, Value};
use std::time::Duration;

pub async fn web_fetch(payload: &Value) -> Value {
    let url = match payload.get("url").and_then(|u| u.as_str()) {
        Some(u) if u.starts_with("http://") || u.starts_with("https://") => u,
        _ => return json!({ "error": "Нужен полный URL (http/https)" }),
    };

    let max_chars = payload
        .get("maxChars")
        .and_then(|m| m.as_u64())
        .unwrap_or(400_000)
        .clamp(1000, 4_000_000) as usize;

    let timeout_ms = payload
        .get("timeoutMs")
        .and_then(|t| t.as_u64())
        .unwrap_or(20000)
        .clamp(1000, 60000);

    let client = match reqwest::Client::builder()
        .timeout(Duration::from_millis(timeout_ms))
        .build()
    {
        Ok(c) => c,
        Err(e) => return json!({ "error": e.to_string() }),
    };

    let mut headers = HeaderMap::new();
    headers.insert(
        reqwest::header::USER_AGENT,
        reqwest::header::HeaderValue::from_static(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        ),
    );

    if let Some(h) = payload.get("headers").and_then(|h| h.as_object()) {
        for (k, v) in h {
            if let Some(v_str) = v.as_str() {
                if let (Ok(hk), Ok(hv)) = (
                    reqwest::header::HeaderName::from_bytes(k.as_bytes()),
                    reqwest::header::HeaderValue::from_str(v_str),
                ) {
                    headers.insert(hk, hv);
                }
            }
        }
    }

    match client.get(url).headers(headers).send().await {
        Ok(resp) => {
            let status = resp.status().as_u16();
            let final_url = resp.url().to_string();
            let ct = resp
                .headers()
                .get(reqwest::header::CONTENT_TYPE)
                .and_then(|v| v.to_str().ok())
                .unwrap_or("")
                .to_string();

            let bytes = match resp.bytes().await {
                Ok(b) => b,
                Err(e) => return json!({ "error": format!("Read error: {}", e) }),
            };

            let total_len = bytes.len();
            let slice_len = total_len.min(max_chars);
            let text = String::from_utf8_lossy(&bytes[..slice_len]).to_string();

            json!({
                "ok": true,
                "status": status,
                "finalUrl": final_url,
                "contentType": ct,
                "text": text,
                "bytes": total_len,
                "truncated": total_len > max_chars
            })
        }
        Err(e) => json!({ "error": e.to_string() }),
    }
}
