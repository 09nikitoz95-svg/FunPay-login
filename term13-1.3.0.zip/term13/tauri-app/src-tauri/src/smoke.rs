use serde_json::{json, Value};

pub async fn smoke_ready() -> Value {
    // If CLI argument --smoke-test was passed, perform smoke checks
    let args: Vec<String> = std::env::args().collect();
    let is_smoke = args.iter().any(|a| a == "--smoke-test");

    if !is_smoke {
        return json!({ "run": false, "ok": true });
    }

    log::info!("Smoke test starting in Tauri runtime");
    json!({ "run": true, "ok": true })
}
