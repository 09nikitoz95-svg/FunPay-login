use futures_util::StreamExt;
use reqwest::header::{HeaderMap, HeaderValue, AUTHORIZATION, CONTENT_TYPE};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tauri::Emitter;
use tokio::sync::Mutex;

pub struct GatewayState {
    client: reqwest::Client,
    controllers: Mutex<HashMap<String, Arc<AtomicBool>>>,
}

impl GatewayState {
    pub fn new() -> Self {
        let client = reqwest::Client::builder()
            .timeout(Duration::from_secs(120))
            .build()
            .unwrap_or_default();
        Self {
            client,
            controllers: Mutex::new(HashMap::new()),
        }
    }

    pub fn normalize_base_url(&self, u: &str) -> String {
        let mut s = u.trim().trim_end_matches('/').to_string();
        if s.is_empty() {
            s = "https://riskradarai.ru/v1".into();
        }
        if !s.starts_with("http://") && !s.starts_with("https://") {
            s = format!("https://{}", s);
        }
        if !s.ends_with("/v1") && !s.contains("11434") {
            s.push_str("/v1");
        }
        s
    }

    fn headers(&self, api_key: &str) -> HeaderMap {
        let mut h = HeaderMap::new();
        h.insert(CONTENT_TYPE, HeaderValue::from_static("application/json"));
        let key = api_key.trim();
        if !key.is_empty() {
            if let Ok(val) = HeaderValue::from_str(&format!("Bearer {}", key)) {
                h.insert(AUTHORIZATION, val);
            }
        }
        h
    }

    pub async fn get_models(&self, base_url: &str, api_key: &str) -> Value {
        let url = format!("{}/models", self.normalize_base_url(base_url));
        match self
            .client
            .get(&url)
            .headers(self.headers(api_key))
            .timeout(Duration::from_secs(20))
            .send()
            .await
        {
            Ok(resp) => {
                if !resp.status().is_success() {
                    let st = resp.status().as_u16();
                    return json!({ "error": format!("HTTP {}", st) });
                }
                match resp.json::<Value>().await {
                    Ok(val) => {
                        let mut models = Vec::new();
                        if let Some(arr) = val.get("data").and_then(|d| d.as_array()) {
                            for m in arr {
                                if let Some(id) = m.get("id").and_then(|i| i.as_str()) {
                                    models.push(id.to_string());
                                }
                            }
                        }
                        let default_model = val
                            .get("default_model")
                            .and_then(|d| d.as_str())
                            .map(|s| s.to_string())
                            .unwrap_or_else(|| {
                                models.first().cloned().unwrap_or_else(|| "gpt-5.6-luna".into())
                            });
                        json!({ "ok": true, "models": models, "default": default_model })
                    }
                    Err(e) => json!({ "error": format!("JSON parse error: {}", e) }),
                }
            }
            Err(e) => {
                // Check if Ollama local
                if base_url.contains("11434") {
                    let ollama_url = format!("{}/api/tags", self.normalize_base_url(base_url).trim_end_matches("/v1"));
                    if let Ok(oresp) = self.client.get(&ollama_url).send().await {
                        if let Ok(oval) = oresp.json::<Value>().await {
                            let mut models = Vec::new();
                            if let Some(arr) = oval.get("models").and_then(|m| m.as_array()) {
                                for m in arr {
                                    if let Some(name) = m.get("name").and_then(|n| n.as_str()) {
                                        models.push(name.to_string());
                                    }
                                }
                            }
                            let def = models.first().cloned().unwrap_or_else(|| "llama3".into());
                            return json!({ "ok": true, "models": models, "default": def });
                        }
                    }
                }
                json!({ "error": format!("Сеть недоступна: {}", e) })
            }
        }
    }

    pub async fn get_balance(&self, base_url: &str, api_key: &str) -> Value {
        let ts = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();
        let url = format!("{}/balance?ts={}", self.normalize_base_url(base_url), ts);
        match self
            .client
            .get(&url)
            .headers(self.headers(api_key))
            .timeout(Duration::from_secs(20))
            .send()
            .await
        {
            Ok(resp) => {
                if !resp.status().is_success() {
                    return json!({ "error": format!("HTTP {}", resp.status().as_u16()) });
                }
                resp.json::<Value>().await.unwrap_or(json!({ "ok": true }))
            }
            Err(e) => json!({ "error": format!("Сеть недоступна: {}", e) }),
        }
    }

    pub async fn check_key(&self, base_url: &str, api_key: &str) -> Value {
        let url = self.normalize_base_url(base_url);
        match self
            .client
            .get(&url)
            .headers(self.headers(api_key))
            .timeout(Duration::from_secs(20))
            .send()
            .await
        {
            Ok(resp) => {
                if !resp.status().is_success() {
                    return json!({ "error": format!("HTTP {}", resp.status().as_u16()) });
                }
                match resp.json::<Value>().await {
                    Ok(j) => {
                        let key_status = j.get("key").and_then(|k| k.as_str()).unwrap_or("none");
                        json!({
                            "ok": key_status == "valid",
                            "keyStatus": key_status,
                            "defaultModel": j.get("default_model").and_then(|d| d.as_str()).unwrap_or(""),
                            "service": j.get("service").and_then(|s| s.as_str()).unwrap_or("")
                        })
                    }
                    Err(_) => json!({ "ok": true, "keyStatus": "valid" }),
                }
            }
            Err(e) => json!({ "error": format!("Сеть недоступна: {}", e) }),
        }
    }

    pub async fn stop_chat(&self, req_id: &str) -> bool {
        let mut map = self.controllers.lock().await;
        if let Some(flag) = map.remove(req_id) {
            flag.store(true, Ordering::SeqCst);
            true
        } else {
            false
        }
    }

    pub async fn perform_chat<R: tauri::Runtime>(
        &self,
        window: &tauri::Window<R>,
        payload: &Value,
    ) -> Value {
        let req_id = payload
            .get("reqId")
            .and_then(|v| v.as_str())
            .unwrap_or("req-default")
            .to_string();
        let base_url = payload
            .get("baseUrl")
            .and_then(|v| v.as_str())
            .unwrap_or("https://riskradarai.ru/v1");
        let api_key = payload
            .get("apiKey")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        let model = payload
            .get("model")
            .and_then(|v| v.as_str())
            .unwrap_or("gpt-5.6-luna");
        let messages = payload.get("messages").cloned().unwrap_or(json!([]));
        let temp = payload.get("temperature").and_then(|t| t.as_f64());

        let stop_flag = Arc::new(AtomicBool::new(false));
        {
            let mut map = self.controllers.lock().await;
            map.insert(req_id.clone(), stop_flag.clone());
        }

        let res = self
            .attempt_chat(window, &req_id, base_url, api_key, model, &messages, temp, true, stop_flag.clone())
            .await;

        // Auto-retry with non-stream on transient failure
        let mut final_res = res;
        if let Some(err) = final_res.get("error").and_then(|e| e.as_str()) {
            let transient = !err.contains("invalid api key")
                && !err.contains("401")
                && !err.contains("403")
                && !err.contains("недостаточно");
            if transient && !stop_flag.load(Ordering::SeqCst) {
                final_res = self
                    .attempt_chat(window, &req_id, base_url, api_key, model, &messages, temp, false, stop_flag.clone())
                    .await;
            }
        }

        let mut map = self.controllers.lock().await;
        map.remove(&req_id);

        final_res
    }

    async fn attempt_chat<R: tauri::Runtime>(
        &self,
        window: &tauri::Window<R>,
        req_id: &str,
        base_url: &str,
        api_key: &str,
        model: &str,
        messages: &Value,
        temperature: Option<f64>,
        stream: bool,
        stop_flag: Arc<AtomicBool>,
    ) -> Value {
        let url = format!("{}/chat/completions", self.normalize_base_url(base_url));
        let mut body_map = serde_json::Map::new();
        body_map.insert("model".into(), Value::String(model.to_string()));
        body_map.insert("messages".into(), messages.clone());
        body_map.insert("stream".into(), Value::Bool(stream));
        if let Some(t) = temperature {
            body_map.insert("temperature".into(), json!(t));
        }

        let req_build = self
            .client
            .post(&url)
            .headers(self.headers(api_key))
            .json(&body_map);

        let resp = match req_build.send().await {
            Ok(r) => r,
            Err(e) => {
                if stop_flag.load(Ordering::SeqCst) {
                    return json!({ "ok": true, "aborted": true });
                }
                return json!({ "error": format!("Не удалось подключиться к шлюзу: {}", e) });
            }
        };

        if !resp.status().is_success() {
            let st = resp.status().as_u16();
            let err_body = resp.text().await.unwrap_or_default();
            let msg = if let Ok(j) = serde_json::from_str::<Value>(&err_body) {
                j.get("error")
                    .and_then(|e| e.get("message").or(Some(e)))
                    .and_then(|m| m.as_str())
                    .map(|s| s.to_string())
                    .unwrap_or_else(|| format!("HTTP {}", st))
            } else {
                format!("HTTP {} {}", st, err_body.chars().take(200).collect::<String>())
            };
            return json!({ "error": msg });
        }

        let ct = resp
            .headers()
            .get(CONTENT_TYPE)
            .and_then(|v| v.to_str().ok())
            .unwrap_or("")
            .to_string();

        if !stream || ct.contains("application/json") {
            match resp.json::<Value>().await {
                Ok(j) => {
                    if let Some(err) = j.get("error") {
                        let em = err
                            .get("message")
                            .or(Some(err))
                            .and_then(|m| m.as_str())
                            .unwrap_or("Unknown gateway error");
                        return json!({ "error": em });
                    }
                    let content = j
                        .get("choices")
                        .and_then(|c| c.get(0))
                        .and_then(|c0| c0.get("message"))
                        .and_then(|m| m.get("content"))
                        .and_then(|c| c.as_str())
                        .unwrap_or("");
                    if !content.is_empty() {
                        let _ = window.emit("chat:delta", json!({ "reqId": req_id, "text": content }));
                    }
                    return json!({ "ok": true, "content": content });
                }
                Err(e) => return json!({ "error": format!("Некорректный ответ шлюза: {}", e) }),
            }
        }

        // Stream SSE
        let mut stream_bytes = resp.bytes_stream();
        let mut buffer = String::new();
        let mut accumulated = String::new();

        while let Some(item) = stream_bytes.next().await {
            if stop_flag.load(Ordering::SeqCst) {
                return json!({ "ok": true, "aborted": true, "content": accumulated });
            }
            let bytes = match item {
                Ok(b) => b,
                Err(e) => return json!({ "error": format!("Ошибка потока: {}", e) }),
            };
            buffer.push_str(&String::from_utf8_lossy(&bytes));

            while let Some(idx) = buffer.find('\n') {
                let line = buffer[..idx].trim().to_string();
                buffer = buffer[idx + 1..].to_string();

                if !line.starts_with("data:") {
                    continue;
                }
                let payload_str = line[5..].trim();
                if payload_str == "[DONE]" {
                    return json!({ "ok": true, "content": accumulated });
                }

                if let Ok(parsed) = serde_json::from_str::<Value>(payload_str) {
                    if let Some(ch) = parsed.get("choices").and_then(|c| c.get(0)) {
                        if let Some(delta) = ch.get("delta") {
                            if let Some(reason) = delta.get("reasoning_content").or_else(|| delta.get("reasoning")).and_then(|r| r.as_str()) {
                                if !reason.is_empty() {
                                    let _ = window.emit("chat:reasoning", json!({ "reqId": req_id, "text": reason }));
                                }
                            }
                            if let Some(content) = delta.get("content").and_then(|c| c.as_str()) {
                                if !content.is_empty() {
                                    accumulated.push_str(content);
                                    let _ = window.emit("chat:delta", json!({ "reqId": req_id, "text": content }));
                                }
                            }
                        }
                        if let Some(fr) = ch.get("finish_reason").and_then(|f| f.as_str()) {
                            if fr == "stop" {
                                return json!({ "ok": true, "finishReason": fr, "content": accumulated });
                            }
                        }
                    }
                }
            }
        }

        json!({ "ok": true, "content": accumulated })
    }
}
