#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod agent_bridge;
mod db;
mod fs_ops;
mod gateway;
mod smoke;
mod ssh_ops;
mod sys_ops;
mod updater;
mod web_ops;

use agent_bridge::AgentBridge;
use db::Database;
use gateway::GatewayState;
use serde_json::{json, Value};
use ssh_ops::SshManager;
use std::sync::Arc;
use tauri::Manager;

pub struct AppState {
    pub db: Arc<Database>,
    pub gateway: Arc<GatewayState>,
    pub ssh: Arc<SshManager>,
    pub agent: Arc<AgentBridge>,
}

#[tauri::command]
async fn rrapi_invoke<R: tauri::Runtime>(
    app: tauri::AppHandle<R>,
    window: tauri::Window<R>,
    channel: String,
    payload: Value,
) -> Result<Value, String> {
    let state = app.state::<AppState>();

    let res = match channel.as_str() {
        // --- Database ---
        "db:get" => state.db.get_db(),
        "db:put" => {
            state.db.put_db(&payload)?;
            json!({ "ok": true })
        }

        // --- App / Updater ---
        "app:info" => {
            let db_val = state.db.get_db();
            let ui_v = db_val
                .get("settings")
                .and_then(|s| s.get("uiVersion"))
                .and_then(|v| v.as_str())
                .unwrap_or("");
            updater::app_info(ui_v)
        }
        "app:checkHotUi" => {
            let db_val = state.db.get_db();
            let ui_v = db_val
                .get("settings")
                .and_then(|s| s.get("uiVersion"))
                .and_then(|v| v.as_str())
                .unwrap_or("");
            updater::check_hot_ui(&window, ui_v).await
        }
        "app:checkUpdates" => updater::check_updates(&window).await,
        "app:installUpdate" => json!({ "ok": true }),
        "app:openExternal" => {
            let url = if payload.is_string() {
                payload.as_str().unwrap_or("")
            } else {
                payload.get("url").and_then(|u| u.as_str()).unwrap_or("")
            };
            updater::open_external(url)
        }
        "app:relaunch" => updater::relaunch(),

        // --- Gateway / Agent ---
        "gw:models" => {
            let base_url = payload
                .get("baseUrl")
                .and_then(|u| u.as_str())
                .unwrap_or("https://riskradarai.ru/v1");
            let api_key = payload
                .get("apiKey")
                .and_then(|k| k.as_str())
                .unwrap_or("");
            state.gateway.get_models(base_url, api_key).await
        }
        "gw:balance" => {
            let base_url = payload
                .get("baseUrl")
                .and_then(|u| u.as_str())
                .unwrap_or("https://riskradarai.ru/v1");
            let api_key = payload
                .get("apiKey")
                .and_then(|k| k.as_str())
                .unwrap_or("");
            state.gateway.get_balance(base_url, api_key).await
        }
        "gw:check" => {
            let base_url = payload
                .get("baseUrl")
                .and_then(|u| u.as_str())
                .unwrap_or("https://riskradarai.ru/v1");
            let api_key = payload
                .get("apiKey")
                .and_then(|k| k.as_str())
                .unwrap_or("");
            state.gateway.check_key(base_url, api_key).await
        }
        "gw:chat" => state.agent.chat(&window, &payload).await,
        "gw:stop" => {
            let req_id = payload
                .get("reqId")
                .and_then(|r| r.as_str())
                .unwrap_or("");
            json!(state.agent.stop(req_id).await)
        }

        // --- Filesystem ---
        "fs:home" => json!(fs_ops::fs_home()),
        "fs:list" => {
            let dir = payload
                .get("dir")
                .and_then(|d| d.as_str())
                .unwrap_or(".");
            fs_ops::fs_list(dir)
        }
        "fs:readText" => {
            let path = payload
                .get("filePath")
                .and_then(|p| p.as_str())
                .unwrap_or("");
            fs_ops::fs_read_text(path)
        }
        "fs:readImage" => {
            let path = payload
                .get("filePath")
                .and_then(|p| p.as_str())
                .unwrap_or("");
            fs_ops::fs_read_image(path)
        }
        "fs:writeText" => {
            let path = payload
                .get("filePath")
                .and_then(|p| p.as_str())
                .unwrap_or("");
            let content = payload
                .get("content")
                .and_then(|c| c.as_str())
                .unwrap_or("");
            fs_ops::fs_write_text(path, content)
        }
        "fs:writeBinary" => {
            let path = payload.get("filePath").and_then(|p| p.as_str());
            let b64 = payload
                .get("base64")
                .and_then(|b| b.as_str())
                .unwrap_or("");
            let ask = payload
                .get("askPath")
                .and_then(|a| a.as_bool())
                .unwrap_or(false);
            let suggested = payload.get("suggestedName").and_then(|s| s.as_str());
            fs_ops::fs_write_binary(path, b64, ask, suggested)
        }
        "fs:mkdir" => {
            let dir = payload
                .get("dir")
                .and_then(|d| d.as_str())
                .unwrap_or("");
            fs_ops::fs_mkdir(dir)
        }
        "fs:remove" => {
            let target = payload
                .get("target")
                .and_then(|t| t.as_str())
                .unwrap_or("");
            fs_ops::fs_remove(target)
        }
        "fs:openPath" => {
            let path = payload
                .get("filePath")
                .and_then(|p| p.as_str())
                .unwrap_or("");
            fs_ops::fs_open_path(path)
        }
        "fs:showInFolder" => {
            let path = payload
                .get("filePath")
                .and_then(|p| p.as_str())
                .unwrap_or("");
            fs_ops::fs_show_in_folder(path)
        }
        "fs:extInfo" => {
            let path = payload
                .get("filePath")
                .and_then(|p| p.as_str())
                .unwrap_or("");
            fs_ops::fs_ext_info(path)
        }
        "fs:openDialog" => {
            let multi = payload
                .get("multi")
                .and_then(|m| m.as_bool())
                .unwrap_or(false);
            fs_ops::fs_open_dialog(multi)
        }
        "fs:dirDialog" => fs_ops::fs_dir_dialog(),
        "fs:saveDialog" => {
            let suggested = payload.get("suggestedName").and_then(|s| s.as_str());
            let content = payload.get("content").and_then(|c| c.as_str());
            fs_ops::fs_save_dialog(suggested, content)
        }

        // --- System Shell ---
        "sys:info" => sys_ops::sys_info(),
        "sys:exec" => sys_ops::sys_exec(&payload).await,

        // --- Web Fetch ---
        "web:fetch" => web_ops::web_fetch(&payload).await,

        // --- SSH / SFTP ---
        "ssh:connect" => {
            match state.ssh.connect(window.clone(), &payload) {
                Ok(id) => json!({ "ok": true, "id": id }),
                Err(e) => json!({ "error": e }),
            }
        }
        "ssh:write" => {
            let id = payload.get("id").and_then(|i| i.as_str()).unwrap_or("");
            let data = payload.get("data").and_then(|d| d.as_str()).unwrap_or("");
            json!(state.ssh.write_data(id, data))
        }
        "ssh:resize" => {
            let id = payload.get("id").and_then(|i| i.as_str()).unwrap_or("");
            let cols = payload.get("cols").and_then(|c| c.as_u64()).unwrap_or(80) as u32;
            let rows = payload.get("rows").and_then(|r| r.as_u64()).unwrap_or(24) as u32;
            json!(state.ssh.resize(id, cols, rows))
        }
        "ssh:close" => {
            let id = payload.get("id").and_then(|i| i.as_str()).unwrap_or("");
            json!(state.ssh.close(id))
        }
        "ssh:sftpList" => {
            let id = payload.get("id").and_then(|i| i.as_str()).unwrap_or("");
            let dir = payload.get("dir").and_then(|d| d.as_str()).unwrap_or(".");
            state.ssh.sftp_list(id, dir)
        }
        "ssh:sftpDownload" => {
            let id = payload.get("id").and_then(|i| i.as_str()).unwrap_or("");
            let remote = payload.get("remote").and_then(|r| r.as_str()).unwrap_or("");
            let local = payload.get("local").and_then(|l| l.as_str()).unwrap_or("");
            state.ssh.sftp_download(id, remote, local)
        }
        "ssh:sftpUpload" => {
            let id = payload.get("id").and_then(|i| i.as_str()).unwrap_or("");
            let local = payload.get("local").and_then(|l| l.as_str()).unwrap_or("");
            let remote = payload.get("remote").and_then(|r| r.as_str()).unwrap_or("");
            state.ssh.sftp_upload(id, local, remote)
        }

        // --- Smoke test ---
        "agent:pending" => state.agent.list_pending().await,
        "agent:confirm" => {
            let id = payload.get("id").and_then(|i| i.as_str()).unwrap_or("");
            let hash = payload.get("hash").and_then(|h| h.as_str()).unwrap_or("");
            state.agent.confirm_action(id, hash).await
        }
        "smoke:ready" => smoke::smoke_ready().await,

        _ => return Err(format!("Unknown IPC channel: {}", channel)),
    };

    Ok(res)
}

fn main() {
    let db = Database::new().expect("Failed to initialize SQLite database");
    let state = AppState {
        db: Arc::new(db),
        gateway: Arc::new(GatewayState::new()),
        ssh: Arc::new(SshManager::new()),
        agent: Arc::new(AgentBridge::new()),
    };

    tauri::Builder::default()
        .manage(state)
        .invoke_handler(tauri::generate_handler![rrapi_invoke])
        .run(tauri::generate_context!())
        .expect("error while running RiskRadar Terminal");
}
