use serde_json::{json, Value};
use std::fs;
use std::io::Cursor;
use std::path::PathBuf;
use std::time::Duration;
use tauri::Emitter;

pub const APP_VERSION: &str = "1.2.99";
pub const APP_SERVER: &str = "https://riskradarai.ru";

pub fn app_info(current_ui_version: &str) -> Value {
    let platform = if cfg!(target_os = "windows") {
        "win32"
    } else if cfg!(target_os = "macos") {
        "darwin"
    } else {
        "linux"
    };

    json!({
        "version": APP_VERSION,
        "runtime": "tauri",
        "tauri": "2.11.5",
        "platform": platform,
        "isPortable": false,
        "uiVersion": if current_ui_version.is_empty() { "1.2.98 (встроенный)" } else { current_ui_version }
    })
}

pub async fn check_hot_ui<R: tauri::Runtime>(
    window: &tauri::Window<R>,
    current_ui_version: &str,
) -> Value {
    let client = match reqwest::Client::builder()
        .timeout(Duration::from_secs(15))
        .build()
    {
        Ok(c) => c,
        Err(e) => return json!({ "error": e.to_string() }),
    };

    let version_url = format!("{}/app/version.json", APP_SERVER);
    let resp = match client.get(&version_url).send().await {
        Ok(r) if r.status().is_success() => r,
        Ok(r) => return json!({ "error": format!("HTTP {}", r.status().as_u16()) }),
        Err(e) => return json!({ "error": e.to_string() }),
    };

    let meta: Value = match resp.json().await {
        Ok(j) => j,
        Err(e) => return json!({ "error": e.to_string() }),
    };

    let remote = meta
        .get("uiVersion")
        .or_else(|| meta.get("version"))
        .and_then(|v| v.as_str())
        .unwrap_or("")
        .to_string();

    if remote.is_empty() || remote == current_ui_version {
        return json!({ "ok": true, "latest": true, "version": remote });
    }

    // Download zip
    let zip_url = format!("{}/app/app.zip", APP_SERVER);
    let zip_resp = match client.get(&zip_url).send().await {
        Ok(r) if r.status().is_success() => r,
        Ok(r) => return json!({ "error": format!("ZIP HTTP {}", r.status().as_u16()) }),
        Err(e) => return json!({ "error": e.to_string() }),
    };

    let bytes = match zip_resp.bytes().await {
        Ok(b) => b,
        Err(e) => return json!({ "error": format!("ZIP read error: {}", e) }),
    };

    let ui_cache_dir = dirs::data_dir()
        .or_else(dirs::home_dir)
        .unwrap_or_else(|| PathBuf::from("."))
        .join("RiskRadar")
        .join("ui")
        .join(&remote);

    if let Err(e) = fs::create_dir_all(&ui_cache_dir) {
        return json!({ "error": format!("Dir create error: {}", e) });
    }

    let cursor = Cursor::new(bytes);
    if let Ok(mut archive) = zip::ZipArchive::new(cursor) {
        let _ = archive.extract(&ui_cache_dir);
    }

    let _ = window.emit("ui:updated", json!({ "version": remote }));

    json!({ "ok": true, "updated": true, "version": remote })
}

pub async fn check_updates<R: tauri::Runtime>(window: &tauri::Window<R>) -> Value {
    let _ = window.emit("upd:event", json!({ "type": "checking" }));

    let client = match reqwest::Client::builder()
        .timeout(Duration::from_secs(15))
        .build()
    {
        Ok(c) => c,
        Err(e) => {
            let _ = window.emit("upd:event", json!({ "type": "error", "message": e.to_string() }));
            return json!({ "error": e.to_string() });
        }
    };

    let url = format!("{}/app/releases/latest.json", APP_SERVER);
    match client.get(&url).send().await {
        Ok(r) if r.status().is_success() => match r.json::<Value>().await {
            Ok(manifest) => {
                let remote_ver = manifest
                    .get("version")
                    .and_then(|v| v.as_str())
                    .unwrap_or("");
                if !remote_ver.is_empty() && remote_ver > APP_VERSION {
                    let _ = window.emit("upd:event", json!({ "type": "available", "version": remote_ver }));
                    json!({ "ok": true, "available": true, "version": remote_ver })
                } else {
                    let _ = window.emit("upd:event", json!({ "type": "not-available", "version": APP_VERSION }));
                    json!({ "ok": true, "available": false, "version": APP_VERSION })
                }
            }
            Err(e) => {
                let _ = window.emit("upd:event", json!({ "type": "error", "message": e.to_string() }));
                json!({ "error": e.to_string() })
            }
        },
        Ok(r) => {
            let msg = format!("HTTP {}", r.status().as_u16());
            let _ = window.emit("upd:event", json!({ "type": "error", "message": msg }));
            json!({ "error": msg })
        }
        Err(e) => {
            let _ = window.emit("upd:event", json!({ "type": "error", "message": e.to_string() }));
            json!({ "error": e.to_string() })
        }
    }
}

pub fn open_external(url: &str) -> Value {
    if url.starts_with("http://") || url.starts_with("https://") {
        let _ = open::that(url);
    }
    json!({ "ok": true })
}

pub fn relaunch() -> Value {
    if let Ok(exe) = std::env::current_exe() {
        let _ = std::process::Command::new(exe).spawn();
        std::process::exit(0);
    }
    json!({ "ok": true })
}
