use rusqlite::{params, Connection};
use serde_json::{json, Value};
use std::fs;
use std::path::PathBuf;
use std::sync::Mutex;

pub struct Database {
    conn: Mutex<Connection>,
    secure_api_key: Mutex<String>,
}

impl Database {
    pub fn new() -> Result<Self, String> {
        let db_dir = dirs::data_dir()
            .or_else(dirs::home_dir)
            .unwrap_or_else(|| PathBuf::from("."))
            .join("RiskRadar");
        
        fs::create_dir_all(&db_dir).map_err(|e| e.to_string())?;
        let db_path = db_dir.join("terminal.db");
        
        let conn = Connection::open(&db_path).map_err(|e| e.to_string())?;
        
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            CREATE TABLE IF NOT EXISTS chats (
                id TEXT PRIMARY KEY,
                title TEXT,
                model TEXT,
                updated_at INTEGER,
                data TEXT
            );
            CREATE TABLE IF NOT EXISTS ssh_profiles (
                id TEXT PRIMARY KEY,
                host TEXT,
                port INTEGER,
                username TEXT,
                data TEXT
            );
            CREATE TABLE IF NOT EXISTS usage_ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER,
                model TEXT,
                tokens INTEGER,
                cost REAL
            );"
        ).map_err(|e| e.to_string())?;

        Ok(Self {
            conn: Mutex::new(conn),
            secure_api_key: Mutex::new(String::new()),
        })
    }

    pub fn set_secure_key(&self, key: &str) {
        if let Ok(mut k) = self.secure_api_key.lock() {
            *k = key.to_string();
        }
    }

    pub fn get_secure_key(&self) -> String {
        self.secure_api_key.lock().map(|k| k.clone()).unwrap_or_default()
    }

    pub fn get_db(&self) -> Value {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(_) => return json!({"settings": {}, "chats": [], "sshProfiles": []}),
        };

        let mut settings_map = serde_json::Map::new();
        if let Ok(mut stmt) = conn.prepare("SELECT key, value FROM settings") {
            let rows = stmt.query_map([], |row| {
                let k: String = row.get(0)?;
                let v: String = row.get(1)?;
                Ok((k, v))
            });
            if let Ok(iter) = rows {
                for item in iter.flatten() {
                    let parsed: Value = serde_json::from_str(&item.1).unwrap_or(Value::String(item.1));
                    settings_map.insert(item.0, parsed);
                }
            }
        }

        // Default settings if empty
        if !settings_map.contains_key("baseUrl") {
            settings_map.insert("baseUrl".into(), Value::String("https://riskradarai.ru/v1".into()));
        }
        if !settings_map.contains_key("model") {
            settings_map.insert("model".into(), Value::String("gpt-5.6-luna".into()));
        }
        if !settings_map.contains_key("theme") {
            settings_map.insert("theme".into(), Value::String("dark".into()));
        }
        if !settings_map.contains_key("temperature") {
            settings_map.insert("temperature".into(), json!(0.7));
        }
        if !settings_map.contains_key("sendImages") {
            settings_map.insert("sendImages".into(), Value::Bool(true));
        }

        // Return the secure in-memory key rather than SQLite stored key
        let secure_key = self.get_secure_key();
        settings_map.insert("apiKey".into(), Value::String(secure_key));

        let mut chats = Vec::new();
        if let Ok(mut stmt) = conn.prepare("SELECT data FROM chats ORDER BY updated_at DESC") {
            let rows = stmt.query_map([], |row| {
                let d: String = row.get(0)?;
                Ok(d)
            });
            if let Ok(iter) = rows {
                for item in iter.flatten() {
                    if let Ok(val) = serde_json::from_str::<Value>(&item) {
                        chats.push(val);
                    }
                }
            }
        }

        let mut ssh_profiles = Vec::new();
        if let Ok(mut stmt) = conn.prepare("SELECT data FROM ssh_profiles") {
            let rows = stmt.query_map([], |row| {
                let d: String = row.get(0)?;
                Ok(d)
            });
            if let Ok(iter) = rows {
                for item in iter.flatten() {
                    if let Ok(val) = serde_json::from_str::<Value>(&item) {
                        ssh_profiles.push(val);
                    }
                }
            }
        }

        json!({
            "settings": settings_map,
            "chats": chats,
            "sshProfiles": ssh_profiles
        })
    }

    pub fn put_db(&self, val: &Value) -> Result<(), String> {
        let conn = self.conn.lock().map_err(|e| e.to_string())?;

        // 1. Settings: API keys are NEVER stored in SQLite (per security plan)
        if let Some(settings) = val.get("settings").and_then(|s| s.as_object()) {
            for (k, v) in settings {
                if k == "apiKey" {
                    if let Some(key_str) = v.as_str() {
                        self.set_secure_key(key_str);
                    }
                    // Skip saving apiKey into SQLite table
                    continue;
                }
                let val_str = if v.is_string() {
                    v.as_str().unwrap().to_string()
                } else {
                    v.to_string()
                };
                let _ = conn.execute(
                    "INSERT INTO settings (key, value) VALUES (?1, ?2)
                     ON CONFLICT(key) DO UPDATE SET value = ?2",
                    params![k, val_str],
                );
            }
        }

        // 2. Chats
        if let Some(chats) = val.get("chats").and_then(|c| c.as_array()) {
            let _ = conn.execute("DELETE FROM chats", []);
            for chat in chats {
                let id = chat.get("id").and_then(|v| v.as_str()).unwrap_or("");
                let title = chat.get("title").and_then(|v| v.as_str()).unwrap_or("");
                let model = chat.get("model").and_then(|v| v.as_str()).unwrap_or("");
                let updated_at = chat.get("updatedAt").and_then(|v| v.as_i64()).unwrap_or(0);
                let data = chat.to_string();
                let _ = conn.execute(
                    "INSERT OR REPLACE INTO chats (id, title, model, updated_at, data) VALUES (?1, ?2, ?3, ?4, ?5)",
                    params![id, title, model, updated_at, data],
                );
            }
        }

        // 3. SSH profiles
        if let Some(profiles) = val.get("sshProfiles").and_then(|p| p.as_array()) {
            let _ = conn.execute("DELETE FROM ssh_profiles", []);
            for prof in profiles {
                let id = prof.get("id").and_then(|v| v.as_str()).unwrap_or("");
                let host = prof.get("host").and_then(|v| v.as_str()).unwrap_or("");
                let port = prof.get("port").and_then(|v| v.as_i64()).unwrap_or(22);
                let user = prof.get("username").and_then(|v| v.as_str()).unwrap_or("");
                let data = prof.to_string();
                let _ = conn.execute(
                    "INSERT OR REPLACE INTO ssh_profiles (id, host, port, username, data) VALUES (?1, ?2, ?3, ?4, ?5)",
                    params![id, host, port, user, data],
                );
            }
        }

        Ok(())
    }
}
