use base64::Engine;
use serde_json::{json, Value};
use ssh2::{Channel, Session, Sftp};
use std::collections::HashMap;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;
use tauri::Emitter;

pub struct SshSessionItem {
    pub sess: Session,
    pub channel: Mutex<Option<Channel>>,
    pub sftp: Mutex<Option<Sftp>>,
    pub active: Arc<AtomicBool>,
}

pub struct SshManager {
    sessions: Mutex<HashMap<String, Arc<SshSessionItem>>>,
}

impl SshManager {
    pub fn new() -> Self {
        Self {
            sessions: Mutex::new(HashMap::new()),
        }
    }

    pub fn connect<R: tauri::Runtime>(
        &self,
        window: tauri::Window<R>,
        cfg: &Value,
    ) -> Result<String, String> {
        let host = cfg
            .get("host")
            .and_then(|h| h.as_str())
            .ok_or_else(|| "No host specified".to_string())?;
        let port = cfg.get("port").and_then(|p| p.as_u64()).unwrap_or(22) as u16;
        let username = cfg
            .get("username")
            .and_then(|u| u.as_str())
            .ok_or_else(|| "No username specified".to_string())?;

        let tcp = TcpStream::connect((host, port)).map_err(|e| format!("TCP connect error: {}", e))?;
        let mut sess = Session::new().map_err(|e| format!("Session init error: {}", e))?;
        sess.set_tcp_stream(tcp);
        sess.handshake().map_err(|e| format!("SSH handshake error: {}", e))?;

        if let Some(pk_path) = cfg.get("privateKeyPath").and_then(|p| p.as_str()) {
            let pass = cfg.get("passphrase").and_then(|p| p.as_str());
            sess.userauth_pubkey_file(username, None, Path::new(pk_path), pass)
                .map_err(|e| format!("Pubkey auth error: {}", e))?;
        } else if let Some(pass) = cfg.get("password").and_then(|p| p.as_str()) {
            sess.userauth_password(username, pass)
                .map_err(|e| format!("Password auth error: {}", e))?;
        } else {
            return Err("Укажите пароль или путь к закрытому ключу".into());
        }

        let mut channel = sess.channel_session().map_err(|e| format!("Channel error: {}", e))?;
        let cols = cfg.get("cols").and_then(|c| c.as_u64()).unwrap_or(100) as u32;
        let rows = cfg.get("rows").and_then(|r| r.as_u64()).unwrap_or(30) as u32;

        channel
            .request_pty("xterm-256color", None, Some((cols, rows, 0, 0)))
            .map_err(|e| format!("PTY error: {}", e))?;
        channel.shell().map_err(|e| format!("Shell error: {}", e))?;

        let id = format!("ssh-{:x}", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis());
        let active = Arc::new(AtomicBool::new(true));

        let item = Arc::new(SshSessionItem {
            sess,
            channel: Mutex::new(Some(channel)),
            sftp: Mutex::new(None),
            active: active.clone(),
        });

        {
            let mut map = self.sessions.lock().unwrap();
            map.insert(id.clone(), item.clone());
        }

        // Spawn reader thread
        let reader_item = item.clone();
        let reader_id = id.clone();
        let reader_window = window.clone();
        thread::spawn(move || {
            let mut buf = [0u8; 4096];
            while reader_item.active.load(Ordering::SeqCst) {
                let read_res = {
                    let mut ch_opt = reader_item.channel.lock().unwrap();
                    if let Some(ref mut ch) = *ch_opt {
                        ch.read(&mut buf)
                    } else {
                        break;
                    }
                };

                match read_res {
                    Ok(0) => break,
                    Ok(n) => {
                        let b64 = base64::engine::general_purpose::STANDARD.encode(&buf[..n]);
                        let _ = reader_window.emit(
                            "ssh:event",
                            json!({ "event": "data", "id": reader_id, "data": b64 }),
                        );
                    }
                    Err(_) => {
                        thread::sleep(Duration::from_millis(50));
                    }
                }
            }
            reader_item.active.store(false, Ordering::SeqCst);
            let _ = reader_window.emit(
                "ssh:event",
                json!({ "event": "closed", "id": reader_id }),
            );
        });

        Ok(id)
    }

    pub fn write_data(&self, id: &str, base64_data: &str) -> bool {
        let bytes = match base64::engine::general_purpose::STANDARD.decode(base64_data.trim()) {
            Ok(b) => b,
            Err(_) => return false,
        };

        let map = self.sessions.lock().unwrap();
        if let Some(item) = map.get(id) {
            let mut ch = item.channel.lock().unwrap();
            if let Some(ref mut channel) = *ch {
                return channel.write_all(&bytes).is_ok();
            }
        }
        false
    }

    pub fn resize(&self, id: &str, cols: u32, rows: u32) -> bool {
        let map = self.sessions.lock().unwrap();
        if let Some(item) = map.get(id) {
            let mut ch = item.channel.lock().unwrap();
            if let Some(ref mut channel) = *ch {
                return channel.request_pty_size(cols, rows, None, None).is_ok();
            }
        }
        false
    }

    pub fn close(&self, id: &str) -> bool {
        let mut map = self.sessions.lock().unwrap();
        if let Some(item) = map.remove(id) {
            item.active.store(false, Ordering::SeqCst);
            let mut ch = item.channel.lock().unwrap();
            if let Some(mut channel) = ch.take() {
                let _ = channel.close();
            }
            true
        } else {
            false
        }
    }

    pub fn sftp_list(&self, id: &str, dir: &str) -> Value {
        let map = self.sessions.lock().unwrap();
        let item = match map.get(id) {
            Some(i) => i.clone(),
            None => return json!({ "error": "Session not found" }),
        };
        drop(map);

        let mut sftp_guard = item.sftp.lock().unwrap();
        if sftp_guard.is_none() {
            match item.sess.sftp() {
                Ok(s) => *sftp_guard = Some(s),
                Err(e) => return json!({ "error": format!("SFTP init error: {}", e) }),
            }
        }

        let sftp = sftp_guard.as_ref().unwrap();
        let path = Path::new(dir);
        let list = match sftp.readdir(path) {
            Ok(l) => l,
            Err(e) => return json!({ "error": format!("SFTP readdir error: {}", e) }),
        };

        let mut entries = Vec::new();
        for (p, stat) in list {
            let filename = p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
            if filename.is_empty() || filename == "." || filename == ".." {
                continue;
            }
            let is_dir = stat.is_dir();
            let size = stat.size.unwrap_or(0);
            let mtime = stat.mtime.unwrap_or(0) * 1000;
            let full_p = format!("{}/{}", dir.trim_end_matches('/'), filename);

            entries.push(json!({
                "name": filename,
                "path": full_p,
                "dir": is_dir,
                "size": size,
                "mtime": mtime,
                "ext": ""
            }));
        }

        entries.sort_by(|a, b| {
            let a_dir = a.get("dir").and_then(|d| d.as_bool()).unwrap_or(false);
            let b_dir = b.get("dir").and_then(|d| d.as_bool()).unwrap_or(false);
            if a_dir != b_dir {
                return b_dir.cmp(&a_dir);
            }
            let a_name = a.get("name").and_then(|n| n.as_str()).unwrap_or("");
            let b_name = b.get("name").and_then(|n| n.as_str()).unwrap_or("");
            a_name.to_lowercase().cmp(&b_name.to_lowercase())
        });

        json!({ "ok": true, "path": dir, "entries": entries })
    }

    pub fn sftp_download(&self, id: &str, remote: &str, local: &str) -> Value {
        let map = self.sessions.lock().unwrap();
        let item = match map.get(id) {
            Some(i) => i.clone(),
            None => return json!({ "error": "Session not found" }),
        };
        drop(map);

        let mut sftp_guard = item.sftp.lock().unwrap();
        if sftp_guard.is_none() {
            if let Ok(s) = item.sess.sftp() {
                *sftp_guard = Some(s);
            }
        }
        let sftp = match sftp_guard.as_ref() {
            Some(s) => s,
            None => return json!({ "error": "SFTP not initialized" }),
        };

        let mut remote_file = match sftp.open(Path::new(remote)) {
            Ok(f) => f,
            Err(e) => return json!({ "error": format!("Open remote failed: {}", e) }),
        };

        let mut local_file = match std::fs::File::create(local) {
            Ok(f) => f,
            Err(e) => return json!({ "error": format!("Create local failed: {}", e) }),
        };

        let mut buf = [0u8; 16384];
        loop {
            match remote_file.read(&mut buf) {
                Ok(0) => break,
                Ok(n) => {
                    if let Err(e) = local_file.write_all(&buf[..n]) {
                        return json!({ "error": format!("Write local failed: {}", e) });
                    }
                }
                Err(e) => return json!({ "error": format!("Read remote failed: {}", e) }),
            }
        }

        json!({ "ok": true, "local": local })
    }

    pub fn sftp_upload(&self, id: &str, local: &str, remote: &str) -> Value {
        let map = self.sessions.lock().unwrap();
        let item = match map.get(id) {
            Some(i) => i.clone(),
            None => return json!({ "error": "Session not found" }),
        };
        drop(map);

        let mut sftp_guard = item.sftp.lock().unwrap();
        if sftp_guard.is_none() {
            if let Ok(s) = item.sess.sftp() {
                *sftp_guard = Some(s);
            }
        }
        let sftp = match sftp_guard.as_ref() {
            Some(s) => s,
            None => return json!({ "error": "SFTP not initialized" }),
        };

        let mut local_file = match std::fs::File::open(local) {
            Ok(f) => f,
            Err(e) => return json!({ "error": format!("Open local failed: {}", e) }),
        };

        let mut remote_file = match sftp.create(Path::new(remote)) {
            Ok(f) => f,
            Err(e) => return json!({ "error": format!("Create remote failed: {}", e) }),
        };

        let mut buf = [0u8; 16384];
        loop {
            match local_file.read(&mut buf) {
                Ok(0) => break,
                Ok(n) => {
                    if let Err(e) = remote_file.write_all(&buf[..n]) {
                        return json!({ "error": format!("Write remote failed: {}", e) });
                    }
                }
                Err(e) => return json!({ "error": format!("Read local failed: {}", e) }),
            }
        }

        json!({ "ok": true, "remote": remote })
    }
}
