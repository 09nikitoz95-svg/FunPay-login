//! Bridge: Tauri gw:chat / gw:stop channels powered by the rr-terminal agent core.
//! Frontend contract is unchanged: chat:delta + chat:reasoning events, gw:stop cancel.

use rr_terminal::{
    agent::Agent, config::Config, redact::redact, storage::Store,
    types::{AgentRole, JobStatus},
};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::time::{Duration, Instant};
use tauri::Emitter;
use tokio::sync::Mutex;

struct JobEntry {
    id: String,
    cfg: Config,
}

pub struct AgentBridge {
    base: Config,
    store: Store,
    jobs: Mutex<HashMap<String, JobEntry>>,
    cfgs: Mutex<HashMap<String, Config>>,
}

fn role_from(s: &str) -> AgentRole {
    match s.trim().to_lowercase().as_str() {
        "planner" => AgentRole::Planner,
        "coder" => AgentRole::Coder,
        "reviewer" => AgentRole::Reviewer,
        _ => AgentRole::Ops,
    }
}

fn messages_to_text(messages: &Value) -> String {
    let mut out = String::new();
    if let Some(arr) = messages.as_array() {
        for m in arr {
            let role = m.get("role").and_then(Value::as_str).unwrap_or("user");
            let content = m.get("content").and_then(Value::as_str).unwrap_or("");
            if !content.trim().is_empty() {
                out.push_str(role);
                out.push_str(": ");
                out.push_str(content.trim());
                out.push('\n');
            }
        }
    }
    out.trim().to_string()
}

impl AgentBridge {
    pub fn new() -> Self {
        let mut base = Config::from_env();
        if base.ai_url.contains("127.0.0.1:8767") || base.ai_url.contains("localhost:8767") {
            base.ai_url = "https://riskradarai.ru/v1".to_string();
        }
        Self {
            base,
            store: Store::default(),
            jobs: Mutex::new(HashMap::new()),
            cfgs: Mutex::new(HashMap::new()),
        }
    }

    fn cfg_for(&self, payload: &Value) -> Config {
        let mut cfg = self.base.clone();
        if let Some(u) = payload.get("baseUrl").and_then(Value::as_str) {
            let u = u.trim().trim_end_matches('/').to_string();
            if !u.is_empty() {
                cfg.ai_url = if u.starts_with("http") {
                    u
                } else {
                    format!("https://{u}")
                };
            }
        }
        if let Some(k) = payload.get("apiKey").and_then(Value::as_str) {
            let k = k.trim().to_string();
            cfg.ai_key = if k.is_empty() { None } else { Some(k) };
        }
        if let Some(m) = payload.get("model").and_then(Value::as_str) {
            if !m.trim().is_empty() {
                cfg.default_model = m.trim().to_string();
            }
        }
        if let Some(p) = payload.get("projectPath").and_then(Value::as_str) {
            let p = std::path::PathBuf::from(p);
            if p.is_absolute() {
                cfg.writable_roots = vec![p];
            }
        }
        cfg
    }

    pub async fn chat<R: tauri::Runtime>(
        &self,
        window: &tauri::Window<R>,
        payload: &Value,
    ) -> Value {
        let req_id = payload
            .get("reqId")
            .and_then(Value::as_str)
            .unwrap_or("req-default")
            .to_string();
        let mut text = messages_to_text(payload.get("messages").unwrap_or(&Value::Null));
        if text.len() < 2 {
            text = payload
                .get("text")
                .and_then(Value::as_str)
                .unwrap_or("")
                .trim()
                .to_string();
        }
        if text.len() < 2 {
            return json!({"ok": false, "error": "empty prompt"});
        }
        let cfg = self.cfg_for(payload);
        let model = Some(cfg.default_model.clone());
        let role = payload.get("role").and_then(Value::as_str).map(role_from);
        let agent = Agent::new(cfg.clone(), self.store.clone());
        let job_id = match agent.submit(text, model, role).await {
            Ok(id) => id,
            Err(e) => return json!({"ok": false, "error": e.to_string()}),
        };
        self.jobs.lock().await.insert(
            req_id.clone(),
            JobEntry {
                id: job_id.clone(),
                cfg: cfg.clone(),
            },
        );
        let deadline = Instant::now() + Duration::from_secs(cfg.max_job_seconds.max(60));
        let mut sent_len = 0usize;
        let mut sent_steps = 0usize;
        let mut last_status = JobStatus::Queued;
        loop {
            if Instant::now() > deadline {
                break;
            }
            tokio::time::sleep(Duration::from_millis(300)).await;
            let Some(job) = self.store.get_job(&job_id).await else {
                break;
            };
            if job.answer.len() > sent_len {
                let delta = &job.answer[sent_len..];
                sent_len = job.answer.len();
                let _ = window.emit("chat:delta", json!({"reqId": req_id, "text": delta}));
            }
            if job.steps.len() > sent_steps {
                for ev in &job.steps[sent_steps..] {
                    let tool = ev.tool.clone().unwrap_or_default();
                    let prev: String =
                        redact(&ev.payload.to_string()).chars().take(200).collect();
                    let _ = window.emit(
                        "chat:reasoning",
                        json!({"reqId": req_id, "text": format!("{} {} {}", tool, ev.event, prev)}),
                    );
                }
                sent_steps = job.steps.len();
            }
            last_status = job.status.clone();
            match &last_status {
                JobStatus::Done | JobStatus::Error | JobStatus::Aborted | JobStatus::StepsLimit => {
                    break
                }
                JobStatus::Pending => {
                    let pend = self.store.list_pending().await;
                    if let Some(p) = pend.into_iter().max_by_key(|p| p.expires_at) {
                        self.cfgs.lock().await.insert(p.id.clone(), cfg.clone());
                        let _ = window.emit(
                            "agent:confirm",
                            json!({"reqId": req_id, "id": p.id, "hash": p.hash, "preview": p.preview}),
                        );
                    }
                    break;
                }
                _ => {}
            }
        }
        self.jobs.lock().await.remove(&req_id);
        match last_status {
            JobStatus::Done => json!({"ok": true, "reqId": req_id, "id": job_id, "status": "Done"}),
            JobStatus::Pending => {
                json!({"ok": true, "reqId": req_id, "id": job_id, "status": "Pending"})
            }
            JobStatus::Aborted => {
                json!({"ok": true, "reqId": req_id, "id": job_id, "status": "Aborted"})
            }
            JobStatus::StepsLimit => {
                json!({"ok": true, "reqId": req_id, "id": job_id, "status": "StepsLimit"})
            }
            _ => json!({"ok": false, "reqId": req_id, "id": job_id, "status": format!("{last_status:?}")}),
        }
    }

    pub async fn stop(&self, req_id: &str) -> bool {
        let entry = self.jobs.lock().await.remove(req_id);
        match entry {
            Some(e) => {
                Agent::new(e.cfg, self.store.clone())
                    .abort(&e.id)
                    .await
            }
            None => false,
        }
    }

    pub async fn list_pending(&self) -> Value {
        let items = self.store.list_pending().await;
        json!({"ok": true, "items": items})
    }

    pub async fn confirm_action(&self, id: &str, hash: &str) -> Value {
        let cfg = self
            .cfgs
            .lock()
            .await
            .remove(id)
            .unwrap_or_else(|| self.base.clone());
        match Agent::new(cfg, self.store.clone()).confirm(id, hash).await {
            Ok(v) => v,
            Err(e) => json!({"ok": false, "error": e.to_string()}),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn renders_messages() {
        let v = serde_json::json!([
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"}
        ]);
        assert_eq!(messages_to_text(&v), "user: hi\nassistant: hello");
        assert_eq!(messages_to_text(&Value::Null), "");
    }
    #[test]
    fn parses_roles() {
        assert_eq!(role_from("coder"), AgentRole::Coder);
        assert_eq!(role_from("???"), AgentRole::Ops);
    }
    #[test]
    fn cfg_overrides() {
        let b = AgentBridge::new();
        let p = serde_json::json!({
            "baseUrl": "example.com",
            "apiKey": "k",
            "model": "m",
            "projectPath": "/tmp/proj"
        });
        let c = b.cfg_for(&p);
        assert_eq!(c.ai_url, "https://example.com");
        assert_eq!(c.ai_key.as_deref(), Some("k"));
        assert_eq!(c.default_model, "m");
        assert_eq!(c.writable_roots, vec![std::path::PathBuf::from("/tmp/proj")]);
    }
}
